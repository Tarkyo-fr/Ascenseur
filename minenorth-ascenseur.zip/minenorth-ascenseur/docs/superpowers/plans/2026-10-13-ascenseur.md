# MineNorth Ascenseur — plan d'implémentation

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal :** Un mod Forge d'ascenseur MineNorthRP : cabine visible qui se déplace entre étages, étages réservés par rôle (police, pompier/SAMU, mairie, entreprise), tailles 1×1, 2×2, 2×4, 4×4.

**Architecture :** Un noyau Java pur (modèle, règles d'accès, contrôleur de trajet) sans import Minecraft, testé en JUnit ; autour, une couche Forge (blocs, entité cabine, `SavedData`, réseau, écrans) qui ne contient que la colle. Les rôles viennent de l'API MineNorth (police) et de réflexion (secours, mairie, entreprises), sur le modèle exact des classes `*Compat` de `minenorth-portes`.

**Tech Stack :** Forge 1.20.1 (47.4.10), Java 17, ForgeGradle 6, JUnit 5 pour le noyau pur.

**Spec :** `docs/superpowers/specs/2026-10-13-ascenseur-design.md`

## Global Constraints

- Forge `1.20.1-47.4.10`, mappings `official 1.20.1`, Java 17, même `build.gradle` que `../minenorth-portes/build.gradle` (flatDir `../minenorth-api/build/libs`, `fg.deobf("blank:minenorth_api:1.0.0")`).
- modId `minenorthascenseur`, paquetage `fr.minenorth.ascenseur`, nom affiché « MineNorth Ascenseur », `archivesName = 'minenorth-ascenseur'`.
- Dépendance obligatoire à `minenorthapi` `[1.0.0,2)`. `minenorthsecours`, `minenorthetat`, `minenorthentreprises` : par réflexion uniquement, jamais obligatoires.
- Tailles de cabine : `1x1`, `2x2`, `2x4`, `4x4`. Étages : 2 à 32, hauteurs `y` strictement croissantes.
- Étage : `Floor(name, y, access)` ; `access` ∈ `PUBLIC`, `POLICE`, `POMPIER`, `MAIRIE`, `entreprise:<id>:<gradeMin>` (`-1` patron seul, `0` grade le plus haut, `99` tous les employés). Toute autre valeur = verrouillé pour les non-OP.
- Règle des rôles identique à `OwnerDoorManager.canOpen` de Portes : OP (niveau 2) passent toujours ; nœuds Forge `grade.police`, `grade.pompier`, `grade.medical`, `grade.mairie` ; police via `MineNorth.police().isPolice(p)`.
- Voyage groupé : seul le joueur qui choisit l'étage est vérifié ; tous ceux dans l'empreinte de la cabine sont emmenés. Appel au palier : vérifié, inerte sans le rôle.
- Seuls les OP règlent un ascenseur. Pendant un trajet, personne ne change d'étage ; les appels sont en file, servis dans l'ordre.
- Protection casse/explosion des blocs du mod pour les non-OP, code propre, sans dépendance à Portes.

## Review Focus

1. Un passager se déconnecte ou meurt en plein trajet : la cabine termine ou revient à un étage sain, rien ne reste bloqué (test sur `TripController`, vérification manuelle).
2. Le serveur s'arrête en plein trajet : au rechargement, la cabine est recalée sur l'étage le plus proche (test `resetSnapsToNearestFloor`).
3. Un bloc obstrue la gaine : le trajet s'interrompt, la cabine revient à l'étage précédent, personne n'est étouffé ni expulsé (vérification manuelle).
4. Secours, Mairie ou Entreprises absent : l'étage de ce rôle reste verrouillé, aucune exception (test `missingRoleModLocksFloor`).
5. Entreprise supprimée ou nom d'accès invalide dans un étage : verrouillé pour les non-OP, signalé à l'admin (tests `unknownAccessLocksFloorForNonOp`, `entrepriseMissingLocksFloor`).
6. L'admin modifie les étages pendant un trajet : les appels pointant vers un étage disparu sont écartés (test `floorsRemovedWhileQueued`).

---

## Structure des fichiers

Dans `minenorth-ascenseur/`, sous `src/main/java/fr/minenorth/ascenseur/` :

- `MineNorthAscenseur.java` : point d'entrée.
- `model/` (Java pur, aucun import `net.minecraft`) : `CabinSize`, `Floor`, `Elevator`, `FloorAccess`, `Roles`, `TripController`, `PanelBuilder`, `ElevatorRules`.
- `compat/` : `SecoursCompat`, `MairieCompat`, `EntrepriseCompat` (copiés de Portes, paquetage changé), `ServerRoles` (implémente `Roles` pour un `ServerPlayer`), `Permissions` (nœuds Forge).
- `data/` : `ElevatorData` (`SavedData`), `ElevatorNbt`.
- `block/` : `ModBlocks`, `CabinBlock`, `CabinBlockEntity`, `CallButtonBlock`, `CallButtonBlockEntity`, `FloorDoorBlock`, `FloorDoorBlockEntity`.
- `cabin/` : `CabinEntity`, `ModEntities`, `ElevatorService` (tick serveur, relie modèle + trajet + entité).
- `network/` : `ModNetwork` et les paquets.
- `client/` : `MineNorthStyle`, `MineNorthButton` (copies de Portes), `ElevatorPanelScreen`, `ElevatorAdminScreen`, `ClientNetworkHandler`, `CabinRenderer`.
- `command/AscenseurCommands.java`, `config/AscenseurConfig.java`, `ElevatorProtection.java`.

Tests : `src/test/java/fr/minenorth/ascenseur/model/*Test.java`.

---

### Task 1 : Squelette du mod

**Files :**
- Create : `build.gradle`, `settings.gradle`, `.gitignore` (`build/`, `run/`, `.gradle/`, `.superpowers/`), `gradle/wrapper/*` et `gradlew*` (copie de `../minenorth-portes`)
- Create : `src/main/resources/META-INF/mods.toml`, `src/main/resources/pack.mcmeta`
- Create : `src/main/java/fr/minenorth/ascenseur/MineNorthAscenseur.java`
- Test : `src/test/java/fr/minenorth/ascenseur/ModIdTest.java`

**Interfaces :**
- Produces : `MineNorthAscenseur.MOD_ID = "minenorthascenseur"`.

- [ ] **Step 1 :** Test `ModIdTest.modIdIsStable` : `assertEquals("minenorthascenseur", MineNorthAscenseur.MOD_ID)`.
- [ ] **Step 2 :** `./gradlew test` ; attendu : échec de compilation (classe absente).
- [ ] **Step 3 :** Copier `build.gradle` de Portes en remplaçant `minenorthportes`/`minenorth-portes`/`MineNorth Portes` par les valeurs des Global Constraints, ajouter `testImplementation 'org.junit.jupiter:junit-jupiter:5.10.2'` et `test { useJUnitPlatform() }`. Écrire `mods.toml` avec les dépendances forge, minecraft, `minenorthapi` (copier celles de Portes). Classe `@Mod(MOD_ID)` vide.
- [ ] **Step 4 :** `./gradlew test build` ; attendu : `BUILD SUCCESSFUL` (le jar `minenorth-ascenseur-1.0.0.jar` est produit ; `../minenorth-api` doit avoir été construit avant).
- [ ] **Step 5 :** `./gradlew runServer`, vérifier dans le log le chargement du mod `minenorthascenseur` sans erreur, puis stopper.
- [ ] **Step 6 :** Commit `chore: squelette du mod ascenseur`.

---

### Task 2 : Modèle d'ascenseur et validation

**Files :**
- Create : `model/CabinSize.java`, `model/Floor.java`, `model/Elevator.java`
- Test : `model/ElevatorTest.java`

**Interfaces :**
- Produces :
  - `enum CabinSize { S1X1, S2X2, S2X4, S4X4 }` avec `int width()`, `int depth()`, `static Optional<CabinSize> parse(String)` (`"2x4"`).
  - `record Floor(String name, int y, String access)`.
  - `final class Elevator` : `UUID id()`, `String name()`, `CabinSize size()`, `List<Floor> floors()`, `static Optional<String> validate(String name, CabinSize size, List<Floor> floors)` (retourne un message d'erreur ou vide).
  - constantes `MIN_FLOORS = 2`, `MAX_FLOORS = 32`.

- [ ] **Step 1 :** Tests : `rejectsFewerThanTwoFloors`, `rejectsMoreThan32Floors`, `rejectsNonIncreasingHeights`, `rejectsBlankFloorName`, `acceptsHospitalExample` (Accueil 64 `PUBLIC`, Urgences 70 `PUBLIC`, Bloc opératoire 76 `POMPIER`, Garde à vue 82 `POLICE`, Direction 88 `entreprise:1:1`, taille `2x4`), `parsesSizes` (`"1x1"`, `"2x2"`, `"2x4"`, `"4x4"` valides, `"3x3"` vide).
- [ ] **Step 2 :** `./gradlew test --tests '*ElevatorTest'` ; attendu : échec.
- [ ] **Step 3 :** Implémenter les trois types. `validate` renvoie le premier message d'erreur en français.
- [ ] **Step 4 :** Même commande ; attendu : tous verts.
- [ ] **Step 5 :** Commit `feat: modèle ascenseur et validation`.

---

### Task 3 : Règles d'accès par étage

**Files :**
- Create : `model/Roles.java`, `model/FloorAccess.java`
- Test : `model/FloorAccessTest.java`

**Interfaces :**
- Consumes : rien.
- Produces :
  - `interface Roles { boolean isOp(); boolean isPolice(); boolean isSecours(); boolean isMairie(); boolean hasNode(String node); boolean entrepriseExists(int id); boolean entrepriseCanOpen(int id, int minGrade); }`
  - `sealed interface FloorAccess` avec `static FloorAccess parse(String raw)` (valeur inconnue → `Unknown`), `String format()`, `boolean canUse(Roles r)`, `String label()` (« Public », « Police », « Pompier/SAMU », « Mairie », « Entreprise », « Verrouillé »).

- [ ] **Step 1 :** Tests avec un faux `Roles` : `publicOpenToAll`, `opAlwaysPasses`, `policeRequiresPoliceOrNode`, `pompierRequiresSecoursOrNode`, `mairieRequiresStaffOrNode`, `entrepriseUsesGrade` (`entreprise:3:1` ouvert seulement si `entrepriseCanOpen(3,1)`), `entrepriseMissingLocksFloor` (`entrepriseExists` faux : verrouillé même pour un employé), `missingRoleModLocksFloor` (tous les rôles faux : POLICE/POMPIER/MAIRIE fermés), `unknownAccessLocksFloorForNonOp` (`"banane"`, `"entreprise:x"`), `roundTripFormat` (`entreprise:3:-1`).
- [ ] **Step 2 :** `./gradlew test --tests '*FloorAccessTest'` ; attendu : échec.
- [ ] **Step 3 :** Implémenter. L'ordre d'évaluation dans `canUse` : OP d'abord, puis le cas ; nœud Forge ou rôle API pour POLICE/POMPIER/MAIRIE (comme `canOpen` de Portes, lignes 264–266).
- [ ] **Step 4 :** Même commande ; attendu : tous verts.
- [ ] **Step 5 :** Commit `feat: règles d'accès des étages`.

---

### Task 4 : Liens vers les autres mods et permissions Forge

**Files :**
- Create : `compat/SecoursCompat.java`, `compat/MairieCompat.java`, `compat/EntrepriseCompat.java`, `compat/ServerRoles.java`, `compat/Permissions.java`
- Reference : `../minenorth-portes/src/main/java/fr/minenorth/drill/door/{SecoursCompat,MairieCompat,EntrepriseCompat,PoliceCompat}.java`

**Interfaces :**
- Consumes : `Roles`, `FloorAccess` (Task 3).
- Produces :
  - `ServerRoles implements Roles`, `static ServerRoles of(ServerPlayer p)`.
  - `EntrepriseCompat.companies(MinecraftServer) -> List<String>` (`"id|nom"`), `grades(MinecraftServer, int id) -> List<String>`, `name(MinecraftServer, int id) -> String`.
  - `Permissions.hasNode(ServerPlayer p, String node) -> boolean` ; les quatre nœuds sont enregistrés sous `minenorthascenseur` via `PermissionGatherEvent.Nodes`, défaut = `p.hasPermissions(2)`, comme `OwnerDoorManager.gatherPermissions`.

- [ ] **Step 1 :** Copier les trois `*Compat` en changeant seulement le paquetage ; `ServerRoles` : `isPolice` = `MineNorth.police().isPolice(p)`, `isSecours` = `SecoursCompat.isSecours(p)`, `isMairie` = `MairieCompat.isStaff(p)`, `hasNode` = `Permissions.hasNode`, `entrepriseExists` = `!EntrepriseCompat.name(server, id).isBlank()`, `entrepriseCanOpen` = `EntrepriseCompat.canOpen`.
- [ ] **Step 2 :** `./gradlew build` ; attendu : `BUILD SUCCESSFUL`.
- [ ] **Step 3 :** Vérification manuelle : `./gradlew runServer` avec seulement l'API présente ; appeler `ServerRoles.of(p)` via une commande temporaire ou un log au join ; attendu : aucune exception, tous les rôles faux. Retirer le code temporaire.
- [ ] **Step 4 :** Commit `feat: liens rôles par réflexion et permissions`.

---

### Task 5 : Contrôleur de trajet

**Files :**
- Create : `model/TripController.java`
- Test : `model/TripControllerTest.java`

**Interfaces :**
- Produces : `final class TripController` :
  - `TripController(int[] floorYs, int startFloor, double blocksPerTick, int doorTicks)`
  - `enum Phase { IDLE, DOORS_CLOSING, MOVING, DOORS_OPENING }`
  - `void call(int floor)` : met en file ; ignoré si déjà en file ; si la cabine est à cet étage et inactive, rouvre les portes.
  - `boolean select(int floor)` : `false` si la phase n'est pas `IDLE` ou si l'étage est invalide ; sinon enregistre la destination.
  - `void tick()`, `Phase phase()`, `int currentFloor()`, `int targetFloor()` (`-1` si aucune), `double y()`.
  - `void updateFloors(int[] floorYs)` : écarte les appels vers un étage disparu.
  - `void reset(double y)` : recale sur l'étage le plus proche, phase `IDLE`, file vidée.

- [ ] **Step 1 :** Tests : `callsServedInOrder`, `duplicateCallsNotQueued`, `selectIgnoredWhileMoving`, `selectAllowedWhenIdle`, `callAtCurrentFloorOpensDoors`, `reachesTargetExactly` (`y()` égale `floorYs[target]` à l'arrivée), `floorsRemovedWhileQueued`, `resetSnapsToNearestFloor` (reset à `y=73` avec étages 64/70/76 → étage 1 puis phase `IDLE`).
- [ ] **Step 2 :** `./gradlew test --tests '*TripControllerTest'` ; attendu : échec.
- [ ] **Step 3 :** Implémenter la machine d'états : `IDLE` → `DOORS_CLOSING` (`doorTicks`) → `MOVING` → `DOORS_OPENING` → `IDLE` (puis prochain appel de la file).
- [ ] **Step 4 :** Même commande ; attendu : tous verts.
- [ ] **Step 5 :** Commit `feat: contrôleur de trajet`.

---

### Task 6 : Panneau joueur et règle de sélection

**Files :**
- Create : `model/PanelBuilder.java`, `model/ElevatorRules.java`
- Test : `model/PanelBuilderTest.java`, `model/ElevatorRulesTest.java`

**Interfaces :**
- Consumes : `Elevator`, `FloorAccess`, `Roles`, `TripController`.
- Produces :
  - `record FloorView(int index, String name, int y, String roleLabel, boolean allowed, boolean current)` et `String tooltip()` au format `3 · Garde à vue · Police`.
  - `PanelBuilder.forPlayer(Elevator e, Roles r, int currentFloor) -> List<FloorView>`.
  - `ElevatorRules.canSelect(Elevator e, int floor, Roles r, boolean insideCabin, TripController t) -> boolean` : vrai seulement si le joueur est dans la cabine, la phase est `IDLE`, l'étage existe, n'est pas l'étage actuel et `FloorAccess.canUse`.
  - `ElevatorRules.canCall(Elevator e, int floor, Roles r) -> boolean`.

- [ ] **Step 1 :** Tests : `tooltipShowsRoleLabel`, `lockedFloorIsNotAllowed`, `currentFloorIsMarked`, `cannotSelectWhileMoving`, `cannotSelectFromOutsideCabin`, `cannotSelectRestrictedFloorWithoutRole`, `callOnRestrictedFloorIsInertWithoutRole`, `passengersWithoutRoleStillCarried` (la règle ne regarde que le joueur qui choisit, pas la liste des passagers : `canSelect` n'a pas de paramètre passagers).
- [ ] **Step 2 :** `./gradlew test --tests '*PanelBuilderTest' --tests '*ElevatorRulesTest'` ; attendu : échec.
- [ ] **Step 3 :** Implémenter.
- [ ] **Step 4 :** Même commande ; attendu : tous verts.
- [ ] **Step 5 :** Commit `feat: panneau joueur et règles de sélection`.

---

### Task 7 : Persistance

**Files :**
- Create : `data/ElevatorNbt.java`, `data/ElevatorData.java`
- Test : `data/ElevatorNbtTest.java`

**Interfaces :**
- Produces :
  - `ElevatorNbt.toTag(Elevator e, ResourceKey<Level> dim, BlockPos anchor, Direction facing) -> CompoundTag` et `fromTag(CompoundTag) -> StoredElevator` (record `(Elevator elevator, ResourceKey<Level> dim, BlockPos anchor, Direction facing)`).
  - `ElevatorData extends SavedData` : `static ElevatorData get(MinecraftServer)`, `Optional<StoredElevator> byId(UUID)`, `Optional<StoredElevator> atAnchor(ResourceKey<Level>, BlockPos)`, `void put(StoredElevator)`, `void remove(UUID)`, `Collection<StoredElevator> all()`. Stocké dans l'overworld sous le nom `minenorthascenseur_elevators`, comme `OwnerDoorData`.

- [ ] **Step 1 :** Test `ElevatorNbtTest.roundTrip` : l'exemple d'hôpital survit à `toTag` puis `fromTag` (nom, taille, 5 étages, accès, ancre, orientation). Si les classes Minecraft ne se chargent pas dans les tests JUnit, déplacer ce test en vérification manuelle (création, `/save-all`, redémarrage, relecture) et le noter dans le commit.
- [ ] **Step 2 :** `./gradlew test --tests '*ElevatorNbtTest'` ; attendu : échec.
- [ ] **Step 3 :** Implémenter.
- [ ] **Step 4 :** Même commande ; attendu : vert.
- [ ] **Step 5 :** Commit `feat: sauvegarde des ascenseurs`.

---

### Task 8 : Blocs et enregistrements

**Files :**
- Create : `block/ModBlocks.java`, `block/CabinBlock.java`, `block/CabinBlockEntity.java`, `block/CallButtonBlock.java`, `block/CallButtonBlockEntity.java`, `block/FloorDoorBlock.java`, `block/FloorDoorBlockEntity.java`
- Create : `src/main/resources/assets/minenorthascenseur/{blockstates,models/block,models/item,lang/fr_fr.json}` pour `cabine`, `bouton_appel`, `porte_etage`
- Modify : `MineNorthAscenseur.java` (enregistrement sur le bus du mod)

**Interfaces :**
- Produces : `ModBlocks.CABIN`, `ModBlocks.CALL_BUTTON`, `ModBlocks.FLOOR_DOOR` (`RegistryObject<Block>`), leurs types d'entité de bloc, et dans chaque entité un champ `UUID elevatorId` (+ `int floorIndex` pour bouton et porte d'étage) avec NBT. Les trois objets vont dans l'onglet créatif MineNorth (voir `SharedTab` de Portes).
- Conventions : `DeferredRegister` comme `ModVending` du mod Entreprises ; textures provisoires vanilla acceptées.

- [ ] **Step 1 :** Implémenter les enregistrements et les trois blocs (les clics ne font encore rien, `use` retourne `InteractionResult.PASS`).
- [ ] **Step 2 :** `./gradlew build` ; attendu : `BUILD SUCCESSFUL`.
- [ ] **Step 3 :** Vérification manuelle `./gradlew runClient` : `/give` les trois blocs, les poser, les casser, quitter et revenir ; attendu : textures visibles, pas de crash, l'`elevatorId` survit au rechargement.
- [ ] **Step 4 :** Commit `feat: blocs cabine, bouton d'appel, porte d'étage`.

---

### Task 9 : Réseau et écrans

**Files :**
- Create : `network/ModNetwork.java`, `network/ElevatorPanelPacket.java`, `network/SelectFloorPacket.java`, `network/AdminPanelPacket.java`, `network/AdminSavePacket.java`
- Create : `client/MineNorthStyle.java`, `client/MineNorthButton.java` (copies de Portes, paquetage changé), `client/ElevatorPanelScreen.java`, `client/ElevatorAdminScreen.java`, `client/ClientNetworkHandler.java`
- Reference : `../minenorth-portes/.../network/ModNetwork.java`, `client/DoorPanelScreen.java`

**Interfaces :**
- Consumes : `FloorView` (Task 6), `Elevator`, `EntrepriseCompat.companies/grades` (Task 4).
- Produces :
  - `ElevatorPanelPacket(UUID elevatorId, String elevatorName, List<FloorView> floors)` (serveur → client).
  - `SelectFloorPacket(UUID elevatorId, int floorIndex)` (client → serveur) ; le serveur revalide tout via `ElevatorRules.canSelect`.
  - `AdminPanelPacket(Elevator-complet, List<String> companies)` (serveur → client, OP seulement) et `AdminSavePacket(UUID id, String name, String size, List<Floor> floors)` (client → serveur) ; le serveur exécute `Elevator.validate`, vérifie `hasPermissions(2)`, et renvoie le message d'erreur à l'écran.
- Écrans : `ElevatorPanelScreen` = colonne de boutons ronds du bas vers le haut, étage actuel mis en évidence, boutons interdits éteints, infobulle `FloorView.tooltip()` au survol. `ElevatorAdminScreen` = nom, taille, nombre d'étages, par étage : nom, hauteur (bouton « ma position = hauteur de l'étage » : `player.getBlockY()`), accès (liste Public / Police / Pompier-SAMU / Mairie / Entreprise + sélecteur d'entreprise et de grade), boutons « + Étage » et « Supprimer ».

- [ ] **Step 1 :** Implémenter paquets, `ModNetwork.register()` appelé depuis `MineNorthAscenseur`, et les deux écrans.
- [ ] **Step 2 :** `./gradlew build` ; attendu : `BUILD SUCCESSFUL`.
- [ ] **Step 3 :** Vérification manuelle `runClient` : ouvrir les deux écrans depuis une commande de test, tester le survol, la sauvegarde admin avec des données invalides (message d'erreur) et valides. Retirer la commande de test.
- [ ] **Step 4 :** Commit `feat: réseau et écrans joueur et admin`.

---

### Task 10 : Cabine mobile et service serveur

**Files :**
- Create : `cabin/CabinEntity.java`, `cabin/ModEntities.java`, `cabin/ElevatorService.java`, `client/CabinRenderer.java`
- Modify : `block/CabinBlock.java`, `block/CallButtonBlock.java`, `block/FloorDoorBlock.java` (interactions)

**Interfaces :**
- Consumes : `TripController`, `ElevatorRules`, `ServerRoles`, `ElevatorData`, paquets de la Task 9.
- Produces : `ElevatorService.onServerTick(MinecraftServer)` (un `TripController` par ascenseur chargé), `handleSelect(ServerPlayer, UUID, int)`, `handleCall(ServerPlayer, UUID, int)`, `openPanel(ServerPlayer, UUID)`.
- Interactions : clic droit sur la cabine → `openPanel` (joueur) ; OP + accroupi → panneau admin ; clic sur le bouton d'appel → `handleCall` ; la porte d'étage est un obstacle fermé tant que la cabine n'est pas à son étage et passe en ouvert avec elle.
- Exigences (spec) : empreinte exacte selon `CabinSize` (2×4 selon l'orientation), mouvement fluide visuel, **aucun dégât de chute, aucune expulsion anti-fly, jamais dans un mur**, tous les joueurs dans l'empreinte voyagent ensemble, un passager qui se déconnecte ou meurt ne bloque pas le service, au démarrage du serveur chaque cabine est recalée via `TripController.reset(y)`.
- Conseil : commencer par un spike de fluidité (une cabine 1×1 qui monte avec un joueur dessus) avant d'écrire le reste ; l'implémentation entité + passagers repositionnés à chaque tick est ma suggestion, pas une contrainte.

- [ ] **Step 1 :** Spike : `CabinEntity` 1×1 et trajet entre deux hauteurs fixes ; vérifier à la main que le joueur monte sans saccade, sans dégât et sans kick après 10 s en l'air.
- [ ] **Step 2 :** Brancher `ElevatorService` sur `ElevatorData` et `TripController`, interactions des trois blocs, tailles 2×2, 2×4, 4×4, portes d'étage, détection d'obstruction (arrêt + retour à l'étage précédent).
- [ ] **Step 3 :** `./gradlew build` ; attendu : `BUILD SUCCESSFUL`, tous les tests précédents toujours verts (`./gradlew test`).
- [ ] **Step 4 :** Vérification manuelle (liste de contrôle) : 1) trajet 0→3 avec 2 joueurs, tous arrivent ; 2) bouton d'appel d'un étage POLICE sans rôle : inerte ; 3) joueur sans rôle monte avec un policier qui choisit « Garde à vue » : il arrive aussi ; 4) bloc posé dans la gaine : arrêt sans dégât ; 5) un passager se déconnecte en plein trajet : service intact ; 6) `/stop` en plein trajet puis relance : cabine à un étage.
- [ ] **Step 5 :** Commit `feat: cabine mobile et service d'ascenseur`.

---

### Task 11 : Protection, commandes, configuration

**Files :**
- Create : `ElevatorProtection.java`, `command/AscenseurCommands.java`, `config/AscenseurConfig.java`
- Reference : `../minenorth-portes/.../door/DoorProtection.java`, `command/DoorCommands.java`, `config/SystemeConfigFiles.java`

**Interfaces :**
- Produces :
  - Protection (casse, explosion) des trois blocs du mod pour les non-OP, message « §cCet ascenseur est protégé. » comme Portes ; un OP qui casse la cabine retire l'entité et dépose les passagers à l'étage le plus proche.
  - `/ascenseur list`, `/ascenseur remove <nom>`, `/ascenseur reload` (niveau 2).
  - `AscenseurConfig` : `speedBlocksPerSecond` (défaut 4.0), `doorSeconds` (défaut 2.0), lus au démarrage et sur `/ascenseur reload`, dans le même style de fichier que `SystemeConfigFiles`.

- [ ] **Step 1 :** Implémenter.
- [ ] **Step 2 :** `./gradlew build test` ; attendu : `BUILD SUCCESSFUL`.
- [ ] **Step 3 :** Vérification manuelle : un joueur non-OP ne casse ni cabine, ni bouton, ni porte, et un TNT les épargne ; un OP casse la cabine en plein trajet sans blocage ; `/ascenseur reload` change la vitesse sans redémarrage.
- [ ] **Step 4 :** Commit `feat: protection, commandes et configuration`.

---

### Task 12 : Recette sur l'exemple de l'hôpital

**Files :**
- Modify : `README.md` (création : installation, commandes, exemple de réglage)

- [ ] **Step 1 :** Sur un serveur de test avec Portes, Secours, Police, Entreprises et Mairie à jour : construire une gaine de 5 étages, poser la cabine 2×4, régler Accueil/Urgences publics, Bloc opératoire POMPIER, Garde à vue POLICE, Direction `entreprise:<id>:1`, poser boutons et portes d'étage.
- [ ] **Step 2 :** Rejouer la liste de contrôle de la Task 10, plus : un civil voit les étages interdits éteints avec infobulle, un pompier accède au Bloc opératoire, un employé de grade 1 accède à la Direction, un employé de grade 5 non.
- [ ] **Step 3 :** `./gradlew build` ; attendu : `BUILD SUCCESSFUL` et le jar dans `build/libs/`.
- [ ] **Step 4 :** Commit `docs: README et recette hôpital`.
