# MineNorth Ascenseur — document de conception

Date : 2026-10-13. Statut : à valider par Tarkyo.

## Intention

Les grands bâtiments du serveur MineNorthRP (l'hôpital en premier) ont plusieurs étages. Il faut un ascenseur qui fait partie du roleplay : une vraie cabine qui monte et descend sous les yeux des joueurs, avec des étages réservés à certains rôles (police, pompiers/SAMU, entreprise, mairie). Le mod doit avoir le même style, la même charte et les mêmes règles de rôles que les autres mods MineNorth, et en particulier que le mod Portes.

## Objectifs

- Un admin pose une cabine puis la règle dans un menu : taille, nombre d'étages, nom et hauteur de chaque étage, rôle autorisé par étage.
- Cabine visible qui se déplace d'un étage à l'autre (pas de téléportation).
- Trois à quatre tailles de cabine : 1×1, 2×2, 2×4 (passage d'un lit d'hôpital), 4×4.
- À chaque étage, un bouton d'appel posé par l'admin à côté de la porte. Un clic appelle la cabine, les portes de la cabine s'ouvrent à l'arrivée.
- Dans la cabine, un clic ouvre le panneau d'étages (voir « Panneau joueur »).
- Étage réservé : public, ou Police, Pompier/SAMU, Mairie, Entreprise (+ grade minimum), comme les portes du mod Portes.
- Voyage groupé : tous les joueurs présents dans la cabine sont emmenés à l'étage choisi par l'un d'eux.

## Non-objectifs (non demandés, hors de la première version)

- Pas de péage ni de paiement pour utiliser l'ascenseur.
- Pas d'intégration redstone (la cabine ne se pilote pas par redstone).
- Pas de transport d'entités non joueurs ni de blocs posés (le but est de transporter des joueurs, y compris un patient sur un lit déjà dans la cabine si c'est un joueur).

## Anti-objectifs (ce qui rendrait le mod raté même s'il « marche »)

- Un joueur sans le bon rôle ne doit jamais pouvoir **choisir** ni **appeler** un étage réservé. Seul le joueur qui choisit l'étage est vérifié.
- Un joueur dans la cabine ne doit jamais se retrouver bloqué dans un mur, tomber dans le vide, prendre des dégâts de chute ni être expulsé pour « vol » (anti-fly du serveur).
- Casser ou détruire la cabine, les boutons ou la gaine par accident ou par grief : protégé pour les non-OP, comme DoorProtection du mod Portes (choix à confirmer).

## Décisions prises avec Tarkyo

1. Vraie cabine qui se déplace, pas de téléportation.
2. Installation : un admin pose la cabine, puis la règle (nombre et positions des étages).
3. Rôles par étage : police, pompiers/SAMU, entreprise (« etc. » : j'ai ajouté Mairie, voir plus bas).
4. Panneau joueur : clavier de boutons ronds (variante B), avec une infobulle au survol qui donne le nom de l'étage et le rôle requis (comme la liste A).
5. Bouton d'appel à chaque étage, posé par l'admin à côté de la porte.
6. Tailles : 1×1, 2×2, 2×4 pour passer un lit d'hôpital ; Tarkyo avait cité 1, 2 et 4 au départ, donc je garde le 4×4.
7. Voyage groupé : seul celui qui choisit l'étage est vérifié, tous ceux qui sont dans la cabine sont emmenés. Tarkyo a confirmé qu'il ne veut pas vérifier chaque passager.

## Mes choix (à vérifier par Tarkyo)

- Forge 1.20.1 (47.4.10), Java 17, même structure Gradle que minenorth-portes.
- Identifiant du mod : `minenorthascenseur`, paquetage `fr.minenorth.ascenseur`, nom affiché « MineNorth Ascenseur ».
- Dépendance obligatoire à `minenorthapi` (police via `MineNorth.police()`). Secours, Entreprises et Mairie sont reliés **par réflexion** comme dans Portes (`SecoursCompat`, `EntrepriseCompat`, `MairieCompat`) : le mod fonctionne même si l'un d'eux est absent, et dans ce cas son rôle n'ouvre rien.
- Règle des rôles identique à `OwnerDoorManager.canOpen` du mod Portes (y compris les nœuds de permission Forge `grade.police`, `grade.pompier`, `grade.medical`, `grade.mairie` et les OP qui passent toujours).
- Entreprise : stocké comme dans Portes, `entreprise:<id>:<gradeMin>` (-1 patron seul, 0 grade le plus haut, 99 tous les employés).
- Interface : reprendre `MineNorthStyle` et `MineNorthButton` (chaque mod embarque sa copie).
- Seuls les OP (niveau 2) règlent un ascenseur.
- Un étage interdit apparaît éteint dans le panneau et ne peut pas être choisi.
- Pas de limite d'étages choisie par Tarkyo : je propose 2 à 32.
- Les portes de la cabine s'ouvrent et se ferment automatiquement à l'arrivée.

## Précisions après relecture

Voyage et appel (décision de Tarkyo) :
- Le voyage groupé est voulu : seul le joueur qui choisit l'étage est vérifié, les autres passagers sont emmenés sans contrôle. Un civil peut donc arriver à un étage réservé s'il est dans la cabine d'un policier ; ce n'est pas un défaut. La phrase « jamais pouvoir choisir ni appeler » vise la **sélection et l'appel**, pas le transport.
- Le bouton d'appel d'un étage réservé est inerte pour un joueur qui n'a pas le rôle (message discret, comme les portes de Portes).

Géométrie (mes choix, à vérifier) :
- L'admin construit la gaine (colonne vide) avec ses propres blocs. Le mod ne creuse ni ne construit rien.
- Le mod fournit un **bloc cabine** que l'admin pose au sol de l'étage de départ (c'est l'ancre, coin au sol). Le menu de réglage donne ensuite la taille ; le mod affiche la cabine (sol, parois, plafond, portes) générée à partir de la taille choisie.
- Chaque étage a un **bloc bouton d'appel** posé par l'admin à côté de l'ouverture, relié à l'ascenseur et à un numéro d'étage dans le menu.
- Comme une gaine ouverte est un risque de chute, chaque étage a une **porte d'étage** fournie par le mod, qui est fermée tant que la cabine n'est pas là et s'ouvre avec la cabine.
- Protection (casse, explosion) : uniquement les blocs du mod (cabine, boutons, portes d'étage), pour les non-OP. Pas de dépendance au mod Portes, code propre et court.

File d'attente (mon choix) : les appels sont mis en file dans l'ordre ; pendant un trajet, un joueur dans la cabine ne peut pas changer d'étage, il peut choisir au prochain arrêt.

Code existant à lire avant de planifier (dans le dossier parent `Mod MineNorthRP`) :
- `minenorth-portes/src/main/java/fr/minenorth/drill/door/` : `OwnerDoorManager.canOpen`, `PoliceCompat`, `SecoursCompat` (appelle `fr.minenorth.secours.api.SecoursApi.isSecours`), `MairieCompat` (appelle `fr.minenorth.etat.api.EtatApi.isMairieStaff`), `EntrepriseCompat` (appelle `fr.minenorth.entreprises.api.EntrepriseApi`), `DoorProtection`.
- `minenorth-api` : `MineNorth.police()` et les autres services.
- Pour le style : `client/MineNorthStyle.java` et `client/MineNorthButton.java` dans Portes.

## Panneau joueur

Clavier de boutons ronds, du bas vers le haut, un par étage. Le bouton de l'étage actuel est mis en évidence. Étage interdit : bouton éteint. Au survol : infobulle « 3 · Garde à vue · Police ». Exemple d'hôpital : 0 Accueil (public), 1 Urgences (public), 2 Bloc opératoire (pompier/SAMU), 3 Garde à vue (police), 4 Direction (entreprise).

## Menu de réglage (admin)

Clic droit sur la cabine ouvre : nom de l'ascenseur, taille de cabine, nombre d'étages, et pour chaque étage : nom, hauteur (avec un bouton « ma position = hauteur de l'étage »), rôle autorisé. Boutons : ajouter un étage, supprimer.

## Laissé au constructeur

- Technique d'affichage et de déplacement de la cabine (entité, blocs mobiles…), du moment qu'elle est fluide, sans dégâts pour les joueurs et sans expulsion anti-fly.
- Orientation et placement du rectangle pour les cabines non carrées (2×4).
- Comportement en cas de gaine obstruée, de chunk non chargé ou d'arrêt du serveur en plein trajet (la cabine doit reprendre un état sain).
- File d'attente quand plusieurs joueurs appellent la cabine.
- Format de sauvegarde des ascenseurs, commandes de gestion et fichiers de configuration, dans le style des autres mods.
