# MineNorth Ascenseur

Mod Forge 1.20.1 pour le serveur MineNorthRP : de vrais ascenseurs avec une cabine mobile, des portes d'étage,
des boutons d'appel et des étages réservés à certains rôles (police, pompiers/SAMU, mairie, entreprise).
Même charte et mêmes règles de rôles que le mod Portes.

## Prérequis

- Minecraft 1.20.1, Forge 47.x.
- `minenorth_api` (obligatoire, jar `minenorth_api-1.0.0.jar`).
- Optionnels, reliés par réflexion (le mod fonctionne sans, le rôle correspondant n'ouvre alors rien) :
  Secours (pompiers/SAMU), Mairie (Etat), Entreprises. La police passe par `minenorth_api`.

## Installation

1. Construire `minenorth-api` d'abord, puis ce mod : `./gradlew build`.
2. Déposer `build/libs/minenorth-ascenseur-1.0.0.jar` (et `minenorth_api`) dans le dossier `mods/` du serveur et des clients.
3. Au premier démarrage, `config/Minenorth-ascenseur/ascenseur.toml` est créé avec les valeurs par défaut.

## Construire un ascenseur (administrateur, OP niveau 2)

1. Construire la gaine : un puits libre sur toute la hauteur, aux dimensions de la cabine (1x1, 1x2, 2x2, 2x4 ou 4x4 ; en 1x2 et 2x4 la porte est sur le petit côté).
2. Poser le bloc **Cabine** au bas de la gaine (case avant gauche de la cabine, vue de l'intérieur vers la porte), en
   regardant vers la gaine. Seul un OP peut en poser : message « Ascenseur créé ». Le bloc devient une petite plaque
   au sol (repère d'ancre) ; la cabine, avec son panneau de commande, est dessinée par le mod et suit les trajets.
   Le côté de la porte est celui d'où vous regardiez.
3. **Clic droit en étant accroupi, main vide**, sur la cabine (ou sur la plaque) : le panneau d'administration s'ouvre. Régler le nom,
   la taille de cabine, puis les étages (nom, hauteur, accès) ; le bouton « ma position » reprend votre hauteur.
   Enregistrer. Un ascenseur compte de 2 à 32 étages.
4. À chaque étage, poser **une seule Porte d'étage** dans la rangée située juste devant le côté porte de la cabine, à
   la hauteur de l'étage : toute l'ouverture (largeur de la cabine × 3 de haut) est remplie de portes plaquées sur la
   façade de la cabine, quelle que soit la direction du regard. Casser une de ces portes retire toute l'ouverture.
5. Poser un **Bouton d'appel** à côté de chaque porte (à hauteur d'yeux, jusqu'à 2 blocs au-dessus de la porte).
   Message « Bouton relié ». Son voyant s'allume tant qu'un appel pour cet étage est en attente ou que la cabine
   arrive, et s'éteint à l'ouverture des portes.
6. Pour supprimer un ascenseur : en **créatif et accroupi, clic gauche sur la cabine** (OP), ou casser la plaque
   d'ancre quand la cabine n'est pas dessus, ou `/ascenseur remove <nom>`. Un clic gauche sans être accroupi ne fait
   rien (les passagers peuvent taper dans la cabine). Les passagers sont déposés
   sur le palier de l'étage le plus proche.

### Afficheur d'étage

Poser un **Afficheur d'étage** (OP) dans la rangée devant la cabine, 1 à 3 blocs au-dessus du haut d'une ouverture : il
se tourne vers le palier et affiche l'étage actuel de la cabine (0 en bas, comme le panneau), avec une flèche ↑ ou ↓
pendant un trajet, et « — » si l'ascenseur est indisponible ou bloqué. Le même étage s'affiche sur l'écran du panneau
de commande dans la cabine. Retirer un afficheur ne touche pas à l'ascenseur.

**Liaison manuelle** : un OP accroupi, main vide, qui fait un clic droit sur un afficheur, un bouton d'appel ou une
porte d'étage le relie à l'ascenseur le plus proche (24 blocs au plus) et à l'étage de hauteur la plus proche (6 blocs
au plus) ; une liaison existante est remplacée. Un afficheur non relié indique « non lié ».

### Personnalisation (panneau d'administration)

- **Couleur** : une pastille parmi les 16 teintes de colorant (ou la première, l'aspect clair d'origine) ; elle colore
  les parois, les vantaux de la cabine et les portes d'étage.
- **Vitres** : N, E, S, O rendent ce côté vitré (verre teinté de la couleur) ; on voit au travers mais on ne le traverse
  pas. Le côté de la porte ne peut pas être vitré.

### Accès par étage

| Valeur | Qui peut choisir ou appeler l'étage |
|---|---|
| `PUBLIC` | tout le monde |
| `POLICE` | policiers (`minenorth_api`), nœud `grade.police`, OP |
| `POMPIER` | pompiers/SAMU (Secours), nœud `grade.pompier`, OP |
| `MAIRIE` | personnel de la mairie, nœud `grade.mairie`, OP |
| `entreprise:<id>:<grade>` | employés de l'entreprise `<id>` dont le grade permet l'accès (voir ci-dessous), OP |

Nœuds de permission : ils sont enregistrés sous l'espace de noms du mod, `minenorthascenseur.grade.police`,
`minenorthascenseur.grade.pompier`, `minenorthascenseur.grade.medical` et `minenorthascenseur.grade.mairie`, distincts des
nœuds `minenorthportes.*` du mod Portes : un plugin de permissions doit les accorder séparément. Les rôles vérifiés par
les API (police, Secours, Mairie, Entreprises) fonctionnent sans aucun nœud.

Grade minimum : `-1` patron seul, `0` grade le plus haut, `99` tous les employés. Un étage interdit apparaît éteint
dans le panneau, avec une infobulle (nom et rôle requis). Seul le joueur qui choisit l'étage est contrôlé : les autres
passagers sont emmenés (voyage groupé voulu). Le bouton d'appel d'un étage réservé est inerte sans le rôle.

## Protection

- Un non-OP ne peut casser ni la cabine, ni un bouton, ni une porte d'étage (« Cet ascenseur est protégé. »).
- Les explosions épargnent ces blocs et le plancher invisible de la cabine.
- Les pistons ne déplacent aucun de ces blocs.
- Les liquides ne remplacent aucun de ces blocs (ni le repère d'ancre, ni les parois invisibles).
- Un ascenseur n'est supprimé que par un OP : casse du repère d'ancre, clic gauche accroupi en créatif sur la cabine,
  ou `/ascenseur remove`. Tout autre retrait du repère (`/setblock`, mod tiers) laisse l'ascenseur intact ; reposer le
  repère au même endroit le reprend.
- Deux gaines ne peuvent pas se chevaucher (pose ou changement de taille refusés), et chaque étage doit tenir dans les
  limites de construction du monde.
- Un objet posé dans la gaine pendant un trajet fait revenir la cabine à l'étage précédent (« Passage obstrué »).

## Commandes (niveau 2)

| Commande | Effet |
|---|---|
| `/ascenseur list` | liste : nom, identifiant court, dimension, position, taille, nombre d'étages, actif ou non |
| `/ascenseur remove <nom>` | supprime un ascenseur par son nom ; si plusieurs correspondent, indiquer le début de l'identifiant (8 caractères de `list`) |
| `/ascenseur reload` | relit `ascenseur.toml` |

`remove` retire l'ascenseur du registre et libère la cabine ; le bloc console reste en place s'il est encore posé.

## Configuration

Fichier `config/Minenorth-ascenseur/ascenseur.toml` :

| Clé | Défaut | Bornes | Rôle |
|---|---|---|---|
| `vitesse_blocs_par_seconde` | `4.0` | 0.5 à 12.0 | vitesse de la cabine |
| `duree_portes_secondes` | `2.0` | 0.5 à 10.0 | ouverture ou fermeture des portes |

Une valeur absente ou invalide revient à la valeur par défaut ; une valeur hors bornes est ramenée à la borne.
`/ascenseur reload` s'applique aux ascenseurs **activés ensuite** (redémarrage du serveur, ou modification de
l'ascenseur dans le panneau d'administration si sa géométrie change) ; un ascenseur déjà actif garde ses valeurs.

## Limites connues

- Non testé en client au moment de la livraison du code : appliquer la liste de contrôle ci-dessous.
- Un OP qui garde un objet en main n'ouvre pas le panneau d'administration en étant accroupi (comportement vanilla) : main vide.
- Une cabine bloquée dans les deux sens reste en trajet jusqu'à ce que la gaine soit dégagée.
- La détection d'obstruction et le relink des portes ne voient que les chunks chargés ; le nettoyage de l'ancienne gaine
  est fait dès qu'elle est rechargée (environ 1 s).
- Les montures ne sont pas transportées.
- Après un changement de taille, les portes laissées ouvertes dans un chunk non chargé sont refermées au rechargement.
- La cabine capte les clics de ceux qui sont dedans : on ne peut pas frapper ni utiliser un objet sur un autre joueur
  dans la cabine.
- Un joueur porté ou monté (menotté, sur un brancard ou une monture entité) est descendu de son support au départ : seul
  le joueur voyage.
- Un joueur qui se reconnecte au-dessus du vide d'une gaine est déposé sur le palier de l'étage le plus proche ; un
  joueur dans la gaine qui clique la cabine l'appelle à l'étage le plus proche.
- Capteur de porte : quelqu'un dans l'embrasure fait rouvrir les portes (3 fois au plus par départ), puis il est
  déposé sur le palier.

## Liste de contrôle en jeu (un OP et un non-OP)

1. Un non-OP pose une cabine : refusé, message en barre d'action, objet conservé.
2. Un OP pose une cabine face à la gaine : « Ascenseur créé » ; le bloc est une petite plaque au sol, la cabine (parois,
   panneau de commande) est dessinée et solide ; accroupi, main vide, clic droit : le panneau d'administration s'ouvre.
3. Retirer le repère par `/setblock` puis le reposer : « Repère replacé » (ascenseur repris) ; une gaine qui chevauche : refusée.
4. Régler 3 étages (0 / +4 / +8), poser une porte par étage : toute l'ouverture se remplit ; les boutons : « Bouton relié ».
   Porte ouverte : ouverture dégagée, un seul seuil fin au sol ; porte fermée : un panneau gris plein et vertical,
   plaqué sur la façade de la cabine (aucune barre horizontale en travers).
5. Une porte à un étage sans cabine est fermée (impossible à franchir ou à sauter) ; à l'étage de la cabine elle est ouverte.
6. Un bouton d'appel amène la cabine, les portes s'ouvrent à l'arrivée et se ferment avant le départ ; trajet de 0 à 2
   avec 2 joueurs : arrivée sans dégâts ni expulsion.
7. Étage POLICE : bouton d'appel inerte pour un joueur sans le rôle (« Cet étage est réservé. »).
8. Poser un bloc dans la gaine en plein trajet : « Passage obstrué », retour à l'étage de départ, personne dans un bloc ;
   bloquer aussi le retour : les passagers sont posés sur le palier.
9. Enregistrement admin qui retire un étage portant une porte : la porte indique « non reliée » ; la remettre et enregistrer : elle est reliée.
10. Tailles 2x2, 2x4, 4x4 dans les quatre orientations : empreinte, plancher invisible, rendu, portes côté porte, rangée de palier.
11. Casser la cabine avec des joueurs dedans : déposés sur le palier, portes fermées, plancher invisible disparu.
12. Idem avec la gaine déchargée, puis y revenir : plus de plancher ni de porte ouverte (nettoyage en 1 s environ).
13. `/stop` en plein trajet puis redémarrage : la cabine est à un étage et les portes sont cohérentes.
14. Protection : un non-OP ne casse ni cabine, ni bouton, ni porte ; un TNT les épargne ; un OP casse la cabine en plein trajet sans blocage.
15. `/ascenseur list`, `/ascenseur remove <nom>` (avec un nom ambigu : demande l'identifiant), `/ascenseur reload`.
16. Sol de la cabine au rez-de-chaussée : uni, sans scintillement vert ni quadrillage.
17. Couleur et vitres : choisir une teinte et deux côtés vitrés, enregistrer ; parois, vantaux et portes d'étage prennent
    la teinte, les côtés vitrés sont transparents mais infranchissables ; le côté porte n'est pas proposé.
18. Taille 1x2 dans les quatre orientations : porte sur le petit côté, rendu et parois corrects.
19. Bouton d'appel : voyant éteint au repos, allumé après un appel, éteint à l'ouverture des portes.
20. Afficheur d'étage posé au-dessus d'une porte : étage actuel, flèche pendant le trajet, « — » ascenseur supprimé ou
    bloqué ; le même étage sur l'écran du panneau dans la cabine.
21. Liaison manuelle : afficheur posé loin d'une porte (« non lié »), OP accroupi main vide clic droit : « Lié à … » et
    l'étage s'affiche ; trop loin : « Aucun ascenseur à moins de 24 blocs » ; un non-OP accroupi : rien.

## Exemple : l'hôpital (5 étages, cabine 2x4)

| Étage | Nom | Accès |
|---|---|---|
| 0 | Accueil | `PUBLIC` |
| 1 | Urgences | `PUBLIC` |
| 2 | Bloc opératoire | `POMPIER` |
| 3 | Garde à vue | `POLICE` |
| 4 | Direction | `entreprise:<id>:1` |

Vérifications attendues : un civil voit les étages 2, 3 et 4 éteints avec infobulle ; un pompier accède au Bloc
opératoire ; un employé de grade 1 (ou mieux) accède à la Direction, un employé de grade 5 non ; un policier accède à la
Garde à vue ; un OP accède partout.
