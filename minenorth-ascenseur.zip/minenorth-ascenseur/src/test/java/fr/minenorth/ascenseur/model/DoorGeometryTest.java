package fr.minenorth.ascenseur.model;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

class DoorGeometryTest {
    /** facing (fx, fz) -> panel side, panel rectangle (px), right-leaf slide. */
    private static final int[][][] TABLE = {
            // north: landing at z-1, panel on its south edge, flush with the cabin front z = minZ
            {{0, -1}, {0, 1}, {0, 14, 16, 16}, {1, 0}},
            // east: landing at x+1, panel on its west edge
            {{1, 0}, {-1, 0}, {0, 0, 2, 16}, {0, 1}},
            // south: landing at z+1, panel on its north edge
            {{0, 1}, {0, -1}, {0, 0, 16, 2}, {-1, 0}},
            // west: landing at x-1, panel on its east edge
            {{-1, 0}, {1, 0}, {14, 0, 16, 16}, {0, -1}},
    };

    @Test
    void allFourFacings() {
        for (int[][] row : TABLE) {
            int fx = row[0][0];
            int fz = row[0][1];
            int[] side = DoorGeometry.panelSide(fx, fz);
            assertArrayEquals(row[1], side);
            assertArrayEquals(row[2], DoorGeometry.panelRectPx(side[0], side[1]));
            assertArrayEquals(row[3], DoorGeometry.rightLeafSlide(fx, fz));
        }
    }

    @Test
    void panelSitsOnTheCabinFrontPlane() {
        // The panel edge (in world coordinates) equals the footprint edge on the door side.
        for (int[][] row : TABLE) {
            int fx = row[0][0];
            int fz = row[0][1];
            CabinFootprint fp = CabinFootprint.of(10, 20, CabinSize.S2X2, fx, fz);
            int cx = fp.cellX(0, -1);
            int cz = fp.cellZ(0, -1);
            int[] side = DoorGeometry.panelSide(fx, fz);
            int[] r = DoorGeometry.panelRectPx(side[0], side[1]);
            double[] d = fp.doorway(0.0); // zero-depth strip = the front plane
            if (fx == 0) {
                double plane = d[1];
                double panelFace = side[1] > 0 ? cz + r[3] / 16.0 : cz + r[1] / 16.0;
                assertEquals(plane, panelFace, 1e-9);
            } else {
                double plane = d[0];
                double panelFace = side[0] > 0 ? cx + r[2] / 16.0 : cx + r[0] / 16.0;
                assertEquals(plane, panelFace, 1e-9);
            }
        }
    }

    @Test
    void onlyTheBottomCellIsAThreshold() {
        assertTrue(DoorGeometry.isThreshold(64, 64));
        assertFalse(DoorGeometry.isThreshold(64, 65));
        assertFalse(DoorGeometry.isThreshold(64, 66));
    }
}
