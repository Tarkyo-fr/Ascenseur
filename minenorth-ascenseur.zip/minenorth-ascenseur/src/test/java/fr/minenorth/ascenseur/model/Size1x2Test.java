package fr.minenorth.ascenseur.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

class Size1x2Test {
    /** facing, then expected minX, maxX, minZ, maxZ, landing x, landing z. */
    private static final int[][] TABLE = {
            {0, -1, 10, 11, 20, 22, 10, 19},
            {1, 0, 9, 11, 20, 21, 11, 20},
            {0, 1, 10, 11, 19, 21, 10, 21},
            {-1, 0, 10, 12, 20, 21, 9, 20},
    };

    @Test
    void parsesAndHasOneByTwoCells() {
        assertEquals(CabinSize.S1X2, CabinSize.parse("1x2").orElseThrow());
        assertEquals(1, CabinSize.S1X2.width());
        assertEquals(2, CabinSize.S1X2.depth());
    }

    @Test
    void footprintLandingAndWallsInAllFourFacings() {
        for (int[] r : TABLE) {
            CabinFootprint fp = CabinFootprint.of(10, 20, CabinSize.S1X2, r[0], r[1]);
            assertEquals(r[2], fp.minX());
            assertEquals(r[3], fp.maxX());
            assertEquals(r[4], fp.minZ());
            assertEquals(r[5], fp.maxZ());
            assertTrue(FloorLinking.inLandingRow(fp, r[6], r[7]));
            assertEquals(CabinFootprint.INTERIOR_HEIGHT, FloorLinking.openingCells(fp, 64).size());
            int door = CabinWalls.doorSide(fp);
            int all = CabinWalls.NORTH | CabinWalls.EAST | CabinWalls.SOUTH | CabinWalls.WEST;
            // Anchor cell: walled on both long sides, open on the door side.
            int anchor = CabinWalls.sides(fp, 10, 20);
            assertEquals(0, anchor & door);
            int back = CabinWalls.sides(fp, fp.cellX(0, 1), fp.cellZ(0, 1));
            assertEquals(all & ~door, back);
        }
    }
}
