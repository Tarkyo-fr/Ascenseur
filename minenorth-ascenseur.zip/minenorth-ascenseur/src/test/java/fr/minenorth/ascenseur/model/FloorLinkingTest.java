package fr.minenorth.ascenseur.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.junit.jupiter.api.Test;

class FloorLinkingTest {
    private static final UUID A = new UUID(0, 1);
    private static final UUID B = new UUID(0, 2);
    private static final int[] FLOORS = {64, 70, 76};

    /** 2x2 anchored at (10, 20), door facing north: landing row is z = 19, x = 10..11. */
    private static FloorLinking.Shaft northShaft() {
        return new FloorLinking.Shaft(A, CabinFootprint.of(10, 20, CabinSize.S2X2, 0, -1), FLOORS);
    }

    @Test
    void floorForBlockYCoversTheOpening() {
        assertEquals(0, FloorLinking.floorForBlockY(FLOORS, 64));
        assertEquals(0, FloorLinking.floorForBlockY(FLOORS, 66));
        assertEquals(-1, FloorLinking.floorForBlockY(FLOORS, 67));
        assertEquals(1, FloorLinking.floorForBlockY(FLOORS, 70));
        assertEquals(-1, FloorLinking.floorForBlockY(FLOORS, 63));
        assertEquals(2, FloorLinking.floorForBlockY(FLOORS, 78));
        assertEquals(-1, FloorLinking.floorForBlockY(FLOORS, 79));
    }

    @Test
    void closeFloorsPreferTheHigherOne() {
        int[] ys = {64, 66};
        assertEquals(0, FloorLinking.floorForBlockY(ys, 65));
        assertEquals(1, FloorLinking.floorForBlockY(ys, 66));
    }

    @Test
    void landingRowIsInFrontOfTheDoor() {
        CabinFootprint fp = northShaft().footprint();
        assertTrue(FloorLinking.inLandingRow(fp, 10, 19));
        assertTrue(FloorLinking.inLandingRow(fp, 11, 19));
        assertFalse(FloorLinking.inLandingRow(fp, 12, 19));
        assertFalse(FloorLinking.inLandingRow(fp, 10, 20)); // inside the cabin
        assertFalse(FloorLinking.inLandingRow(fp, 10, 22)); // behind the cabin
    }

    @Test
    void landingRowFollowsOrientationFor2x4() {
        // Facing east: width runs south (+z), depth runs west (-x); landing row is x = 11.
        CabinFootprint fp = CabinFootprint.of(10, 20, CabinSize.S2X4, 1, 0);
        assertTrue(FloorLinking.inLandingRow(fp, 11, 20));
        assertTrue(FloorLinking.inLandingRow(fp, 11, 21));
        assertFalse(FloorLinking.inLandingRow(fp, 11, 19));
        assertFalse(FloorLinking.inLandingRow(fp, 9, 20));
    }

    @Test
    void doorLinksByGeometry() {
        List<FloorLinking.Shaft> shafts = List.of(northShaft());
        assertEquals(Optional.of(new FloorLinking.Link(A, 1)), FloorLinking.byGeometry(shafts, 11, 70, 19));
        assertEquals(Optional.of(new FloorLinking.Link(A, 1)), FloorLinking.byGeometry(shafts, 11, 72, 19));
        assertEquals(Optional.empty(), FloorLinking.byGeometry(shafts, 11, 73, 19));
        assertEquals(Optional.empty(), FloorLinking.byGeometry(shafts, 13, 70, 19));
    }

    @Test
    void doorTakesFirstMatchingShaft() {
        FloorLinking.Shaft other = new FloorLinking.Shaft(B, CabinFootprint.of(30, 20, CabinSize.S1X1, 0, -1), FLOORS);
        List<FloorLinking.Shaft> shafts = List.of(other, northShaft());
        assertEquals(Optional.of(new FloorLinking.Link(A, 0)), FloorLinking.byGeometry(shafts, 10, 64, 19));
        assertEquals(Optional.of(new FloorLinking.Link(B, 2)), FloorLinking.byGeometry(shafts, 30, 76, 19));
    }

    @Test
    void buttonCopiesNearestDoor() {
        FloorLinking.LinkedDoor far = new FloorLinking.LinkedDoor(10, 70, 19, new FloorLinking.Link(A, 1));
        FloorLinking.LinkedDoor near = new FloorLinking.LinkedDoor(11, 70, 19, new FloorLinking.Link(B, 1));
        Optional<FloorLinking.Link> link = FloorLinking.forButton(List.of(far, near), List.of(), 13, 71, 19);
        assertEquals(Optional.of(new FloorLinking.Link(B, 1)), link);
    }

    @Test
    void buttonIgnoresDoorsTooFarOrAbove() {
        FloorLinking.LinkedDoor tooFar = new FloorLinking.LinkedDoor(10, 70, 19, new FloorLinking.Link(A, 1));
        FloorLinking.LinkedDoor above = new FloorLinking.LinkedDoor(13, 72, 19, new FloorLinking.Link(A, 1));
        FloorLinking.LinkedDoor tooLow = new FloorLinking.LinkedDoor(13, 67, 19, new FloorLinking.Link(A, 0));
        assertEquals(Optional.empty(), FloorLinking.forButton(List.of(tooFar, above, tooLow), List.of(), 13, 70, 19));
    }

    @Test
    void buttonFallsBackToGeometry() {
        List<FloorLinking.Shaft> shafts = List.of(northShaft());
        assertEquals(Optional.of(new FloorLinking.Link(A, 2)), FloorLinking.forButton(List.of(), shafts, 10, 77, 19));
        assertEquals(Optional.empty(), FloorLinking.forButton(List.of(), shafts, 14, 77, 19));
    }
}
