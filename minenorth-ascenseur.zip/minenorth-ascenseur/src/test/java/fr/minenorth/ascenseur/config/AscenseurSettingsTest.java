package fr.minenorth.ascenseur.config;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;
import org.junit.jupiter.api.Test;

class AscenseurSettingsTest {
    @Test
    void defaultsWhenEmptyOrNull() {
        assertEquals(AscenseurSettings.DEFAULTS, AscenseurSettings.parse(List.of()));
        assertEquals(AscenseurSettings.DEFAULTS, AscenseurSettings.parse(null));
    }

    @Test
    void parsesValuesAndComments() {
        AscenseurSettings s = AscenseurSettings.parse(List.of(
                "# commentaire", "vitesse_blocs_par_seconde = 6.0  # rapide", "duree_portes_secondes=1.5"));
        assertEquals(6.0, s.vitesseBlocsParSeconde());
        assertEquals(1.5, s.dureePortesSecondes());
        assertEquals(0.3, s.blocksPerTick(), 1e-9);
        assertEquals(30, s.doorTicks());
    }

    @Test
    void clampsOutOfRange() {
        AscenseurSettings s = AscenseurSettings.parse(List.of("vitesse_blocs_par_seconde = 100", "duree_portes_secondes = 0"));
        assertEquals(12.0, s.vitesseBlocsParSeconde());
        assertEquals(0.5, s.dureePortesSecondes());
        AscenseurSettings t = AscenseurSettings.parse(List.of("vitesse_blocs_par_seconde = -3", "duree_portes_secondes = 99"));
        assertEquals(0.5, t.vitesseBlocsParSeconde());
        assertEquals(10.0, t.dureePortesSecondes());
    }

    @Test
    void badValuesFallBackToDefaults() {
        AscenseurSettings s = AscenseurSettings.parse(List.of(
                "vitesse_blocs_par_seconde = abc", "duree_portes_secondes = NaN", "n'importe quoi", "= 3"));
        assertEquals(AscenseurSettings.DEFAULTS, s);
    }
}
