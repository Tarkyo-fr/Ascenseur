package fr.minenorth.ascenseur.model;

import static fr.minenorth.ascenseur.model.CabinWalls.EAST;
import static fr.minenorth.ascenseur.model.CabinWalls.NORTH;
import static fr.minenorth.ascenseur.model.CabinWalls.SOUTH;
import static fr.minenorth.ascenseur.model.CabinWalls.WEST;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;
import org.junit.jupiter.api.Test;

class CabinWallsTest {
    @Test
    void oneByOneIsOpenOnTheDoorSideOnly() {
        CabinFootprint fp = CabinFootprint.of(0, 0, CabinSize.S1X1, 0, -1);
        assertEquals(EAST | SOUTH | WEST, CabinWalls.sides(fp, 0, 0));
        assertEquals(0, CabinWalls.sides(fp, 1, 0));
    }

    @Test
    void twoByTwoNorth() {
        CabinFootprint fp = CabinFootprint.of(10, 20, CabinSize.S2X2, 0, -1);
        assertEquals(WEST, CabinWalls.sides(fp, 10, 20));
        assertEquals(EAST, CabinWalls.sides(fp, 11, 20));
        assertEquals(WEST | SOUTH, CabinWalls.sides(fp, 10, 21));
        assertEquals(EAST | SOUTH, CabinWalls.sides(fp, 11, 21));
    }

    @Test
    void twoByFourEastHasDoorOnEast() {
        CabinFootprint fp = CabinFootprint.of(10, 20, CabinSize.S2X4, 1, 0);
        assertEquals(EAST, CabinWalls.doorSide(fp));
        assertEquals(NORTH, CabinWalls.sides(fp, 10, 20));
        assertEquals(SOUTH, CabinWalls.sides(fp, 10, 21));
        assertEquals(WEST | SOUTH, CabinWalls.sides(fp, 7, 21));
        assertEquals(NORTH, CabinWalls.sides(fp, 8, 20));
    }

    @Test
    void fourByFourWestInteriorCellsHaveNoWall() {
        CabinFootprint fp = CabinFootprint.of(0, 0, CabinSize.S4X4, -1, 0);
        assertEquals(WEST, CabinWalls.doorSide(fp));
        assertEquals(0, CabinWalls.sides(fp, fp.minX() + 1, fp.minZ() + 1));
        assertEquals(NORTH, CabinWalls.sides(fp, fp.minX(), fp.minZ()));
        assertEquals(EAST | SOUTH, CabinWalls.sides(fp, fp.maxX() - 1, fp.maxZ() - 1));
    }

    @Test
    void openingCellsCoverWidthTimesInteriorHeight() {
        CabinFootprint fp = CabinFootprint.of(10, 20, CabinSize.S2X2, 0, -1);
        List<int[]> cells = FloorLinking.openingCells(fp, 64);
        assertEquals(2 * CabinFootprint.INTERIOR_HEIGHT, cells.size());
        for (int[] c : cells) {
            assertEquals(19, c[2]);
            assertEquals(true, c[0] == 10 || c[0] == 11);
            assertEquals(true, c[1] >= 64 && c[1] < 64 + CabinFootprint.INTERIOR_HEIGHT);
        }
    }
}
