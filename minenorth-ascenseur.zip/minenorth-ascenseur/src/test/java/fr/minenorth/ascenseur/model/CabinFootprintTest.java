package fr.minenorth.ascenseur.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

class CabinFootprintTest {
    // Orientations (fx, fz) comme Direction de Minecraft.
    private static final int[] NORTH = {0, -1};
    private static final int[] SOUTH = {0, 1};
    private static final int[] WEST = {-1, 0};
    private static final int[] EAST = {1, 0};

    private static CabinFootprint of(int ax, int az, CabinSize size, int[] facing) {
        return CabinFootprint.of(ax, az, size, facing[0], facing[1]);
    }

    private static void assertBounds(CabinFootprint f, int minX, int maxX, int minZ, int maxZ) {
        assertEquals(minX, f.minX(), "minX");
        assertEquals(maxX, f.maxX(), "maxX");
        assertEquals(minZ, f.minZ(), "minZ");
        assertEquals(maxZ, f.maxZ(), "maxZ");
    }

    @Test
    void oneByOneIsTheAnchorCell() {
        CabinFootprint f = of(10, -5, CabinSize.S1X1, NORTH);
        assertBounds(f, 10, 11, -5, -4);
        assertEquals(10.5, f.centerX());
        assertEquals(-4.5, f.centerZ());
        assertTrue(f.containsXZ(10.5, -4.5));
        assertTrue(f.containsXZ(10.0, -5.0));
        assertFalse(f.containsXZ(11.0, -4.5));
        assertFalse(f.containsXZ(10.5, -5.01));
    }

    @Test
    void twoByTwoFacingNorthGoesEastAndSouth() {
        CabinFootprint f = of(0, 0, CabinSize.S2X2, NORTH);
        assertBounds(f, 0, 2, 0, 2);
    }

    @Test
    void fourByFourFacingSouthGoesWestAndNorth() {
        CabinFootprint f = of(0, 0, CabinSize.S4X4, SOUTH);
        assertBounds(f, -3, 1, -3, 1);
        assertEquals(4, f.spanX());
        assertEquals(4, f.spanZ());
    }

    @Test
    void twoByFourFacingNorth() {
        // largeur vers l'est (droite du nord), profondeur vers le sud (arrière)
        CabinFootprint f = of(0, 0, CabinSize.S2X4, NORTH);
        assertBounds(f, 0, 2, 0, 4);
        assertEquals(2, f.spanX());
        assertEquals(4, f.spanZ());
    }

    @Test
    void twoByFourFacingEast() {
        // largeur vers le sud, profondeur vers l'ouest
        CabinFootprint f = of(0, 0, CabinSize.S2X4, EAST);
        assertBounds(f, -3, 1, 0, 2);
        assertEquals(4, f.spanX());
        assertEquals(2, f.spanZ());
    }

    @Test
    void twoByFourFacingSouth() {
        // largeur vers l'ouest, profondeur vers le nord
        CabinFootprint f = of(0, 0, CabinSize.S2X4, SOUTH);
        assertBounds(f, -1, 1, -3, 1);
    }

    @Test
    void twoByFourFacingWest() {
        // largeur vers le nord, profondeur vers l'est
        CabinFootprint f = of(0, 0, CabinSize.S2X4, WEST);
        assertBounds(f, 0, 4, -1, 1);
    }

    @Test
    void cellsFollowRightAndBackAxes() {
        CabinFootprint f = of(5, 5, CabinSize.S2X4, EAST);
        assertEquals(5, f.cellX(0, 0));
        assertEquals(5, f.cellZ(0, 0));
        // à droite de l'est : le sud
        assertEquals(5, f.cellX(1, 0));
        assertEquals(6, f.cellZ(1, 0));
        // vers l'arrière de l'est : l'ouest
        assertEquals(2, f.cellX(0, 3));
        assertEquals(5, f.cellZ(0, 3));
        // palier devant la porte : une case vers l'est
        assertEquals(6, f.cellX(0, -1));
        assertEquals(5, f.cellZ(0, -1));
    }

    @Test
    void cellsOfFourByFourFacingWest() {
        // droite de l'ouest : le nord ; arrière : l'est
        CabinFootprint f = of(0, 0, CabinSize.S4X4, WEST);
        assertBounds(f, 0, 4, -3, 1);
        assertEquals(0, f.cellX(3, 0));
        assertEquals(-3, f.cellZ(3, 0));
        assertEquals(3, f.cellX(0, 3));
        assertEquals(0, f.cellZ(0, 3));
        assertEquals(-1, f.cellX(0, -1)); // palier à l'ouest
    }

    @Test
    void cellsOfTwoByTwoFacingSouth() {
        // droite du sud : l'ouest ; arrière : le nord
        CabinFootprint f = of(3, 3, CabinSize.S2X2, SOUTH);
        assertBounds(f, 2, 4, 2, 4);
        assertEquals(2, f.cellX(1, 1));
        assertEquals(2, f.cellZ(1, 1));
        assertEquals(4, f.cellZ(0, -1)); // palier au sud
    }

    @Test
    void containsExcludesMaxEdges() {
        CabinFootprint f = of(0, 0, CabinSize.S2X2, NORTH);
        assertTrue(f.containsXZ(0.0, 0.0));
        assertTrue(f.containsXZ(1.999, 1.999));
        assertFalse(f.containsXZ(2.0, 1.0));
        assertFalse(f.containsXZ(1.0, 2.0));
        assertFalse(f.containsXZ(-0.001, 1.0));
    }

    @Test
    void verticalToleranceAroundFloor() {
        CabinFootprint f = of(0, 0, CabinSize.S1X1, NORTH);
        assertTrue(f.contains(0.5, 64.0, 0.5, 64.0));
        assertTrue(f.contains(0.5, 63.5, 0.5, 64.0));
        assertFalse(f.contains(0.5, 63.4, 0.5, 64.0));
        assertTrue(f.contains(0.5, 65.5, 0.5, 64.0));
        assertFalse(f.contains(0.5, 65.6, 0.5, 64.0));
        assertFalse(f.contains(1.5, 64.0, 0.5, 64.0));
    }

    @Test
    void clampKeepsRiderInside() {
        CabinFootprint f = of(0, 0, CabinSize.S1X1, NORTH);
        assertEquals(0.3, f.clampX(-5.0, 0.3), 1e-9);
        assertEquals(0.5, f.clampX(0.5, 0.3), 1e-9);
        assertEquals(0.7, f.clampX(5.0, 0.3), 1e-9);
        assertEquals(0.5, f.clampZ(0.5, 0.3), 1e-9);
        // marge trop grande : le centre
        assertEquals(0.5, f.clampX(0.9, 0.6), 1e-9);
    }

    @Test
    void invalidFacingRejected() {
        assertThrows(IllegalArgumentException.class, () -> CabinFootprint.of(0, 0, CabinSize.S1X1, 1, 1));
        assertThrows(IllegalArgumentException.class, () -> CabinFootprint.of(0, 0, CabinSize.S1X1, 0, 0));
        assertThrows(IllegalArgumentException.class, () -> CabinFootprint.of(0, 0, null, 0, 1));
    }
}
