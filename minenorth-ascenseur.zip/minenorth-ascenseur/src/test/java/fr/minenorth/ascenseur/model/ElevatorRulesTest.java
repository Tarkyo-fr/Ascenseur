package fr.minenorth.ascenseur.model;

import static org.junit.jupiter.api.Assertions.*;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import org.junit.jupiter.api.Test;

class ElevatorRulesTest {

    static class FakeRoles implements Roles {
        boolean op, police;
        Set<String> nodes = new HashSet<>();

        public boolean isOp() { return op; }
        public boolean isPolice() { return police; }
        public boolean isSecours() { return false; }
        public boolean isMairie() { return false; }
        public boolean hasNode(String node) { return nodes.contains(node); }
        public boolean entrepriseExists(int id) { return false; }
        public boolean entrepriseCanOpen(int id, int minGrade) { return false; }
    }

    static Elevator elevator() {
        return new Elevator(UUID.randomUUID(), "Commissariat", CabinSize.values()[0], List.of(
                new Floor("Accueil", 64, "PUBLIC"),
                new Floor("Bureaux", 70, "PUBLIC"),
                new Floor("Garde à vue", 76, "POLICE")));
    }

    static TripController idleAt(int floor) {
        return new TripController(new int[] {64, 70, 76}, floor, 0.25, 10);
    }

    @Test
    void cannotSelectWhileMoving() {
        TripController t = idleAt(0);
        assertTrue(t.select(1));
        t.tick();
        assertNotEquals(TripController.Phase.IDLE, t.phase());
        assertFalse(ElevatorRules.canSelect(elevator(), 1, new FakeRoles(), true, t));
    }

    @Test
    void cannotSelectFromOutsideCabin() {
        assertFalse(ElevatorRules.canSelect(elevator(), 1, new FakeRoles(), false, idleAt(0)));
        assertTrue(ElevatorRules.canSelect(elevator(), 1, new FakeRoles(), true, idleAt(0)));
    }

    @Test
    void cannotSelectRestrictedFloorWithoutRole() {
        assertFalse(ElevatorRules.canSelect(elevator(), 2, new FakeRoles(), true, idleAt(0)));
        FakeRoles police = new FakeRoles();
        police.police = true;
        assertTrue(ElevatorRules.canSelect(elevator(), 2, police, true, idleAt(0)));
    }

    @Test
    void cannotSelectCurrentOrOutOfRangeFloor() {
        assertFalse(ElevatorRules.canSelect(elevator(), 0, new FakeRoles(), true, idleAt(0)));
        assertFalse(ElevatorRules.canSelect(elevator(), 3, new FakeRoles(), true, idleAt(0)));
        assertFalse(ElevatorRules.canSelect(elevator(), -1, new FakeRoles(), true, idleAt(0)));
    }

    @Test
    void callOnRestrictedFloorIsInertWithoutRole() {
        assertFalse(ElevatorRules.canCall(elevator(), 2, new FakeRoles()));
        assertTrue(ElevatorRules.canCall(elevator(), 1, new FakeRoles()));
        assertFalse(ElevatorRules.canCall(elevator(), 5, new FakeRoles()));
        FakeRoles police = new FakeRoles();
        police.police = true;
        assertTrue(ElevatorRules.canCall(elevator(), 2, police));
    }

    @Test
    void passengersWithoutRoleStillCarried() {
        // Seul le joueur qui choisit est vérifié : un passager sans rôle suit le voyage.
        FakeRoles chooser = new FakeRoles();
        chooser.police = true;
        assertTrue(ElevatorRules.canSelect(elevator(), 2, chooser, true, idleAt(0)));
    }
}
