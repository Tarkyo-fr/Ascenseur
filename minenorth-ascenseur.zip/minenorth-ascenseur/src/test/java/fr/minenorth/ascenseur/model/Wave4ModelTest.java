package fr.minenorth.ascenseur.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.junit.jupiter.api.Test;

class Wave4ModelTest {
    private static final int[] FLOORS = {64, 70, 76};

    @Test
    void styleValidation() {
        assertTrue(ElevatorStyle.validate(-1, 0).isEmpty());
        assertTrue(ElevatorStyle.validate(15, 15).isEmpty());
        assertFalse(ElevatorStyle.validate(16, 0).isEmpty());
        assertFalse(ElevatorStyle.validate(-2, 0).isEmpty());
        assertFalse(ElevatorStyle.validate(0, 16).isEmpty());
        assertThrows(IllegalArgumentException.class, () -> new ElevatorStyle(0, 32));
        assertEquals(ElevatorStyle.DEFAULT, ElevatorStyle.sanitize(99, 0));
        assertEquals(new ElevatorStyle(3, 5), ElevatorStyle.sanitize(3, 5 | 64));
    }

    @Test
    void glassNeverOnTheDoorSide() {
        ElevatorStyle all = new ElevatorStyle(2, ElevatorStyle.ALL_SIDES);
        int[][] facings = {{0, -1}, {1, 0}, {0, 1}, {-1, 0}};
        for (int[] f : facings) {
            CabinFootprint fp = CabinFootprint.of(0, 0, CabinSize.S2X2, f[0], f[1]);
            int door = CabinWalls.doorSide(fp);
            assertEquals(ElevatorStyle.ALL_SIDES & ~door, all.effectiveGlass(fp));
        }
    }

    @Test
    void indicatorDirectionAndText() {
        assertEquals(FloorIndicator.UP, FloorIndicator.direction(TripController.Phase.MOVING, 64.5, 70));
        assertEquals(FloorIndicator.DOWN, FloorIndicator.direction(TripController.Phase.MOVING, 64.5, 64));
        assertEquals(FloorIndicator.NONE, FloorIndicator.direction(TripController.Phase.IDLE, 64, 70));
        assertEquals("2 ↑", FloorIndicator.text(true, 2, FloorIndicator.UP));
        assertEquals("0", FloorIndicator.text(true, 0, FloorIndicator.NONE));
        assertEquals("—", FloorIndicator.text(false, 3, FloorIndicator.DOWN));
        for (int dir = -1; dir <= 1; dir++) {
            int packed = FloorIndicator.pack(true, 7, dir);
            assertEquals(7, FloorIndicator.packedFloor(packed));
            assertEquals(dir, FloorIndicator.packedDirection(packed));
        }
        assertEquals("—", FloorIndicator.text(FloorIndicator.pack(false, 1, 0)));
    }

    @Test
    void controllerDirectionAndServing() {
        TripController c = new TripController(FLOORS, 0, 1.0, 2);
        assertFalse(c.isServing(2));
        c.call(2);
        assertTrue(c.isServing(2));
        for (int i = 0; i < 100 && c.phase() != TripController.Phase.MOVING; i++) {
            c.tick();
        }
        assertEquals(FloorIndicator.UP, c.direction());
        assertTrue(c.isServing(2));
        for (int i = 0; i < 100 && c.phase() != TripController.Phase.IDLE; i++) {
            c.tick();
        }
        assertEquals(FloorIndicator.NONE, c.direction());
        assertFalse(c.isServing(2)); // arrived, doors open: light off
    }

    @Test
    void indicatorLinksAboveTheOpening() {
        UUID id = new UUID(0, 9);
        List<FloorLinking.Shaft> shafts = List.of(
                new FloorLinking.Shaft(id, CabinFootprint.of(10, 20, CabinSize.S1X2, 0, -1), FLOORS));
        // Opening of floor 0: y 64..66; indicator allowed at 67..69.
        assertEquals(Optional.empty(), FloorLinking.forIndicator(shafts, 10, 66, 19));
        assertEquals(Optional.of(new FloorLinking.Link(id, 0)), FloorLinking.forIndicator(shafts, 10, 67, 19));
        assertEquals(Optional.of(new FloorLinking.Link(id, 0)), FloorLinking.forIndicator(shafts, 10, 69, 19));
        assertEquals(Optional.of(new FloorLinking.Link(id, 1)), FloorLinking.forIndicator(shafts, 10, 73, 19));
        assertEquals(Optional.empty(), FloorLinking.forIndicator(shafts, 11, 67, 19));
    }
}
