package fr.minenorth.ascenseur.model;

import static org.junit.jupiter.api.Assertions.*;

import java.util.HashSet;
import java.util.Set;
import org.junit.jupiter.api.Test;

class FloorAccessTest {

    static class FakeRoles implements Roles {
        boolean op, police, secours, mairie, exists;
        Set<String> nodes = new HashSet<>();
        Set<String> opened = new HashSet<>();

        public boolean isOp() { return op; }
        public boolean isPolice() { return police; }
        public boolean isSecours() { return secours; }
        public boolean isMairie() { return mairie; }
        public boolean hasNode(String node) { return nodes.contains(node); }
        public boolean entrepriseExists(int id) { return exists; }
        public boolean entrepriseCanOpen(int id, int minGrade) { return opened.contains(id + ":" + minGrade); }
    }

    @Test
    void publicOpenToAll() {
        assertTrue(FloorAccess.parse("PUBLIC").canUse(new FakeRoles()));
    }

    @Test
    void opAlwaysPasses() {
        FakeRoles r = new FakeRoles();
        r.op = true;
        for (String raw : new String[] {"PUBLIC", "POLICE", "POMPIER", "MAIRIE", "entreprise:3:1", "banane"}) {
            assertTrue(FloorAccess.parse(raw).canUse(r), raw);
        }
    }

    @Test
    void policeRequiresPoliceOrNode() {
        FloorAccess a = FloorAccess.parse("POLICE");
        assertFalse(a.canUse(new FakeRoles()));
        FakeRoles p = new FakeRoles();
        p.police = true;
        assertTrue(a.canUse(p));
        FakeRoles n = new FakeRoles();
        n.nodes.add("grade.police");
        assertTrue(a.canUse(n));
    }

    @Test
    void pompierRequiresSecoursOrNode() {
        FloorAccess a = FloorAccess.parse("POMPIER");
        assertFalse(a.canUse(new FakeRoles()));
        FakeRoles p = new FakeRoles();
        p.secours = true;
        assertTrue(a.canUse(p));
        FakeRoles n = new FakeRoles();
        n.nodes.add("grade.pompier");
        assertTrue(a.canUse(n));
    }

    @Test
    void mairieRequiresStaffOrNode() {
        FloorAccess a = FloorAccess.parse("MAIRIE");
        assertFalse(a.canUse(new FakeRoles()));
        FakeRoles p = new FakeRoles();
        p.mairie = true;
        assertTrue(a.canUse(p));
        FakeRoles n = new FakeRoles();
        n.nodes.add("grade.mairie");
        assertTrue(a.canUse(n));
    }

    @Test
    void entrepriseUsesGrade() {
        FloorAccess a = FloorAccess.parse("entreprise:3:1");
        FakeRoles r = new FakeRoles();
        r.exists = true;
        assertFalse(a.canUse(r));
        r.opened.add("3:1");
        assertTrue(a.canUse(r));
    }

    @Test
    void entrepriseMissingLocksFloor() {
        FloorAccess a = FloorAccess.parse("entreprise:3:1");
        FakeRoles r = new FakeRoles();
        r.exists = false;
        r.opened.add("3:1");
        assertFalse(a.canUse(r));
    }

    @Test
    void missingRoleModLocksFloor() {
        FakeRoles r = new FakeRoles();
        for (String raw : new String[] {"POLICE", "POMPIER", "MAIRIE"}) {
            assertFalse(FloorAccess.parse(raw).canUse(r), raw);
        }
    }

    @Test
    void unknownAccessLocksFloorForNonOp() {
        FakeRoles r = new FakeRoles();
        r.exists = true;
        r.police = true;
        for (String raw : new String[] {"banane", "entreprise:x", "entreprise:3", "", "police"}) {
            FloorAccess a = FloorAccess.parse(raw);
            assertInstanceOf(FloorAccess.Unknown.class, a, raw);
            assertFalse(a.canUse(r), raw);
            assertEquals("Verrouillé", a.label());
        }
        assertFalse(FloorAccess.parse(null).canUse(r));
    }

    @Test
    void roundTripFormat() {
        for (String raw : new String[] {"PUBLIC", "POLICE", "POMPIER", "MAIRIE", "entreprise:3:-1", "entreprise:3:99", "entreprise:7:0"}) {
            assertEquals(raw, FloorAccess.parse(raw).format());
        }
        assertEquals("entreprise:3:99", FloorAccess.parse("entreprise:3:500").format());
        assertEquals("entreprise:3:-1", FloorAccess.parse("entreprise:3:-9").format());
    }

    @Test
    void labels() {
        assertEquals("Public", FloorAccess.parse("PUBLIC").label());
        assertEquals("Police", FloorAccess.parse("POLICE").label());
        assertEquals("Pompier/SAMU", FloorAccess.parse("POMPIER").label());
        assertEquals("Mairie", FloorAccess.parse("MAIRIE").label());
        assertEquals("Entreprise", FloorAccess.parse("entreprise:3:1").label());
    }
}
