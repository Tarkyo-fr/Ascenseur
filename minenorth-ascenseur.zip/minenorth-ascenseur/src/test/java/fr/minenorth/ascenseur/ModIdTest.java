package fr.minenorth.ascenseur;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class ModIdTest {
    @Test
    void modIdIsStable() {
        assertEquals("minenorthascenseur", MineNorthAscenseur.MOD_ID);
    }
}
