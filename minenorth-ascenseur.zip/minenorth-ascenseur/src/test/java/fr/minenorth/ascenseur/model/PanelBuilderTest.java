package fr.minenorth.ascenseur.model;

import static org.junit.jupiter.api.Assertions.*;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import org.junit.jupiter.api.Test;

class PanelBuilderTest {

    static class FakeRoles implements Roles {
        boolean op, police, secours, mairie;
        Set<String> nodes = new HashSet<>();

        public boolean isOp() { return op; }
        public boolean isPolice() { return police; }
        public boolean isSecours() { return secours; }
        public boolean isMairie() { return mairie; }
        public boolean hasNode(String node) { return nodes.contains(node); }
        public boolean entrepriseExists(int id) { return false; }
        public boolean entrepriseCanOpen(int id, int minGrade) { return false; }
    }

    static Elevator elevator() {
        return new Elevator(UUID.randomUUID(), "Commissariat", CabinSize.values()[0], List.of(
                new Floor("Accueil", 64, "PUBLIC"),
                new Floor("Bureaux", 70, "PUBLIC"),
                new Floor("Garde à vue", 76, "POLICE")));
    }

    @Test
    void tooltipShowsRoleLabel() {
        FakeRoles police = new FakeRoles();
        police.police = true;
        List<FloorView> views = PanelBuilder.forPlayer(elevator(), police, 0);
        assertEquals("2 · Garde à vue · Police", views.get(2).tooltip());
        assertEquals("Police", views.get(2).roleLabel());
        assertEquals("1 · Bureaux", views.get(1).tooltip());
    }

    @Test
    void lockedFloorIsNotAllowed() {
        List<FloorView> views = PanelBuilder.forPlayer(elevator(), new FakeRoles(), 0);
        assertTrue(views.get(0).allowed());
        assertTrue(views.get(1).allowed());
        assertFalse(views.get(2).allowed());
        assertEquals(3, views.size());
        assertEquals(76, views.get(2).y());
    }

    @Test
    void currentFloorIsMarked() {
        List<FloorView> views = PanelBuilder.forPlayer(elevator(), new FakeRoles(), 1);
        assertFalse(views.get(0).current());
        assertTrue(views.get(1).current());
        assertFalse(views.get(2).current());
    }
}
