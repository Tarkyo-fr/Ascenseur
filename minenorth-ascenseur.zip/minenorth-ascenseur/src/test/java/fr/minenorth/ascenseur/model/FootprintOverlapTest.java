package fr.minenorth.ascenseur.model;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

class FootprintOverlapTest {
    @Test
    void adjacentShaftsDoNotOverlap() {
        CabinFootprint a = CabinFootprint.of(0, 0, CabinSize.S2X2, 0, -1); // x 0..1, z 0..1
        CabinFootprint b = CabinFootprint.of(2, 0, CabinSize.S2X2, 0, -1); // x 2..3
        assertFalse(a.overlaps(b));
        assertFalse(b.overlaps(a));
    }

    @Test
    void sharedColumnOverlaps() {
        CabinFootprint a = CabinFootprint.of(0, 0, CabinSize.S2X2, 0, -1);
        CabinFootprint b = CabinFootprint.of(1, 1, CabinSize.S1X1, 0, -1);
        assertTrue(a.overlaps(b));
        assertTrue(b.overlaps(a));
    }

    @Test
    void resizeInto2x4ReachesTheNeighbour() {
        // 2x4 facing east from (10, 20): x 7..10, z 20..21.
        CabinFootprint big = CabinFootprint.of(10, 20, CabinSize.S2X4, 1, 0);
        assertTrue(big.overlaps(CabinFootprint.of(7, 21, CabinSize.S1X1, 0, -1)));
        assertFalse(big.overlaps(CabinFootprint.of(6, 21, CabinSize.S1X1, 0, -1)));
    }

    @Test
    void doorwayStraddlesTheFrontPlane() {
        CabinFootprint north = CabinFootprint.of(10, 20, CabinSize.S2X2, 0, -1); // front edge z = 20
        org.junit.jupiter.api.Assertions.assertArrayEquals(new double[] {10, 19.7, 12, 20.3}, north.doorway(0.3), 1e-9);
        CabinFootprint east = CabinFootprint.of(10, 20, CabinSize.S2X4, 1, 0); // front edge x = 11
        org.junit.jupiter.api.Assertions.assertArrayEquals(new double[] {10.7, 20, 11.3, 22}, east.doorway(0.3), 1e-9);
    }
}
