package fr.minenorth.ascenseur.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import fr.minenorth.ascenseur.model.TripController.Phase;
import org.junit.jupiter.api.Test;

class TripControllerTest {
    private static final int[] FLOORS = {64, 70, 76};

    private static TripController controller() {
        return new TripController(FLOORS, 0, 1.0, 2);
    }

    /** Ticks until a trip (or door reopening) has started and the controller is IDLE again. */
    private static int runToIdle(TripController c) {
        int n = 0;
        boolean started = c.phase() != Phase.IDLE;
        do {
            c.tick();
            n++;
            started |= c.phase() != Phase.IDLE;
            assertTrue(n < 1000, "controller never became idle");
        } while (!started || c.phase() != Phase.IDLE);
        return n;
    }

    @Test
    void callsServedInOrder() {
        TripController c = controller();
        c.call(2);
        c.call(1);
        runToIdle(c);
        assertEquals(2, c.currentFloor());
        runToIdle(c);
        assertEquals(1, c.currentFloor());
        assertEquals(70.0, c.y());
        assertEquals(-1, c.targetFloor());
    }

    @Test
    void duplicateCallsNotQueued() {
        TripController c = controller();
        c.call(2);
        c.call(2);
        runToIdle(c);
        assertEquals(2, c.currentFloor());
        c.tick();
        assertEquals(Phase.IDLE, c.phase());
        assertEquals(-1, c.targetFloor());
    }

    @Test
    void phasesFollowDoorCycle() {
        TripController c = controller();
        c.call(1);
        c.tick();
        assertEquals(Phase.DOORS_CLOSING, c.phase());
        assertEquals(1, c.targetFloor());
        while (c.phase() == Phase.DOORS_CLOSING) {
            c.tick();
        }
        assertEquals(Phase.MOVING, c.phase());
        while (c.phase() == Phase.MOVING) {
            c.tick();
        }
        assertEquals(Phase.DOORS_OPENING, c.phase());
        assertEquals(70.0, c.y());
        while (c.phase() == Phase.DOORS_OPENING) {
            c.tick();
        }
        assertEquals(Phase.IDLE, c.phase());
    }

    @Test
    void selectIgnoredWhileMoving() {
        TripController c = controller();
        c.call(2);
        c.tick();
        assertFalse(c.select(1));
        while (c.phase() != Phase.MOVING) {
            c.tick();
        }
        assertFalse(c.select(1));
        runToIdle(c);
        assertEquals(2, c.currentFloor());
    }

    @Test
    void selectAllowedWhenIdle() {
        TripController c = controller();
        assertTrue(c.select(2));
        assertFalse(c.select(5));
        assertFalse(c.select(-1));
        runToIdle(c);
        assertEquals(2, c.currentFloor());
        assertEquals(76.0, c.y());
    }

    @Test
    void selectedServedBeforeQueuedCalls() {
        TripController c = controller();
        c.call(1);
        assertTrue(c.select(2));
        runToIdle(c);
        assertEquals(2, c.currentFloor());
        runToIdle(c);
        assertEquals(1, c.currentFloor());
    }

    @Test
    void callAtCurrentFloorWhileIdleIsANoOp() {
        TripController c = controller();
        c.call(0);
        assertEquals(Phase.IDLE, c.phase());
        assertEquals(-1, c.targetFloor());
        assertEquals(64.0, c.y());
    }

    @Test
    void reachesTargetExactly() {
        TripController c = new TripController(new int[] {64, 70, 76}, 0, 0.7, 1);
        c.call(2);
        runToIdle(c);
        assertEquals(76.0, c.y());
        assertEquals(2, c.currentFloor());
        c.call(0);
        runToIdle(c);
        assertEquals(64.0, c.y());
    }

    @Test
    void floorsRemovedWhileQueued() {
        TripController c = controller();
        c.call(2);
        c.call(1);
        c.updateFloors(new int[] {64, 70});
        runToIdle(c);
        assertEquals(1, c.currentFloor());
        c.tick();
        assertEquals(Phase.IDLE, c.phase());
        assertEquals(-1, c.targetFloor());
    }

    @Test
    void floorRemovedWhileHeadingThereAbortsTrip() {
        TripController c = controller();
        c.call(2);
        c.call(1);
        while (c.phase() != Phase.MOVING) {
            c.tick();
        }
        c.tick();
        c.updateFloors(new int[] {64, 70});
        assertEquals(Phase.IDLE, c.phase());
        assertEquals(-1, c.targetFloor());
        assertEquals(0, c.currentFloor());
        assertEquals(64.0, c.y());
        runToIdle(c);
        assertEquals(1, c.currentFloor());
        assertEquals(70.0, c.y());
    }

    @Test
    void resetWhileMoving() {
        TripController c = controller();
        c.call(2);
        c.call(1);
        while (c.phase() != Phase.MOVING) {
            c.tick();
        }
        c.tick();
        c.reset(73);
        assertEquals(1, c.currentFloor());
        assertEquals(70.0, c.y());
        assertEquals(Phase.IDLE, c.phase());
        assertEquals(-1, c.targetFloor());
        for (int i = 0; i < 10; i++) {
            c.tick();
        }
        assertEquals(Phase.IDLE, c.phase());
        assertEquals(1, c.currentFloor());
    }

    @Test
    void queuedCallWaitsDwellBeforeDeparting() {
        TripController c = controller(); // doorTicks = 2
        c.call(2);
        c.call(1);
        runToIdle(c);
        assertEquals(2, c.currentFloor());
        c.tick();
        assertEquals(Phase.IDLE, c.phase());
        c.tick();
        assertEquals(Phase.IDLE, c.phase());
        c.tick();
        assertEquals(Phase.DOORS_CLOSING, c.phase());
        assertEquals(1, c.targetFloor());
    }

    @Test
    void selectAcceptedDuringDwellWithQueuedCalls() {
        TripController c = controller();
        c.call(2);
        c.call(1);
        runToIdle(c);
        assertEquals(2, c.currentFloor());
        c.tick();
        assertEquals(Phase.IDLE, c.phase());
        assertTrue(c.select(0));
        runToIdle(c);
        assertEquals(0, c.currentFloor());
        runToIdle(c);
        assertEquals(1, c.currentFloor());
    }

    @Test
    void resetSnapsToNearestFloor() {
        TripController c = controller();
        c.call(2);
        c.tick();
        c.reset(73);
        assertEquals(1, c.currentFloor());
        assertEquals(Phase.IDLE, c.phase());
        assertEquals(70.0, c.y());
        c.tick();
        assertEquals(Phase.IDLE, c.phase());
    }

    @Test
    void pendingSelectionUntilNextTick() {
        TripController c = controller();
        assertFalse(c.hasPendingSelection());
        assertTrue(c.select(2));
        assertTrue(c.hasPendingSelection());
        c.tick();
        assertFalse(c.hasPendingSelection());
        assertEquals(Phase.DOORS_CLOSING, c.phase());
        assertEquals(2, c.targetFloor());
    }

    @Test
    void selectingCurrentFloorLeavesNothingPending() {
        TripController c = controller();
        assertTrue(c.select(0));
        assertFalse(c.hasPendingSelection());
        assertEquals(Phase.IDLE, c.phase());
    }

    @Test
    void remapKeepsHeightWhenLowerFloorRemoved() {
        TripController c = new TripController(FLOORS, 1, 1.0, 2); // arrêtée à 70
        c.call(2);
        assertFalse(c.remapFloorsByHeight(new int[] {70, 76}));
        assertEquals(0, c.currentFloor());
        assertEquals(70.0, c.y());
        runToIdle(c);
        assertEquals(1, c.currentFloor()); // l'appel vers 76 a suivi sa hauteur
        assertEquals(76.0, c.y());
    }

    @Test
    void remapDropsCallsWhoseHeightIsGone() {
        TripController c = new TripController(FLOORS, 2, 1.0, 2); // arrêtée à 76
        c.call(0);
        c.call(1);
        assertFalse(c.remapFloorsByHeight(new int[] {64, 72, 76}));
        assertEquals(2, c.currentFloor());
        runToIdle(c);
        assertEquals(0, c.currentFloor());
        for (int i = 0; i < 20; i++) {
            c.tick();
        }
        assertEquals(Phase.IDLE, c.phase());
        assertEquals(0, c.currentFloor()); // l'appel vers 70 a disparu avec l'étage
    }

    @Test
    void remapMovesToNearestWhenOwnFloorGone() {
        TripController c = new TripController(FLOORS, 1, 1.0, 2); // 70
        assertTrue(c.remapFloorsByHeight(new int[] {64, 69, 80}));
        assertEquals(1, c.currentFloor());
        assertEquals(69.0, c.y());
        assertEquals(Phase.IDLE, c.phase());
    }

    @Test
    void remapKeepsPendingSelectionByHeight() {
        TripController c = new TripController(FLOORS, 1, 1.0, 2);
        assertTrue(c.select(2));
        c.remapFloorsByHeight(new int[] {70, 76});
        assertTrue(c.hasPendingSelection());
        runToIdle(c);
        assertEquals(76.0, c.y());
    }

    @Test
    void remapDuringDoorsClosingDropsVanishedTarget() {
        TripController c = new TripController(FLOORS, 0, 1.0, 2);
        c.call(2);
        c.tick();
        assertEquals(Phase.DOORS_CLOSING, c.phase());
        c.remapFloorsByHeight(new int[] {64, 70});
        assertEquals(Phase.IDLE, c.phase());
        assertEquals(-1, c.targetFloor());
        assertEquals(64.0, c.y());
    }

    @Test
    void resetClearsPendingSelection() {
        TripController c = controller();
        assertTrue(c.select(2));
        c.reset(64);
        assertFalse(c.hasPendingSelection());
    }

    /** Ticks until the cabin is MOVING. */
    private static void tickUntilMoving(TripController c) {
        for (int i = 0; i < 100 && c.phase() != Phase.MOVING; i++) {
            c.tick();
        }
        assertEquals(Phase.MOVING, c.phase());
    }

    @Test
    void obstructionWhileNotMovingDoesNothing() {
        TripController c = controller();
        assertEquals(TripController.Obstruction.NONE, c.obstructed());
        c.call(2);
        c.tick();
        assertEquals(Phase.DOORS_CLOSING, c.phase());
        assertEquals(TripController.Obstruction.NONE, c.obstructed());
        assertEquals(2, c.targetFloor());
    }

    @Test
    void obstructionReversesToOriginFloor() {
        TripController c = new TripController(FLOORS, 0, 0.5, 2);
        c.call(1);
        c.call(2);
        tickUntilMoving(c);
        c.tick();
        c.tick();
        c.tick();
        assertEquals(65.5, c.y());
        assertEquals(TripController.Obstruction.REVERSED, c.obstructed());
        assertEquals(0, c.targetFloor());
        assertEquals(65.0, c.nextY());
        c.tick();
        assertEquals(65.0, c.y());
        runToIdle(c);
        assertEquals(0, c.currentFloor());
        assertEquals(64.0, c.y());
        // The aborted destination is dropped; the other queued call is kept.
        runToIdle(c);
        assertEquals(2, c.currentFloor());
    }

    @Test
    void obstructionWhileGoingBackHoldsForOneTick() {
        TripController c = new TripController(FLOORS, 0, 0.5, 2);
        c.call(1);
        tickUntilMoving(c);
        c.tick();
        c.tick();
        assertEquals(65.0, c.y());
        assertEquals(TripController.Obstruction.REVERSED, c.obstructed());
        assertEquals(TripController.Obstruction.HELD, c.obstructed());
        assertEquals(65.0, c.nextY());
        c.tick();
        assertEquals(65.0, c.y());
        assertEquals(Phase.MOVING, c.phase());
        c.tick(); // cleared: resumes going back
        assertEquals(64.5, c.y());
    }

    @Test
    void obstructionAtFirstStepArrivesBackImmediately() {
        TripController c = controller();
        c.call(1);
        tickUntilMoving(c);
        assertEquals(64.0, c.y());
        assertEquals(TripController.Obstruction.REVERSED, c.obstructed());
        c.tick();
        assertEquals(Phase.DOORS_OPENING, c.phase());
        assertEquals(0, c.currentFloor());
        assertEquals(64.0, c.y());
    }

    @Test
    void nextYFollowsMovement() {
        TripController c = new TripController(FLOORS, 0, 4.0, 0);
        assertEquals(64.0, c.nextY());
        c.call(1);
        tickUntilMoving(c);
        assertEquals(68.0, c.nextY());
        c.tick();
        assertEquals(70.0, c.nextY()); // clamped on the floor
    }

    @Test
    void leadingLayerIsTopWhenGoingUpAndFloorWhenGoingDown() {
        assertEquals(TripController.NO_LAYER, TripController.leadingLayer(64.0, 64.0, 3));
        assertEquals(67, TripController.leadingLayer(64.0, 64.2, 3));
        assertEquals(66, TripController.leadingLayer(63.8, 64.0, 3));
        assertEquals(63, TripController.leadingLayer(64.0, 63.8, 3));
        assertEquals(64, TripController.leadingLayer(64.2, 64.0, 3));
        assertEquals(-2, TripController.leadingLayer(-1.0, -1.2, 3));
    }

    @Test
    void holdingTheCallButtonDoesNotKeepTheCabin() {
        TripController c = new TripController(FLOORS, 0, 1.0, 2);
        c.call(1);
        runToIdle(c); // at floor 1, doors open, dwell running
        c.call(0); // someone else waits at floor 0
        int ticks = 0;
        while (c.phase() == Phase.IDLE && ticks < 50) {
            c.call(1); // spam from the landing of floor 1
            c.tick();
            ticks++;
        }
        assertEquals(Phase.DOORS_CLOSING, c.phase());
        assertTrue(ticks <= 3, "dwell was extended: " + ticks);
    }

    @Test
    void dwellRunsDownWithoutCalls() {
        TripController c = new TripController(FLOORS, 0, 1.0, 2);
        c.call(1);
        runToIdle(c);
        c.tick();
        c.tick();
        c.tick();
        c.call(2);
        c.tick();
        assertEquals(Phase.DOORS_CLOSING, c.phase()); // no extra wait
    }

    @Test
    void selectionDuringDoorsOpeningIsServedOnceIdle() {
        TripController c = new TripController(FLOORS, 0, 1.0, 2);
        c.call(1);
        tickUntilMoving(c);
        while (c.phase() == Phase.MOVING) {
            c.tick();
        }
        assertEquals(Phase.DOORS_OPENING, c.phase());
        assertTrue(c.select(2));
        assertTrue(c.hasPendingSelection());
        runToIdle(c);
        assertEquals(1, c.currentFloor());
        c.tick();
        assertEquals(Phase.DOORS_CLOSING, c.phase());
        assertEquals(2, c.targetFloor());
        assertFalse(c.select(0)); // closing: refused
    }

    @Test
    void doorSensorReopensAndKeepsTheDestination() {
        TripController c = new TripController(FLOORS, 0, 1.0, 2);
        c.call(2);
        c.tick();
        assertEquals(Phase.DOORS_CLOSING, c.phase());
        assertTrue(c.doorObstructed());
        assertEquals(Phase.DOORS_OPENING, c.phase());
        assertEquals(0, c.currentFloor());
        runToIdle(c);
        c.tick();
        assertEquals(Phase.DOORS_CLOSING, c.phase());
        assertEquals(2, c.targetFloor());
    }

    @Test
    void doorSensorBudgetIsBounded() {
        TripController c = new TripController(FLOORS, 0, 1.0, 2);
        c.call(2);
        c.tick();
        for (int i = 0; i < TripController.MAX_DOOR_REOPENS; i++) {
            assertTrue(c.doorObstructed());
            while (c.phase() != Phase.DOORS_CLOSING) {
                c.tick();
            }
        }
        assertFalse(c.doorObstructed());
        tickUntilMoving(c);
        assertEquals(2, c.targetFloor());
        assertFalse(c.doorObstructed()); // not closing
    }
}
