package fr.minenorth.ascenseur.network;

import fr.minenorth.ascenseur.model.Floor;
import io.netty.buffer.Unpooled;
import net.minecraft.network.FriendlyByteBuf;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class PacketLimitsTest {

    private static FriendlyByteBuf buffer() {
        return new FriendlyByteBuf(Unpooled.buffer());
    }

    @Test
    void roundTripFloors() {
        FriendlyByteBuf b = buffer();
        List<Floor> floors = List.of(new Floor("Accueil", 64, "PUBLIC"), new Floor("Bloc", 70, "POLICE"));
        PacketLimits.writeFloors(b, floors);
        assertEquals(floors, PacketLimits.readFloors(b));
    }

    @Test
    void hugeCountIsRejectedWithoutAllocating() {
        FriendlyByteBuf b = buffer();
        b.writeVarInt(Integer.MAX_VALUE);
        assertThrows(IllegalArgumentException.class, () -> PacketLimits.readFloors(b));
    }

    @Test
    void sanitizeCompaniesTruncatesNameAndKeepsId() {
        String longName = "x".repeat(200);
        List<String> out = PacketLimits.sanitizeCompanies(List.of("42|" + longName));
        assertEquals(1, out.size());
        assertEquals(PacketLimits.MAX_NAME, out.get(0).length());
        assertTrue(out.get(0).startsWith("42|x"));
    }

    @Test
    void sanitizeCompaniesCapsCount() {
        List<String> many = new java.util.ArrayList<>();
        for (int i = 0; i < 300; i++) {
            many.add(i + "|Nom " + i);
        }
        List<String> out = PacketLimits.sanitizeCompanies(many);
        assertEquals(PacketLimits.MAX_COMPANIES, out.size());
        assertEquals("0|Nom 0", out.get(0));
    }

    @Test
    void sanitizeCompaniesHandlesNoBarAndEmpty() {
        assertEquals(List.of(), PacketLimits.sanitizeCompanies(List.of()));
        assertEquals(List.of(), PacketLimits.sanitizeCompanies(null));
        List<String> out = PacketLimits.sanitizeCompanies(List.of("y".repeat(100)));
        assertEquals(PacketLimits.MAX_NAME, out.get(0).length());
    }

    @Test
    void sanitizeFloorsTruncatesAndCaps() {
        List<Floor> in = new java.util.ArrayList<>();
        for (int i = 0; i < 40; i++) {
            in.add(new Floor("n".repeat(100), i, "a".repeat(100)));
        }
        List<Floor> out = PacketLimits.sanitizeFloors(in);
        assertEquals(PacketLimits.MAX_FLOORS, out.size());
        assertEquals(PacketLimits.MAX_NAME, out.get(0).name().length());
        assertEquals(PacketLimits.MAX_ACCESS, out.get(0).access().length());
        assertEquals(5, out.get(5).y());
    }

    @Test
    void negativeCountIsRejected() {
        FriendlyByteBuf b = buffer();
        b.writeVarInt(-1);
        assertThrows(IllegalArgumentException.class, () -> PacketLimits.readCount(b, 10));
    }

    @Test
    void countAboveBoundIsRejectedAndAtBoundAccepted() {
        FriendlyByteBuf over = buffer();
        over.writeVarInt(PacketLimits.MAX_FLOORS + 1);
        assertThrows(IllegalArgumentException.class, () -> PacketLimits.readFloors(over));

        FriendlyByteBuf ok = buffer();
        ok.writeVarInt(3);
        assertEquals(3, PacketLimits.readCount(ok, 3));
    }
}
