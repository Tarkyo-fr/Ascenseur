package fr.minenorth.ascenseur.model;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.junit.jupiter.api.Test;

class ElevatorTest {

    private static List<Floor> floors(int count) {
        List<Floor> list = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            list.add(new Floor("Etage " + i, 64 + i * 6, "PUBLIC"));
        }
        return list;
    }

    @Test
    void rejectsFewerThanTwoFloors() {
        assertTrue(Elevator.validate("Hopital", CabinSize.S2X4, floors(1)).isPresent());
        assertTrue(Elevator.validate("Hopital", CabinSize.S2X4, List.of()).isPresent());
    }

    @Test
    void rejectsMoreThan32Floors() {
        assertTrue(Elevator.validate("Tour", CabinSize.S2X2, floors(33)).isPresent());
        assertTrue(Elevator.validate("Tour", CabinSize.S2X2, floors(32)).isEmpty());
    }

    @Test
    void rejectsNonIncreasingHeights() {
        List<Floor> f = List.of(new Floor("A", 70, "PUBLIC"), new Floor("B", 70, "PUBLIC"));
        assertTrue(Elevator.validate("X", CabinSize.S1X1, f).isPresent());
        List<Floor> g = List.of(new Floor("A", 70, "PUBLIC"), new Floor("B", 64, "PUBLIC"));
        assertTrue(Elevator.validate("X", CabinSize.S1X1, g).isPresent());
    }

    @Test
    void rejectsBlankFloorName() {
        List<Floor> f = List.of(new Floor("A", 64, "PUBLIC"), new Floor("  ", 70, "PUBLIC"));
        assertTrue(Elevator.validate("X", CabinSize.S1X1, f).isPresent());
    }

    @Test
    void acceptsHospitalExample() {
        List<Floor> f = List.of(
                new Floor("Accueil", 64, "PUBLIC"),
                new Floor("Urgences", 70, "PUBLIC"),
                new Floor("Bloc opératoire", 76, "POMPIER"),
                new Floor("Garde à vue", 82, "POLICE"),
                new Floor("Direction", 88, "entreprise:1:1"));
        assertTrue(Elevator.validate("Hôpital", CabinSize.parse("2x4").orElseThrow(), f).isEmpty());
        Elevator e = new Elevator(UUID.randomUUID(), "Hôpital", CabinSize.S2X4, f);
        assertEquals(5, e.floors().size());
        assertEquals(CabinSize.S2X4, e.size());
        assertEquals("Hôpital", e.name());
        assertNotNull(e.id());
    }

    @Test
    void constructorThrowsWhenInvalid() {
        assertThrows(IllegalArgumentException.class,
                () -> new Elevator(UUID.randomUUID(), "X", CabinSize.S1X1, floors(1)));
    }

    @Test
    void parsesSizes() {
        assertEquals(Optional.of(CabinSize.S1X1), CabinSize.parse("1x1"));
        assertEquals(Optional.of(CabinSize.S2X2), CabinSize.parse("2x2"));
        assertEquals(Optional.of(CabinSize.S2X4), CabinSize.parse("2x4"));
        assertEquals(Optional.of(CabinSize.S4X4), CabinSize.parse("4x4"));
        assertTrue(CabinSize.parse("3x3").isEmpty());
        assertEquals(2, CabinSize.S2X4.width());
        assertEquals(4, CabinSize.S2X4.depth());
    }
}
