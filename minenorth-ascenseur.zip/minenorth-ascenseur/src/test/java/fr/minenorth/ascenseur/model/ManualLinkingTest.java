package fr.minenorth.ascenseur.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;
import org.junit.jupiter.api.Test;

class ManualLinkingTest {
    private static final String OW = "minecraft:overworld";
    private static final int[] FLOORS = {64, 70, 76};

    private static ManualLinking.Candidate at(int x, int z, String dim, int... ys) {
        return new ManualLinking.Candidate(dim, CabinFootprint.of(x, z, CabinSize.S2X2, 0, -1), ys);
    }

    @Test
    void nearestElevatorWins() {
        List<ManualLinking.Candidate> c = List.of(at(0, 0, OW, FLOORS), at(10, 0, OW, FLOORS));
        ManualLinking.Pick p = ManualLinking.pick(c, OW, 9, 64, -1);
        assertTrue(p.ok());
        assertEquals(1, p.elevator());
        assertEquals(0, p.floor());
    }

    @Test
    void displayAboveTheDoorMapsToItsFloor() {
        List<ManualLinking.Candidate> c = List.of(at(0, 0, OW, FLOORS));
        assertEquals(0, ManualLinking.pick(c, OW, 0, 67, -1).floor()); // 3 above floor 0
        assertEquals(1, ManualLinking.pick(c, OW, 0, 68, -1).floor()); // closer to 70
    }

    @Test
    void tieGoesToTheLowerFloor() {
        List<ManualLinking.Candidate> c = List.of(at(0, 0, OW, FLOORS));
        assertEquals(0, ManualLinking.pick(c, OW, 0, 67, -1).floor()); // 64 and 70 are both 3 away
    }

    @Test
    void verticalToleranceIsSixBlocks() {
        List<ManualLinking.Candidate> c = List.of(at(0, 0, OW, 64, 100));
        assertTrue(ManualLinking.pick(c, OW, 0, 70, -1).ok());
        ManualLinking.Pick far = ManualLinking.pick(c, OW, 0, 71, -1);
        assertFalse(far.ok());
        assertEquals(ManualLinking.Failure.NO_FLOOR, far.failure());
    }

    @Test
    void outOfRangeOrOtherDimensionIsRefused() {
        List<ManualLinking.Candidate> c = List.of(at(0, 0, "minecraft:the_nether", FLOORS), at(100, 0, OW, FLOORS));
        ManualLinking.Pick p = ManualLinking.pick(c, OW, 0, 64, 0);
        assertEquals(ManualLinking.Failure.NO_ELEVATOR, p.failure());
        assertEquals(0.0, ManualLinking.distance(CabinFootprint.of(0, 0, CabinSize.S2X2, 0, -1), 1, 1));
        // 24 blocks from the shaft edge is still accepted.
        assertTrue(ManualLinking.pick(List.of(at(0, 0, OW, FLOORS)), OW, 25, 64, 0).ok());
        assertFalse(ManualLinking.pick(List.of(at(0, 0, OW, FLOORS)), OW, 27, 64, 0).ok());
    }

    @Test
    void noFloorsIsRefused() {
        ManualLinking.Pick p = ManualLinking.pick(List.of(at(0, 0, OW)), OW, 0, 64, 0);
        assertEquals(ManualLinking.Failure.NO_FLOOR, p.failure());
    }
}
