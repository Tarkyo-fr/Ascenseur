package fr.minenorth.ascenseur.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import fr.minenorth.ascenseur.model.ElevatorNameMatcher.Candidate;
import java.util.List;
import java.util.UUID;
import org.junit.jupiter.api.Test;

class ElevatorNameMatcherTest {
    private static final Candidate A = new Candidate(UUID.fromString("aaaa1111-0000-0000-0000-000000000000"), "Hôpital");
    private static final Candidate B = new Candidate(UUID.fromString("bbbb2222-0000-0000-0000-000000000000"), "Hôpital Nord");
    private static final Candidate C = new Candidate(UUID.fromString("cccc3333-0000-0000-0000-000000000000"), "Mairie");
    private static final List<Candidate> ALL = List.of(A, B, C);

    @Test
    void exactNameWinsOverPartial() {
        assertEquals(List.of(A), ElevatorNameMatcher.match(ALL, "hôpital").matches());
    }

    @Test
    void partialNameCanBeAmbiguous() {
        assertTrue(ElevatorNameMatcher.match(ALL, "hôp").ambiguous());
    }

    @Test
    void idPrefixResolvesAmbiguity() {
        assertEquals(B, ElevatorNameMatcher.match(ALL, "bbbb").single());
    }

    @Test
    void noMatchAndBlank() {
        assertTrue(ElevatorNameMatcher.match(ALL, "zzz").none());
        assertTrue(ElevatorNameMatcher.match(ALL, "  ").none());
    }
}
