package fr.minenorth.ascenseur.model;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class FloorRemapTest {
    @Test
    void sameHeightsKeepTheirNewIndex() {
        assertArrayEquals(new int[] {-1, 0, 1}, FloorRemap.byHeight(new int[] {64, 70, 76}, new int[] {70, 76}));
    }

    @Test
    void insertedFloorShiftsIndices() {
        assertArrayEquals(new int[] {0, 2, 3}, FloorRemap.byHeight(new int[] {64, 70, 76}, new int[] {64, 67, 70, 76}));
    }

    @Test
    void movedFloorIsGone() {
        assertArrayEquals(new int[] {0, -1, 2}, FloorRemap.byHeight(new int[] {64, 70, 76}, new int[] {64, 71, 76}));
    }

    @Test
    void nearestPrefersLowerOnTie() {
        int[] ys = {64, 70, 76};
        assertEquals(1, FloorRemap.nearest(ys, 69.0));
        assertEquals(0, FloorRemap.nearest(ys, 67.0));
        assertEquals(2, FloorRemap.nearest(ys, 200.0));
        assertEquals(-1, FloorRemap.indexOf(ys, 65));
    }
}
