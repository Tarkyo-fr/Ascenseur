package fr.minenorth.ascenseur.data;

import fr.minenorth.ascenseur.model.CabinSize;
import fr.minenorth.ascenseur.model.Elevator;
import fr.minenorth.ascenseur.model.Floor;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ElevatorNbtTest {
    // La partie qui touche ResourceKey (toTag/fromTag) exige le bootstrap Forge, indisponible en JUnit : on teste write/read.
    private static final ResourceLocation OVERWORLD = new ResourceLocation("minecraft", "overworld");


    private static Elevator hospital() {
        return new Elevator(UUID.fromString("123e4567-e89b-12d3-a456-426614174000"), "Hôpital Central", CabinSize.S2X4, List.of(
                new Floor("Accueil", 64, "PUBLIC"),
                new Floor("Urgences", 70, "PUBLIC"),
                new Floor("Bloc opératoire", 76, "POMPIER"),
                new Floor("Garde à vue", 82, "POLICE"),
                new Floor("Direction", 88, "entreprise:1:1")));
    }

    @Test
    void roundTrip() {
        Elevator e = hospital();
        BlockPos anchor = new BlockPos(-120, 64, 345);
        CompoundTag tag = ElevatorNbt.write(e, OVERWORLD, anchor, Direction.EAST);

        ElevatorNbt.Parts back = ElevatorNbt.read(tag);

        assertEquals(e.id(), back.elevator().id());
        assertEquals("Hôpital Central", back.elevator().name());
        assertEquals(CabinSize.S2X4, back.elevator().size());
        assertEquals(e.floors(), back.elevator().floors());
        assertEquals(OVERWORLD, back.dim());
        assertEquals(anchor, back.anchor());
        assertEquals(Direction.EAST, back.facing());
    }

    @Test
    void invalidFacingFallsBackToNorth() {
        CompoundTag tag = ElevatorNbt.write(hospital(), OVERWORLD, BlockPos.ZERO, Direction.SOUTH);
        tag.putString("Facing", "up");
        assertEquals(Direction.NORTH, ElevatorNbt.read(tag).facing());
        tag.remove("Facing");
        assertEquals(Direction.NORTH, ElevatorNbt.read(tag).facing());
    }

    @Test
    void oldSaveWithoutStyleReadsDefaultStyle() {
        CompoundTag tag = ElevatorNbt.write(hospital(), OVERWORLD, BlockPos.ZERO, Direction.NORTH);
        assertEquals(fr.minenorth.ascenseur.model.ElevatorStyle.DEFAULT, ElevatorNbt.read(tag).style());
    }

    @Test
    void styleRoundTripAndSanitize() {
        CompoundTag tag = ElevatorNbt.write(hospital(), OVERWORLD, BlockPos.ZERO, Direction.NORTH);
        ElevatorNbt.writeStyle(tag, new fr.minenorth.ascenseur.model.ElevatorStyle(11, 6));
        assertEquals(new fr.minenorth.ascenseur.model.ElevatorStyle(11, 6), ElevatorNbt.read(tag).style());
        tag.putInt("Color", 42);
        assertEquals(fr.minenorth.ascenseur.model.ElevatorStyle.DEFAULT.colorIndex(), ElevatorNbt.read(tag).style().colorIndex());
    }
}
