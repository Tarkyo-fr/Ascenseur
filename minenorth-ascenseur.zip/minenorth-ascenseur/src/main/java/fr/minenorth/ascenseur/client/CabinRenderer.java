package fr.minenorth.ascenseur.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import fr.minenorth.ascenseur.MineNorthAscenseur;
import fr.minenorth.ascenseur.cabin.CabinEntity;
import fr.minenorth.ascenseur.cabin.ModEntities;
import fr.minenorth.ascenseur.model.CabinFootprint;
import fr.minenorth.ascenseur.model.CabinWalls;
import fr.minenorth.ascenseur.model.FloorIndicator;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.item.DyeColor;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.block.BlockRenderDispatcher;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Rendu de la cabine (textures vanilla provisoires) : parois minces claires, sol poli, plafond avec
 * un plafonnier lumineux, encadrement de porte métallique, porte coulissante en deux vantaux animée,
 * main courante et panneau de commande (écran et boutons) sur la paroi droite près de la porte.
 *
 * <p>Repère local : la porte est en z = 0, la largeur W va de x = 0 à W (vers la droite vue de
 * l'intérieur, comme {@link CabinFootprint}), la profondeur D de z = 0 à D, le plancher en y = 0.
 * Les pièces sont découpées en morceaux d'au plus un bloc pour ne pas étirer les textures.
 */
public class CabinRenderer extends EntityRenderer<CabinEntity> {
    private static final float WALL = (float) CabinWalls.THICKNESS;
    private static final float FLOOR = 2.0F / 16.0F;
    private static final float FRAME = 2.0F / 16.0F;
    private static final float DOOR_H = 2.25F;

    // Sol uni (pas de bordure de texture, donc pas de quadrillage par case).
    private static final BlockState FLOOR_STATE = Blocks.GRAY_CONCRETE.defaultBlockState();
    /** Le dessus du sol dessiné est légèrement au-dessus de la hauteur d'étage : au rez-de-chaussée, le bloc
     * du terrain (herbe…) a son sommet exactement à cette hauteur et les deux faces se battaient (z-fighting). */
    private static final float FLOOR_LIFT = 0.01F;
    private static final BlockState WALL_STATE = Blocks.SMOOTH_QUARTZ.defaultBlockState();
    private static final BlockState CEILING_STATE = Blocks.SMOOTH_QUARTZ.defaultBlockState();
    private static final BlockState LAMP_STATE = Blocks.SEA_LANTERN.defaultBlockState();
    private static final BlockState METAL_STATE = Blocks.IRON_BLOCK.defaultBlockState();
    private static final BlockState DOOR_STATE = Blocks.LIGHT_GRAY_CONCRETE.defaultBlockState();
    private static final BlockState PANEL_STATE = Blocks.GRAY_CONCRETE.defaultBlockState();
    private static final BlockState SCREEN_STATE = Blocks.CYAN_CONCRETE.defaultBlockState();
    private static final BlockState BUTTON_STATE = Blocks.GOLD_BLOCK.defaultBlockState();

    public CabinRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.shadowRadius = 0.0F;
    }

    @Override
    public void render(CabinEntity cabin, float yaw, float partialTick, PoseStack pose,
                       MultiBufferSource buffers, int light) {
        BlockRenderDispatcher blocks = Minecraft.getInstance().getBlockRenderer();
        Direction doorSide = cabin.doorSide();
        boolean doorOnZ = doorSide.getAxis() == Direction.Axis.Z;
        float w = doorOnZ ? cabin.spanX() : cabin.spanZ();
        float d = doorOnZ ? cabin.spanZ() : cabin.spanX();
        float h = CabinFootprint.INTERIOR_HEIGHT;
        float open = cabin.doorOpenness(partialTick);
        Box box = new Box(pose, blocks, buffers, light);

        pose.pushPose();
        // Le z local négatif (côté porte) est tourné vers doorSide.
        pose.mulPose(Axis.YP.rotationDegrees(180.0F - doorSide.toYRot()));
        pose.translate(-w / 2.0F, 0.0F, -d / 2.0F);

        // Sol, plafond et plafonnier.
        box.draw(FLOOR_STATE, 0, -FLOOR + FLOOR_LIFT, 0, w, FLOOR_LIFT, d);
        box.draw(CEILING_STATE, 0, h - WALL, 0, w, h, d);
        float lw = Math.max(0.4F, w * 0.5F);
        float ld = Math.max(0.4F, d * 0.5F);
        box.lit(LAMP_STATE, (w - lw) / 2, h - WALL - 0.03F, (d - ld) / 2, (w + lw) / 2, h - WALL, (d + ld) / 2);

        // Parois du fond et des côtés : couleur choisie, ou vitre (la collision reste celle d'une paroi).
        BlockState wallState = wallState(cabin.color());
        int glass = cabin.glass();
        BlockState glassState = glassState(cabin.color());
        Direction rightSide = doorSide.getClockWise();
        box.draw(sideState(glass, doorSide.getOpposite(), wallState, glassState), 0, 0, d - WALL, w, h - WALL, d);
        box.draw(sideState(glass, rightSide.getOpposite(), wallState, glassState), 0, 0, 0, WALL, h - WALL, d - WALL);
        box.draw(sideState(glass, rightSide, wallState, glassState), w - WALL, 0, 0, w, h - WALL, d - WALL);

        // Façade : linteau, encadrement métallique et vantaux coulissants.
        float left = WALL + FRAME;
        float right = w - WALL - FRAME;
        box.draw(wallState, WALL, DOOR_H, 0, w - WALL, h - WALL, WALL);
        box.draw(METAL_STATE, WALL, 0, 0, left, DOOR_H, 2 * WALL);
        box.draw(METAL_STATE, right, 0, 0, w - WALL, DOOR_H, 2 * WALL);
        box.draw(METAL_STATE, WALL, DOOR_H, 0, w - WALL, DOOR_H + 0.06F, 2 * WALL);
        float leaf = (right - left) / 2.0F * (1.0F - open);
        if (leaf > 0.005F) {
            box.draw(doorState(cabin.color()), left, 0, 0.5F * WALL, left + leaf, DOOR_H, 1.5F * WALL);
            box.draw(doorState(cabin.color()), right - leaf, 0, 0.5F * WALL, right, DOOR_H, 1.5F * WALL);
        }

        // Main courante (fond et côtés) ; côté droit, elle commence après le panneau de commande.
        float railY = 0.9F;
        box.draw(METAL_STATE, WALL + 0.1F, railY, d - WALL - 0.07F, w - WALL - 0.1F, railY + 0.06F, d - WALL);
        if (d > 0.9F) {
            box.draw(METAL_STATE, WALL, railY, 0.35F, WALL + 0.07F, railY + 0.06F, d - WALL - 0.1F);
            box.draw(METAL_STATE, w - WALL - 0.07F, railY, 0.55F, w - WALL, railY + 0.06F, d - WALL - 0.1F);
        }

        // Panneau de commande : plaque, écran lumineux et boutons, paroi droite près de la porte.
        float px = w - WALL;
        box.draw(PANEL_STATE, px - 0.03F, 0.95F, 0.12F, px, 1.7F, 0.46F);
        box.lit(SCREEN_STATE, px - 0.04F, 1.45F, 0.17F, px - 0.03F, 1.63F, 0.41F);
        // Étage actuel et sens de marche sur l'écran du panneau (lisible depuis l'intérieur).
        drawLabel(pose, buffers, FloorIndicator.text(cabin.indicator()), px - 0.0405F, 1.54F, 0.29F, 0.18F);
        for (int row = 0; row < 3; row++) {
            float by = 1.05F + row * 0.12F;
            box.draw(BUTTON_STATE, px - 0.05F, by, 0.20F, px - 0.03F, by + 0.06F, 0.26F);
            box.draw(BUTTON_STATE, px - 0.05F, by, 0.32F, px - 0.03F, by + 0.06F, 0.38F);
        }
        pose.popPose();
        super.render(cabin, yaw, partialTick, pose, buffers, light);
    }


    /**
     * Texte centré sur un écran vertical de la paroi droite (repère local), tourné vers l'intérieur
     * (lisible en regardant vers +X local), en pleine luminosité. {@code height} : hauteur des lettres.
     */
    private static void drawLabel(PoseStack pose, MultiBufferSource buffers, String text,
                                  float x, float y, float z, float height) {
        Font font = Minecraft.getInstance().font;
        float scale = height / 9.0F;
        pose.pushPose();
        pose.translate(x, y, z);
        pose.mulPose(Axis.YP.rotationDegrees(-90.0F));
        pose.scale(scale, -scale, scale);
        font.drawInBatch(text, -font.width(text) / 2.0F, -4.0F, 0xFFFFFFFF, false, pose.last().pose(), buffers,
                Font.DisplayMode.POLYGON_OFFSET, 0, LightTexture.FULL_BRIGHT);
        pose.popPose();
    }

    private static final BlockState[] CONCRETE = new BlockState[16];
    private static final BlockState[] STAINED_GLASS = new BlockState[16];

    private static BlockState byName(String name) {
        return BuiltInRegistries.BLOCK.get(new ResourceLocation("minecraft", name)).defaultBlockState();
    }

    /** Paroi : quartz clair d'origine, ou béton de la teinte choisie (aspect uni, sans quadrillage). */
    static BlockState wallState(int color) {
        if (color < 0 || color > 15) {
            return WALL_STATE;
        }
        if (CONCRETE[color] == null) {
            CONCRETE[color] = byName(DyeColor.byId(color).getName() + "_concrete");
        }
        return CONCRETE[color];
    }

    /** Vitre : verre clair d'origine, ou verre teinté de la couleur choisie. */
    static BlockState glassState(int color) {
        if (color < 0 || color > 15) {
            return Blocks.GLASS.defaultBlockState();
        }
        if (STAINED_GLASS[color] == null) {
            STAINED_GLASS[color] = byName(DyeColor.byId(color).getName() + "_stained_glass");
        }
        return STAINED_GLASS[color];
    }

    /** Vantaux de la cabine : même matière que les portes d'étage (gris clair, ou la teinte choisie). */
    static BlockState doorState(int color) {
        return color < 0 || color > 15 ? DOOR_STATE : wallState(color);
    }

    private static BlockState sideState(int glassMask, Direction side, BlockState wall, BlockState glass) {
        int bit = CabinWalls.sideOf(side.getStepX(), side.getStepZ());
        return (glassMask & bit) != 0 ? glass : wall;
    }
    /** Dessin de pavés en blocs réduits. */
    private record Box(PoseStack pose, BlockRenderDispatcher blocks, MultiBufferSource buffers, int light) {
        void draw(BlockState state, float x0, float y0, float z0, float x1, float y1, float z1) {
            render(state, light, x0, y0, z0, x1, y1, z1);
        }

        /** Pièce lumineuse (plafonnier, écran) : pleine luminosité. */
        void lit(BlockState state, float x0, float y0, float z0, float x1, float y1, float z1) {
            render(state, LightTexture.FULL_BRIGHT, x0, y0, z0, x1, y1, z1);
        }

        private void render(BlockState state, int packedLight, float x0, float y0, float z0, float x1, float y1, float z1) {
            for (float x = x0; x < x1 - 1.0E-4F; x += 1.0F) {
                float sx = Math.min(1.0F, x1 - x);
                for (float y = y0; y < y1 - 1.0E-4F; y += 1.0F) {
                    float sy = Math.min(1.0F, y1 - y);
                    for (float z = z0; z < z1 - 1.0E-4F; z += 1.0F) {
                        float sz = Math.min(1.0F, z1 - z);
                        pose.pushPose();
                        pose.translate(x, y, z);
                        pose.scale(sx, sy, sz);
                        blocks.renderSingleBlock(state, pose, buffers, packedLight, OverlayTexture.NO_OVERLAY);
                        pose.popPose();
                    }
                }
            }
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    public ResourceLocation getTextureLocation(CabinEntity cabin) {
        return TextureAtlas.LOCATION_BLOCKS;
    }

    /** Enregistrement du rendu (client uniquement). */
    @Mod.EventBusSubscriber(modid = MineNorthAscenseur.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static final class Registration {
        private Registration() {
        }

        @SubscribeEvent
        public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
            event.registerEntityRenderer(ModEntities.CABIN.get(), CabinRenderer::new);
        }
    }
}
