package fr.minenorth.ascenseur.cabin;

import fr.minenorth.ascenseur.block.ModBlocks;
import fr.minenorth.ascenseur.compat.ServerRoles;
import fr.minenorth.ascenseur.data.ElevatorData;
import fr.minenorth.ascenseur.data.StoredElevator;
import fr.minenorth.ascenseur.model.CabinFootprint;
import fr.minenorth.ascenseur.model.CabinWalls;
import fr.minenorth.ascenseur.model.Elevator;
import fr.minenorth.ascenseur.model.ElevatorRules;
import fr.minenorth.ascenseur.model.Floor;
import fr.minenorth.ascenseur.model.FloorIndicator;
import fr.minenorth.ascenseur.model.FloorRemap;
import fr.minenorth.ascenseur.model.TripController;
import fr.minenorth.ascenseur.network.ModNetwork;
import fr.minenorth.ascenseur.network.ServerHooks;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.OptionalInt;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetPassengersPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Service serveur des ascenseurs (un par serveur), piloté par le tick serveur.
 *
 * <p>Pour chaque ascenseur dont la dimension est chargée, il possède un {@link TripController}
 * (toujours actif, même si personne n'est à proximité) et, quand les chunks de la gaine sont
 * actifs, la {@link CabinEntity} et le plancher invisible ({@link CabinFloorBlock}).
 *
 * <p>Déroulé d'un trajet :
 * <ul>
 *   <li>cabine arrêtée : plancher invisible posé sous l'empreinte, les joueurs marchent dessus ;</li>
 *   <li>départ (début de la phase MOVING, début de tick) : chaque joueur dans l'empreinte devient
 *       passager de la cabine ; le plancher est retiré en fin de tick, une fois les passagers
 *       envoyés aux clients ;</li>
 *   <li>trajet : la cabine avance, les passagers suivent (aucune expulsion anti-fly, aucune chute) ;
 *       un joueur qui descend (Maj) ou qui arrive dans l'empreinte est repris en fin de tick ;</li>
 *   <li>arrivée : le plancher est posé au début du tick, les passagers descendent en fin de tick,
 *       sur place (dans l'empreinte), et leur position est renvoyée exactement au client.</li>
 * </ul>
 * Le contrôleur ne dépend jamais des passagers : une déconnexion ou une mort n'a aucun effet sur
 * le trajet.
 */
public final class ElevatorService implements ServerHooks.SelectionService {
    /** Pas de plancher posé (trajet en cours). */
    private static final int NONE = Integer.MIN_VALUE;
    /** Position du plancher inconnue (démarrage) : tous les étages sont nettoyés. */
    private static final int UNKNOWN = Integer.MIN_VALUE + 1;
    /** Distance minimale entre un joueur déplacé et la paroi (demi-largeur d'un joueur + marge). */
    private static final double RIDER_MARGIN = CabinFootprint.RIDER_MARGIN;
    /** État des portes d'étage inconnu : toutes les ouvertures sont remises en ordre. */
    private static final int DOORS_UNKNOWN = -2;
    /** Période (ticks) de la reprise des nettoyages en attente. */
    private static final int CLEANUP_PERIOD = 20;
    /** Intervalle minimal (ticks) entre deux journaux répétés pour un même ascenseur. */
    private static final long LOG_PERIOD = 200;
    /** Délai (ticks) avant la vérification « dans la gaine » d'un joueur qui se connecte, et durée maximale d'attente. */
    private static final long LOGIN_DELAY = 20;
    private static final long LOGIN_GIVE_UP = 400;
    /** Demi-épaisseur (blocs) de l'embrasure surveillée par le capteur de porte, de part et d'autre de la façade. */
    private static final double DOORWAY_DEPTH = 0.3;
    private static final org.slf4j.Logger LOGGER = com.mojang.logging.LogUtils.getLogger();

    @Nullable
    private static ElevatorService instance;

    private final MinecraftServer server;
    private final Map<UUID, ActiveElevator> active = new HashMap<>();
    /** Joueurs déplacés ce tick-ci : leur position est renvoyée une seconde fois en fin de tick. */
    private final List<Relocation> pendingTeleports = new ArrayList<>();
    private long tickStamp;

    private record Relocation(ServerPlayer player, double x, double y, double z) {
    }

    private ElevatorService(MinecraftServer server) {
        this.server = server;
    }

    /** État vivant d'un ascenseur. Une nouvelle instance est créée si la géométrie change. */
    private static final class ActiveElevator {
        final UUID id;
        final ServerLevel level;
        final CabinFootprint footprint;
        final Direction facing;
        final TripController trip;
        /** Coins de l'empreinte, pour savoir si les chunks de la gaine sont actifs. */
        final BlockPos[] chunkProbes;
        StoredElevator stored;
        int[] floorYs;
        @Nullable
        CabinEntity cabin;
        /** Chunks de la gaine actifs (entités qui tickent) lors du dernier passage. */
        boolean present;
        /** Les joueurs sont passagers et le plancher est retiré (trajet en cours côté monde). */
        boolean boarded;
        /** Arrivée : faire descendre les passagers en fin de tick. */
        boolean alightPending;
        /** Y d'étage où le plancher est posé, {@link #NONE} ou {@link #UNKNOWN}. */
        int platformY = UNKNOWN;
        /** Étage dont les portes d'étage sont ouvertes, -1 aucune, {@link #DOORS_UNKNOWN} à balayer. */
        int doorFloor = DOORS_UNKNOWN;
        long seen;
        /** Bloquée dans les deux sens (affichage « — »). */
        boolean blocked;
        /** Dernier affichage d'étage envoyé aux afficheurs, et boutons d'appel allumés (bit par étage). */
        int shownIndicator = Integer.MIN_VALUE;
        long litButtons = -1L;
        /** Dernier journal d'obstruction / d'erreur (anti-répétition). */
        long lastBlockLog = Long.MIN_VALUE / 2;
        long lastErrorLog = Long.MIN_VALUE / 2;

        ActiveElevator(StoredElevator stored, ServerLevel level, CabinFootprint footprint, Direction facing,
                       int[] floorYs, TripController trip) {
            this.id = stored.elevator().id();
            this.stored = stored;
            this.level = level;
            this.footprint = footprint;
            this.facing = facing;
            this.floorYs = floorYs;
            this.trip = trip;
            int y = stored.anchor().getY();
            this.chunkProbes = new BlockPos[] {
                    new BlockPos(footprint.minX(), y, footprint.minZ()),
                    new BlockPos(footprint.maxX() - 1, y, footprint.minZ()),
                    new BlockPos(footprint.minX(), y, footprint.maxZ() - 1),
                    new BlockPos(footprint.maxX() - 1, y, footprint.maxZ() - 1),
                    // Rangée de palier (portes d'étage), qui peut être dans un autre chunk.
                    new BlockPos(footprint.cellX(0, -1), y, footprint.cellZ(0, -1)),
                    new BlockPos(footprint.cellX(footprint.width() - 1, -1), y, footprint.cellZ(footprint.width() - 1, -1))
            };
        }
    }

    // --- Cycle de vie ----------------------------------------------------------------------------

    static void start(MinecraftServer server) {
        instance = new ElevatorService(server);
        ServerHooks.setSelectionService(instance);
    }

    static void stop() {
        ServerHooks.setSelectionService(null);
        instance = null;
    }

    /** Service du serveur en cours, nul hors d'une partie. */
    @Nullable
    public static ElevatorService current() {
        return instance;
    }

    /** Vrai si cette cabine est celle que le service gère actuellement pour son ascenseur. */
    static boolean isLiveCabin(CabinEntity cabin) {
        ElevatorService s = instance;
        if (s == null || cabin.elevatorId() == null) {
            return false;
        }
        ActiveElevator a = s.active.get(cabin.elevatorId());
        return a != null && a.cabin == cabin;
    }

    /** À appeler après avoir remplacé un ascenseur dans {@link ElevatorData} (réglage admin). */
    public static void notifyElevatorUpdated(StoredElevator stored) {
        ElevatorService s = instance;
        if (s != null) {
            s.onElevatorUpdated(stored);
        }
    }

    // --- Tick ------------------------------------------------------------------------------------

    /** Début de tick serveur : avance les trajets, place les cabines, gère départs et arrivées. */
    void tickStart() {
        tickStamp++;
        ElevatorData data = ElevatorData.get(server);
        for (StoredElevator stored : data.all()) {
            ServerLevel level = server.getLevel(stored.dim());
            if (level == null) {
                continue; // dimension indisponible : ignorée (l'état éventuel est retiré plus bas)
            }
            UUID id = stored.elevator().id();
            ActiveElevator a = active.get(id);
            try {
                if (a == null) {
                    a = activate(stored, level);
                    active.put(id, a);
                } else if (a.stored != stored) {
                    a = refresh(a, stored, level);
                }
                a.seen = tickStamp;
                checkObstruction(a);
                checkDoorSensor(a);
                a.trip.tick();
                applyTripState(a);
            } catch (RuntimeException e) {
                // Une erreur sur un ascenseur ne doit jamais casser le tick serveur : il est sauté ce tick-ci.
                if (a != null) {
                    a.seen = tickStamp;
                }
                logError(a, stored.elevator().name(), e);
            }
        }
        Iterator<ActiveElevator> it = active.values().iterator();
        while (it.hasNext()) {
            ActiveElevator a = it.next();
            if (a.seen != tickStamp) {
                it.remove();
                deactivate(a, null, nearestFloorY(a));
                if (data.byId(a.id).isEmpty()) {
                    CabinStateData.get(server).remove(a.id);
                }
            }
        }
    }

    /**
     * Retire immédiatement un ascenseur du monde (suppression par un admin, Task 10b) : les joueurs
     * de la cabine (passagers ou à pied) sont déposés sur le palier de l'étage le plus proche, devant
     * la porte, jamais dans la gaine ; la cabine et le plancher invisible sont retirés et la hauteur
     * d'arrêt sauvegardée est oubliée. À appeler après avoir retiré l'ascenseur de
     * {@link ElevatorData}, sinon il est réactivé au tick suivant.
     */
    public void release(UUID elevatorId) {
        release(elevatorId, null);
    }

    /**
     * Comme {@link #release(UUID)} ; {@code removed} (l'ascenseur tel qu'il était sauvegardé) permet
     * de nettoyer plus tard la gaine d'un ascenseur qui n'était pas actif (dimension déchargée).
     */
    public void release(UUID elevatorId, @Nullable StoredElevator removed) {
        ActiveElevator a = active.remove(elevatorId);
        if (a != null) {
            deactivate(a, null, nearestFloorY(a));
        } else if (removed != null) {
            CabinStateData.get(server).addPendingCleanup(removed);
        }
        CabinStateData.get(server).remove(elevatorId);
    }

    /**
     * Relie à nouveau les portes et boutons d'un ascenseur après un réglage admin (étages par
     * hauteur, voir {@link ElevatorBlocks#relink}) ; les portes d'étage sont ensuite remises en ordre.
     */
    public void relink(UUID elevatorId) {
        relink(elevatorId, null);
    }

    /** Comme {@link #relink(UUID)}, en balayant aussi l'ancienne gaine {@code previous}. */
    public void relink(UUID elevatorId, @Nullable StoredElevator previous) {
        Optional<StoredElevator> now = ElevatorData.get(server).byId(elevatorId);
        if (now.isEmpty()) {
            return;
        }
        ServerLevel level = server.getLevel(now.get().dim());
        if (level == null) {
            return;
        }
        ElevatorBlocks.relink(level, now.get(), previous);
        ActiveElevator a = active.get(elevatorId);
        if (a != null) {
            a.doorFloor = DOORS_UNKNOWN;
            a.shownIndicator = Integer.MIN_VALUE;
            a.litButtons = -1L;
            reconcileDoors(a);
        }
    }

    // --- Obstruction -----------------------------------------------------------------------------

    /**
     * Avant chaque pas d'un trajet : si la couche de blocs dans laquelle la cabine va entrer est
     * occupée, le trajet est interrompu et la cabine revient à l'étage qu'elle a quitté. Si le retour
     * est bloqué aussi, la cabine attend sur place et ses passagers sont déposés sur le palier de
     * l'étage le plus proche (jamais poussés dans un mur). Seulement en mouvement et gaine chargée.
     */
    private void checkObstruction(ActiveElevator a) {
        a.blocked = false;
        if (a.trip.phase() != TripController.Phase.MOVING || !isPresent(a) || !isBlockedAhead(a)) {
            return;
        }
        TripController.Obstruction outcome = a.trip.obstructed();
        if (outcome == TripController.Obstruction.REVERSED) {
            tellRiders(a, "Passage obstrué : retour à l'étage précédent.");
            saveRest(a, a.floorYs[a.trip.targetFloor()]);
            if (!isBlockedAhead(a)) {
                return;
            }
            outcome = a.trip.obstructed();
        }
        if (outcome == TripController.Obstruction.HELD) {
            a.blocked = true;
            evacuateRiders(a);
        }
    }

    /** Vrai si un bloc solide occupe la couche où la cabine entre au prochain pas (toute l'empreinte). */
    private boolean isBlockedAhead(ActiveElevator a) {
        int layer = TripController.leadingLayer(a.trip.y(), a.trip.nextY(), CabinFootprint.INTERIOR_HEIGHT);
        if (layer == TripController.NO_LAYER || a.level.isOutsideBuildHeight(layer)) {
            return false;
        }
        Block floorBlock = ModBlocks.CABIN_FLOOR.get();
        Block console = ModBlocks.CABIN.get();
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        for (int x = a.footprint.minX(); x < a.footprint.maxX(); x++) {
            for (int z = a.footprint.minZ(); z < a.footprint.maxZ(); z++) {
                pos.set(x, layer, z);
                BlockState state = a.level.getBlockState(pos);
                if (state.isAir() || state.is(floorBlock) || state.is(console) || state.is(ModBlocks.CABIN_WALL.get())) {
                    continue;
                }
                // Bloc solide, mais aussi lave et feu : jamais de passagers à travers.
                if (!state.getCollisionShape(a.level, pos).isEmpty()
                        || state.getFluidState().is(net.minecraft.tags.FluidTags.LAVA) || state.is(BlockTags.FIRE)) {
                    if (a.lastBlockLog + LOG_PERIOD <= tickStamp) {
                        a.lastBlockLog = tickStamp;
                        LOGGER.info("[Ascenseur] Gaine obstruée : « {} » ({}) par {} en {} {} {}",
                                a.stored.elevator().name(), a.level.dimension().location(),
                                state.getBlock().getName().getString(), x, layer, z);
                    }
                    return true;
                }
            }
        }
        return false;
    }

    private void tellRiders(ActiveElevator a, String message) {
        if (a.cabin == null) {
            return;
        }
        for (Entity rider : a.cabin.getPassengers()) {
            if (rider instanceof ServerPlayer p) {
                p.displayClientMessage(Component.literal(message), true);
            }
        }
    }

    /** Cabine bloquée dans les deux sens : passagers déposés sur le palier de l'étage le plus proche. */
    private void evacuateRiders(ActiveElevator a) {
        if (a.cabin == null) {
            return;
        }
        int floorY = nearestFloorY(a);
        for (Entity rider : List.copyOf(a.cabin.getPassengers())) {
            if (rider instanceof ServerPlayer p) {
                Vec3 spot = landingSpot(a.level, p, a.footprint, a.floorYs, floorY);
                relocate(p, spot.x, spot.y, spot.z);
                p.displayClientMessage(Component.literal("Passage obstrué : vous avez été déposé à l'étage."), true);
            }
        }
    }

    // --- Nettoyages en attente -------------------------------------------------------------------

    /**
     * Gaine retirée alors que ses chunks n'étaient pas chargés : planchers invisibles et portes
     * d'étage sont remis en ordre dès que toute la gaine est chargée (vérifié toutes les secondes,
     * liste vide en temps normal). Un plancher utilisé par un ascenseur actif n'est jamais retiré.
     */
    private void runPendingCleanups() {
        CabinStateData state = CabinStateData.get(server);
        if (state.pendingCleanups().isEmpty() || tickStamp % CLEANUP_PERIOD != 0) {
            return;
        }
        ElevatorData data = ElevatorData.get(server);
        for (StoredElevator s : List.copyOf(state.pendingCleanups())) {
            ServerLevel level = server.getLevel(s.dim());
            if (level == null) {
                continue;
            }
            CabinFootprint fp = ElevatorBlocks.footprintOf(s);
            if (!shaftLoaded(level, fp, s.anchor().getY()) || overlapsUnknownPlatform(level, fp)) {
                continue;
            }
            UUID id = s.elevator().id();
            Optional<StoredElevator> current = data.byId(id);
            CabinFootprint skipRow = current.map(ElevatorBlocks::footprintOf).orElse(null);
            int[] ys = ElevatorBlocks.floorYs(s.elevator());
            for (int floorY : ys) {
                ElevatorBlocks.applyDoors(level, id, fp, floorY, -1, skipRow, s.style());
                final int fy = floorY;
                setShell(level, fp, floorY, false, (x, z) -> isLivePlatform(level, x, fy - 1, z));
            }
            state.removePendingCleanup(s);
        }
    }

    private static boolean shaftLoaded(ServerLevel level, CabinFootprint fp, int y) {
        return level.hasChunkAt(new BlockPos(fp.minX(), y, fp.minZ()))
                && level.hasChunkAt(new BlockPos(fp.maxX() - 1, y, fp.minZ()))
                && level.hasChunkAt(new BlockPos(fp.minX(), y, fp.maxZ() - 1))
                && level.hasChunkAt(new BlockPos(fp.maxX() - 1, y, fp.maxZ() - 1))
                && level.hasChunkAt(new BlockPos(fp.cellX(0, -1), y, fp.cellZ(0, -1)))
                && level.hasChunkAt(new BlockPos(fp.cellX(fp.width() - 1, -1), y, fp.cellZ(fp.width() - 1, -1)));
    }

    /** Vrai si ce bloc est le plancher posé (ou à poser) d'un ascenseur actif. */
    private boolean isLivePlatform(ServerLevel level, int x, int y, int z) {
        for (ActiveElevator a : active.values()) {
            if (a.level == level && a.footprint.containsXZ(x + 0.5, z + 0.5)
                    && a.platformY == y + 1) {
                return true;
            }
        }
        return false;
    }

    /** Un ascenseur actif sur ces cases n'a pas encore fait son propre nettoyage : on attend. */
    private boolean overlapsUnknownPlatform(ServerLevel level, CabinFootprint fp) {
        for (ActiveElevator a : active.values()) {
            if (a.level == level && a.platformY == UNKNOWN
                    && a.footprint.minX() < fp.maxX() && fp.minX() < a.footprint.maxX()
                    && a.footprint.minZ() < fp.maxZ() && fp.minZ() < a.footprint.maxZ()) {
                return true;
            }
        }
        return false;
    }

    /**
     * Fin de tick serveur (après l'envoi des changements de blocs et d'entités) : descente des
     * passagers à l'arrivée, retrait du plancher au départ, reprise des joueurs restés dans
     * l'empreinte pendant un trajet.
     */
    void tickEnd() {
        for (Relocation r : pendingTeleports) {
            ServerPlayer p = r.player();
            if (!p.isRemoved() && !p.isPassenger()) {
                p.resetFallDistance();
                p.connection.teleport(r.x(), r.y(), r.z(), p.getYRot(), p.getXRot());
            }
        }
        pendingTeleports.clear();
        for (ActiveElevator a : active.values()) {
            try {
                if (a.alightPending) {
                    a.alightPending = false;
                    alightPlayers(a);
                }
                reconcilePlatform(a);
                if (a.boarded && a.cabin != null && !a.cabin.isRemoved()) {
                    boardPlayers(a);
                }
            } catch (RuntimeException e) {
                logError(a, a.stored.elevator().name(), e);
            }
        }
        try {
            runPendingCleanups();
            runLoginChecks();
        } catch (RuntimeException e) {
            if (tickStamp % LOG_PERIOD == 0) {
                LOGGER.error("[Ascenseur] Erreur dans les tâches différées", e);
            }
        }
    }

    private void logError(@Nullable ActiveElevator a, String name, RuntimeException e) {
        if (a == null ? tickStamp % LOG_PERIOD == 1 : a.lastErrorLog + LOG_PERIOD <= tickStamp) {
            if (a != null) {
                a.lastErrorLog = tickStamp;
            }
            LOGGER.error("[Ascenseur] Erreur sur l'ascenseur « {} » (ignoré ce tick)", name, e);
        }
    }

    // --- Capteur de porte -------------------------------------------------------------------------

    /**
     * Pendant la fermeture des portes : un joueur (hors passagers) dans l'embrasure (bande de part et
     * d'autre de la façade de la cabine) fait rouvrir les portes, quelques fois au plus ; ensuite, il
     * est déposé sur le palier pour ne jamais rester à cheval sur une porte fermée au-dessus du vide.
     */
    private void checkDoorSensor(ActiveElevator a) {
        if (a.trip.phase() != TripController.Phase.DOORS_CLOSING || !isPresent(a)) {
            return;
        }
        double[] d = a.footprint.doorway(DOORWAY_DEPTH);
        double floorY = a.trip.y();
        AABB doorway = new AABB(d[0], floorY, d[1], d[2], floorY + CabinFootprint.INTERIOR_HEIGHT, d[3]);
        List<ServerPlayer> inDoorway = new ArrayList<>();
        for (ServerPlayer p : a.level.players()) {
            if (!p.isSpectator() && p.isAlive() && !p.isPassenger() && p.getBoundingBox().intersects(doorway)) {
                inDoorway.add(p);
            }
        }
        if (inDoorway.isEmpty() || a.trip.doorObstructed()) {
            return;
        }
        int y = a.floorYs[a.trip.currentFloor()];
        for (ServerPlayer p : inDoorway) {
            Vec3 spot = landingSpot(a.level, p, a.footprint, a.floorYs, y);
            relocate(p, spot.x, spot.y, spot.z);
            p.displayClientMessage(Component.literal("Attention à la fermeture des portes."), true);
        }
    }

    // --- Connexion : jamais dans le vide de la gaine ----------------------------------------------

    private final Map<UUID, Long> loginChecks = new HashMap<>();

    /** Un joueur se connecte : vérifié un peu plus tard, une fois son chunk chargé. */
    void onPlayerLoggedIn(ServerPlayer player) {
        loginChecks.put(player.getUUID(), tickStamp + LOGIN_DELAY);
    }

    private void runLoginChecks() {
        if (loginChecks.isEmpty()) {
            return;
        }
        Iterator<Map.Entry<UUID, Long>> it = loginChecks.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Long> e = it.next();
            if (e.getValue() > tickStamp) {
                continue;
            }
            ServerPlayer p = server.getPlayerList().getPlayer(e.getKey());
            if (p == null || rescueIfInShaft(p) || tickStamp - e.getValue() > LOGIN_GIVE_UP) {
                it.remove();
            }
        }
    }

    /**
     * Joueur dans la colonne d'une gaine sans y être en sécurité (cabine absente, en trajet, ou à une
     * autre hauteur) : déposé sur le palier de l'étage le plus proche. Renvoie faux s'il faut attendre
     * que la gaine soit chargée.
     */
    private boolean rescueIfInShaft(ServerPlayer p) {
        if (p.isPassenger() || p.isSpectator()) {
            return true;
        }
        for (ActiveElevator a : active.values()) {
            if (p.level() != a.level || !a.footprint.containsXZ(p.getX(), p.getZ())) {
                continue;
            }
            double low = a.floorYs[0] - 1;
            double high = a.floorYs[a.floorYs.length - 1] + CabinFootprint.INTERIOR_HEIGHT;
            if (p.getY() < low || p.getY() > high) {
                continue;
            }
            if (!isPresent(a)) {
                return false;
            }
            boolean stopped = a.trip.phase() != TripController.Phase.MOVING && !a.boarded;
            int cabinY = a.floorYs[a.trip.currentFloor()];
            if (stopped && a.platformY == cabinY && a.footprint.contains(p.getX(), p.getY(), p.getZ(), cabinY)) {
                return true; // debout dans la cabine arrêtée : rien à faire
            }
            int nearest = a.floorYs[FloorRemap.nearest(a.floorYs, p.getY())];
            Vec3 spot = landingSpot(a.level, p, a.footprint, a.floorYs, nearest);
            relocate(p, spot.x, spot.y, spot.z);
            p.displayClientMessage(Component.literal("Vous avez été déposé sur le palier."), true);
            return true;
        }
        return true;
    }

    private ActiveElevator activate(StoredElevator stored, ServerLevel level) {
        Elevator e = stored.elevator();
        Direction facing = stored.facing().getAxis().isHorizontal() ? stored.facing() : Direction.NORTH;
        CabinFootprint footprint = CabinFootprint.of(stored.anchor().getX(), stored.anchor().getZ(),
                e.size(), facing.getStepX(), facing.getStepZ());
        int[] ys = floorYs(e);
        TripController trip = new TripController(ys, 0, CabinTuning.blocksPerTick(), CabinTuning.doorTicks());
        // Reprise : hauteur d'arrêt sauvegardée, sinon l'étage le plus proche de l'ancre.
        OptionalInt rest = CabinStateData.get(server).restY(e.id());
        trip.reset(rest.isPresent() ? rest.getAsInt() : stored.anchor().getY());
        ActiveElevator a = new ActiveElevator(stored, level, footprint, facing, ys, trip);
        saveRest(a, ys[trip.currentFloor()]);
        return a;
    }

    /** Applique un ascenseur modifié ; renvoie l'état à utiliser (nouveau si la géométrie a changé). */
    private ActiveElevator refresh(ActiveElevator a, StoredElevator stored, ServerLevel level) {
        if (a.level != level || !sameGeometry(a.stored, stored)) {
            // Le nouvel état reprend à la hauteur d'arrêt sauvegardée (destination si trajet en cours) :
            // les joueurs sont déposés à ce même étage, et le plancher y est posé dans le même appel.
            ActiveElevator fresh = activate(stored, level);
            int safeY = fresh.floorYs[fresh.trip.currentFloor()];
            deactivate(a, fresh, safeY);
            active.put(fresh.id, fresh);
            return fresh;
        }
        a.stored = stored;
        int[] ys = floorYs(stored.elevator());
        if (!Arrays.equals(ys, a.floorYs)) {
            boolean stopped = a.trip.phase() != TripController.Phase.MOVING;
            double oldY = a.trip.y();
            boolean present = isPresent(a);
            List<ServerPlayer> standing = stopped && present ? playersStandingIn(a, oldY) : List.of();
            a.floorYs = ys;
            a.doorFloor = DOORS_UNKNOWN; // index d'étage changé : toutes les ouvertures sont revues
            a.litButtons = -1L;
            a.shownIndicator = Integer.MIN_VALUE;
            boolean moved = a.trip.remapFloorsByHeight(ys);
            if (moved && stopped && present) {
                // L'étage de la cabine n'existe plus : plancher posé au nouvel étage, puis les joueurs.
                a.present = true;
                reconcilePlatform(a);
                for (ServerPlayer p : standing) {
                    relocate(p, a.footprint.clampX(p.getX(), RIDER_MARGIN), a.trip.y(),
                            a.footprint.clampZ(p.getZ(), RIDER_MARGIN));
                }
            }
        }
        return a;
    }

    private void onElevatorUpdated(StoredElevator stored) {
        UUID id = stored.elevator().id();
        ActiveElevator a = active.get(id);
        if (a == null) {
            return; // activé au prochain tick
        }
        ServerLevel level = server.getLevel(stored.dim());
        if (level == null) {
            active.remove(id);
            deactivate(a, null, nearestFloorY(a));
            return;
        }
        applyTripState(refresh(a, stored, level));
    }

    /** Fait suivre au monde l'état du contrôleur (départ, arrivée, position de la cabine). */
    private void applyTripState(ActiveElevator a) {
        a.present = isPresent(a);
        if (a.present) {
            ensureCabin(a);
        } else if (a.cabin != null && a.cabin.isRemoved()) {
            a.cabin = null;
        }
        boolean moving = a.trip.phase() == TripController.Phase.MOVING;
        if (moving && !a.boarded) {
            // Départ : la cabine n'a pas encore bougé ce tick-ci.
            a.boarded = true;
            a.alightPending = false;
            if (a.cabin != null) {
                boardPlayers(a);
            }
            saveRest(a, a.floorYs[a.trip.targetFloor()]);
        } else if (!moving && a.boarded) {
            // Arrivée (ou trajet interrompu par un réglage) : le plancher d'abord, la descente en fin de tick.
            a.boarded = false;
            reconcilePlatform(a);
            a.alightPending = true;
            saveRest(a, a.floorYs[a.trip.currentFloor()]);
        }
        updateCabin(a, moving);
        reconcileDoors(a);
        reconcileSignals(a);
    }

    // --- Afficheurs d'étage et voyants des boutons d'appel ------------------------------------------

    /**
     * Afficheurs et voyants suivent l'état du trajet, mais le monde n'est lu et écrit que lorsqu'une
     * valeur change (arrivée, départ, étage franchi, appel) ; gaine non chargée : revu au retour.
     */
    private void reconcileSignals(ActiveElevator a) {
        if (!a.present) {
            a.shownIndicator = Integer.MIN_VALUE;
            a.litButtons = -1L;
            return;
        }
        int value = indicatorValue(a);
        if (value != a.shownIndicator) {
            ElevatorBlocks.applyIndicators(a.level, a.id, a.footprint, a.floorYs, value);
            a.shownIndicator = value;
        }
        long lit = 0L;
        for (int i = 0; i < a.floorYs.length && i < 64; i++) {
            if (a.trip.isServing(i)) {
                lit |= 1L << i;
            }
        }
        if (lit != a.litButtons) {
            long changed = a.litButtons == -1L ? ~0L : lit ^ a.litButtons;
            ElevatorBlocks.applyButtons(a.level, a.id, a.footprint, a.floorYs, lit, changed);
            a.litButtons = lit;
        }
    }

    /** Valeur à afficher pour cet ascenseur (afficheur fraîchement posé) ; -1 s'il n'est pas actif. */
    public int indicatorValue(UUID elevatorId) {
        ActiveElevator a = active.get(elevatorId);
        return a == null ? -1 : indicatorValue(a);
    }

    /** Ascenseur retiré du monde : afficheurs sur « — », voyants éteints (chunks chargés). */
    private void clearSignals(ActiveElevator a) {
        ElevatorBlocks.applyIndicators(a.level, a.id, a.footprint, a.floorYs, -1);
        ElevatorBlocks.applyButtons(a.level, a.id, a.footprint, a.floorYs, 0L, ~0L);
    }

    // --- Portes d'étage ---------------------------------------------------------------------------

    /**
     * Portes d'étage : seules celles de l'étage où la cabine est arrêtée portes ouvertes sont
     * ouvertes. Changement d'étage : deux ouvertures mises à jour ; état inconnu (activation,
     * redémarrage, gaine rechargée, réglage) : toutes les ouvertures sont remises en ordre.
     */
    private void reconcileDoors(ActiveElevator a) {
        if (!a.present) {
            a.doorFloor = DOORS_UNKNOWN; // à revoir quand la gaine sera de nouveau chargée
            return;
        }
        int desired = doorsOpen(a.trip) ? a.trip.currentFloor() : -1;
        if (desired == a.doorFloor) {
            return;
        }
        boolean complete = true;
        if (a.doorFloor == DOORS_UNKNOWN) {
            for (int y : a.floorYs) {
                complete &= ElevatorBlocks.applyDoors(a.level, a.id, a.footprint, y, desired, null, a.stored.style());
            }
        } else {
            if (a.doorFloor >= 0) {
                complete &= ElevatorBlocks.applyDoors(a.level, a.id, a.footprint, a.floorYs[a.doorFloor], desired, null, a.stored.style());
            }
            if (desired >= 0) {
                complete &= ElevatorBlocks.applyDoors(a.level, a.id, a.footprint, a.floorYs[desired], desired, null, a.stored.style());
            }
        }
        a.doorFloor = complete ? desired : DOORS_UNKNOWN;
    }

    /** Ferme toutes les portes d'étage de l'ascenseur (chunks chargés). */
    private void closeAllDoors(ActiveElevator a) {
        for (int y : a.floorYs) {
            ElevatorBlocks.applyDoors(a.level, a.id, a.footprint, y, -1, null, a.stored.style());
        }
        a.doorFloor = DOORS_UNKNOWN;
    }

    // --- Cabine ----------------------------------------------------------------------------------

    private boolean isPresent(ActiveElevator a) {
        for (BlockPos probe : a.chunkProbes) {
            if (!a.level.isPositionEntityTicking(probe)) {
                return false;
            }
        }
        return true;
    }

    private void ensureCabin(ActiveElevator a) {
        if (a.cabin != null && !a.cabin.isRemoved()) {
            return;
        }
        a.cabin = null;
        CabinEntity cabin = ModEntities.CABIN.get().create(a.level);
        if (cabin == null) {
            return;
        }
        cabin.configure(a.id, a.footprint, a.facing);
        syncLook(a, cabin);
        cabin.moveTo(a.footprint.centerX(), a.trip.y(), a.footprint.centerZ(), 0.0F, 0.0F);
        boolean moving = a.trip.phase() == TripController.Phase.MOVING;
        cabin.syncState(moving, targetY(a, moving), (float) a.trip.blocksPerTick(), doorsOpen(a.trip));
        if (a.level.addFreshEntity(cabin)) {
            a.cabin = cabin;
        }
    }

    private void updateCabin(ActiveElevator a, boolean moving) {
        CabinEntity cabin = a.cabin;
        if (cabin == null) {
            return;
        }
        double x = a.footprint.centerX();
        double y = a.trip.y();
        double z = a.footprint.centerZ();
        if (cabin.getX() != x || cabin.getY() != y || cabin.getZ() != z) {
            cabin.setPos(x, y, z);
        }
        cabin.syncState(moving, targetY(a, moving), (float) a.trip.blocksPerTick(), doorsOpen(a.trip));
        syncLook(a, cabin);
    }

    private void syncLook(ActiveElevator a, CabinEntity cabin) {
        cabin.syncLook(a.stored.style().colorIndex(), a.stored.style().effectiveGlass(a.footprint), indicatorValue(a));
    }

    /** Affichage d'étage compact : étage le plus proche de la cabine, sens de marche ; « — » si bloquée. */
    private static int indicatorValue(ActiveElevator a) {
        int floor = FloorRemap.nearest(a.floorYs, a.trip.y());
        return FloorIndicator.pack(!a.blocked, floor, a.trip.direction());
    }

    private static int targetY(ActiveElevator a, boolean moving) {
        int floor = moving ? a.trip.targetFloor() : a.trip.currentFloor();
        return a.floorYs[floor];
    }

    private static boolean doorsOpen(TripController trip) {
        return trip.phase() == TripController.Phase.IDLE || trip.phase() == TripController.Phase.DOORS_OPENING;
    }

    // --- Passagers -------------------------------------------------------------------------------

    /**
     * Fait monter dans la cabine (comme passagers) les joueurs dont les pieds, ou ceux de leur
     * monture, sont dans l'empreinte. Un joueur monté (cheval, cochon…) descend d'abord sur place :
     * seul le joueur est transporté, la monture tombe au fond de la gaine sans dégâts. Ainsi aucune
     * chute de monture ne peut blesser un joueur (il n'en est plus passager).
     */
    private void boardPlayers(ActiveElevator a) {
        CabinEntity cabin = a.cabin;
        double floorY = a.trip.y();
        for (ServerPlayer p : a.level.players()) {
            if (p.isSpectator() || !p.isAlive()) {
                continue;
            }
            Entity vehicle = p.getVehicle();
            if (vehicle instanceof CabinEntity) {
                continue;
            }
            Entity feet = p.getRootVehicle();
            if (!a.footprint.contains(feet.getX(), feet.getY(), feet.getZ(), floorY)) {
                continue;
            }
            if (vehicle != null) {
                double x = p.getX();
                double z = p.getZ();
                p.stopRiding();
                if (p.isPassenger()) {
                    continue; // descente refusée par un autre mod : on ne force pas
                }
                // Pas de dépose « à côté de la monture » : le joueur reste à sa place, sur le plancher.
                p.moveTo(a.footprint.clampX(x, RIDER_MARGIN), floorY, a.footprint.clampZ(z, RIDER_MARGIN),
                        p.getYRot(), p.getXRot());
            }
            // force = true : ignore le délai de remontée de 3 s après une descente.
            if (p.startRiding(cabin, true)) {
                p.resetFallDistance();
            }
        }
    }

    /**
     * Déplace un joueur (hors de tout véhicule) et l'annonce au client tout de suite, puis une
     * seconde fois en fin de tick, après l'envoi des changements de blocs (plancher posé).
     */
    private void relocate(ServerPlayer p, double x, double y, double z) {
        if (p.isPassenger()) {
            p.stopRiding();
        }
        p.moveTo(x, y, z, p.getYRot(), p.getXRot());
        p.resetFallDistance();
        p.connection.teleport(x, y, z, p.getYRot(), p.getXRot());
        pendingTeleports.add(new Relocation(p, x, y, z));
    }

    /** Joueurs à pied (non passagers) dans la cabine arrêtée à {@code floorY}. */
    private List<ServerPlayer> playersStandingIn(ActiveElevator a, double floorY) {
        List<ServerPlayer> found = new ArrayList<>();
        for (ServerPlayer p : a.level.players()) {
            if (!p.isSpectator() && p.isAlive() && !p.isPassenger()
                    && a.footprint.contains(p.getX(), p.getY(), p.getZ(), floorY)) {
                found.add(p);
            }
        }
        return found;
    }

    /**
     * Place sûre sur un palier devant la porte de la cabine, jamais dans la gaine : d'abord à l'étage
     * {@code preferredY}, puis aux autres étages du plus proche au plus lointain. À un étage, les
     * cases des trois rangées devant la porte (une case de plus de chaque côté) et une hauteur de
     * -1 à +1 sont essayées ; une case convient si elle a deux blocs libres (sans collision ni liquide)
     * au-dessus d'un bloc porteur au sommet plein. On préfère la bonne hauteur, puis la rangée à deux
     * cases (la rangée juste devant porte la porte d'étage), puis la case la plus proche du joueur.
     * À défaut, la première hauteur libre au-dessus du palier (jusqu'à 8 blocs), sinon le centre du palier.
     */
    private Vec3 landingSpot(ServerLevel level, ServerPlayer p, CabinFootprint fp, int[] floorYs, int preferredY) {
        Integer[] order = new Integer[floorYs.length];
        for (int i = 0; i < order.length; i++) {
            order[i] = floorYs[i];
        }
        Arrays.sort(order, (u, v) -> Integer.compare(Math.abs(u - preferredY), Math.abs(v - preferredY)));
        List<Integer> ys = new ArrayList<>(Arrays.asList(order));
        if (!ys.contains(preferredY)) {
            ys.add(0, preferredY);
        }
        for (int floorY : ys) {
            Vec3 spot = landingAt(level, p, fp, floorY);
            if (spot != null) {
                return spot;
            }
        }
        int across = nearestAcross(fp, p, -2);
        BlockPos base = new BlockPos(fp.cellX(across, -2), preferredY, fp.cellZ(across, -2));
        for (int dy = 0; dy <= 8; dy++) {
            BlockPos feet = base.above(dy);
            if (level.isLoaded(feet) && isFreeCell(level, feet) && isFreeCell(level, feet.above())) {
                return Vec3.atBottomCenterOf(feet);
            }
        }
        return Vec3.atBottomCenterOf(base);
    }

    /** Meilleure case de palier libre à l'étage {@code floorY}, ou null. */
    @Nullable
    private Vec3 landingAt(ServerLevel level, ServerPlayer p, CabinFootprint fp, int floorY) {
        Vec3 best = null;
        double bestScore = Double.MAX_VALUE;
        for (int back = -1; back >= -3; back--) {
            int rowRank = back == -2 ? 0 : back == -1 ? 1 : 2;
            for (int across = -1; across <= fp.width(); across++) {
                for (int dy = -1; dy <= 1; dy++) {
                    BlockPos feet = new BlockPos(fp.cellX(across, back), floorY + dy, fp.cellZ(across, back));
                    if (!level.isLoaded(feet) || !isStandable(level, p, feet)) {
                        continue;
                    }
                    Vec3 spot = Vec3.atBottomCenterOf(feet);
                    double score = Math.abs(dy) * 1.0E6 + rowRank * 1.0E4 + spot.distanceToSqr(p.position());
                    if (score < bestScore) {
                        bestScore = score;
                        best = spot;
                    }
                }
            }
        }
        return best;
    }

    private static int nearestAcross(CabinFootprint fp, ServerPlayer p, int back) {
        int best = 0;
        double bestDist = Double.MAX_VALUE;
        for (int across = 0; across < fp.width(); across++) {
            double dx = fp.cellX(across, back) + 0.5 - p.getX();
            double dz = fp.cellZ(across, back) + 0.5 - p.getZ();
            if (dx * dx + dz * dz < bestDist) {
                bestDist = dx * dx + dz * dz;
                best = across;
            }
        }
        return best;
    }

    /** Deux blocs libres au-dessus d'un bloc porteur (sommet plein), sans liquide ni collision. */
    private static boolean isStandable(ServerLevel level, ServerPlayer p, BlockPos feet) {
        BlockPos below = feet.below();
        BlockState ground = level.getBlockState(below);
        if (ground.is(ModBlocks.CABIN_FLOOR.get()) || !ground.getFluidState().isEmpty()) {
            return false;
        }
        VoxelShape support = ground.getCollisionShape(level, below);
        if (support.isEmpty() || support.max(Direction.Axis.Y) < 1.0) {
            return false;
        }
        if (!isFreeCell(level, feet) || !isFreeCell(level, feet.above())) {
            return false;
        }
        AABB box = p.getDimensions(Pose.STANDING).makeBoundingBox(Vec3.atBottomCenterOf(feet));
        return level.noCollision(p, box);
    }

    private static boolean isFreeCell(ServerLevel level, BlockPos pos) {
        BlockState state = level.getBlockState(pos);
        return state.getCollisionShape(level, pos).isEmpty() && state.getFluidState().isEmpty()
                && !state.is(BlockTags.FIRE);
    }

    /**
     * Fait descendre les passagers sur place (sur le plancher posé en début de tick). L'annonce des
     * passagers est envoyée avant la position exacte, pour que le client ne se recale pas sur sa
     * propre position de cabine.
     */
    private void alightPlayers(ActiveElevator a) {
        CabinEntity cabin = a.cabin;
        if (cabin == null || cabin.isRemoved()) {
            return;
        }
        List<Entity> riders = cabin.getPassengers();
        if (riders.isEmpty()) {
            return;
        }
        for (Entity rider : riders) {
            rider.stopRiding();
        }
        a.level.getChunkSource().broadcast(cabin, new ClientboundSetPassengersPacket(cabin));
        for (Entity rider : riders) {
            if (rider instanceof ServerPlayer p && !p.isPassenger()) {
                p.resetFallDistance();
                p.connection.teleport(p.getX(), p.getY(), p.getZ(), p.getYRot(), p.getXRot());
            }
        }
    }

    /** Déconnexion d'un passager : déposé à l'étage de destination, la cabine poursuit sans lui. */
    void onPlayerLoggedOut(ServerPlayer player) {
        if (!(player.getVehicle() instanceof CabinEntity cabin)) {
            return;
        }
        UUID id = cabin.elevatorId();
        ActiveElevator a = id == null ? null : active.get(id);
        OptionalInt y = OptionalInt.empty();
        if (a != null) {
            int floor = a.trip.targetFloor() >= 0 ? a.trip.targetFloor() : a.trip.currentFloor();
            y = OptionalInt.of(a.floorYs[floor]);
        } else if (id != null) {
            y = CabinStateData.get(server).restY(id); // dernier étage connu
        }
        double x = cabin.clampX(player.getX());
        double z = cabin.clampZ(player.getZ());
        player.stopRiding();
        if (y.isPresent()) {
            player.moveTo(x, y.getAsInt(), z, player.getYRot(), player.getXRot());
        }
        player.resetFallDistance();
    }

    /**
     * Vrai si l'entité est dans la colonne d'une gaine (empreinte, du plancher le plus bas au plafond
     * le plus haut) : une chute à cet endroit ne fait pas de dégâts.
     */
    boolean isInShaft(LivingEntity entity) {
        for (ActiveElevator a : active.values()) {
            if (entity.level() != a.level || !a.footprint.containsXZ(entity.getX(), entity.getZ())) {
                continue;
            }
            double low = a.floorYs[0] - 1;
            double high = a.floorYs[a.floorYs.length - 1] + CabinFootprint.INTERIOR_HEIGHT;
            if (entity.getY() >= low && entity.getY() <= high) {
                return true;
            }
        }
        return false;
    }

    // --- Plancher invisible ----------------------------------------------------------------------

    /** Pose le plancher sous la cabine arrêtée, le retire pendant un trajet. */
    private void reconcilePlatform(ActiveElevator a) {
        if (!a.present) {
            return; // rattrapé quand les chunks de la gaine seront actifs
        }
        int desired = a.boarded ? NONE : a.floorYs[a.trip.currentFloor()];
        if (desired == a.platformY) {
            return;
        }
        removePlatformEverywhere(a, desired);
        if (desired != NONE) {
            setPlatform(a, desired, true);
        }
        a.platformY = desired;
    }

    /** Retire le plancher connu, ou tous les planchers de la gaine si sa position est inconnue. */
    private void removePlatformEverywhere(ActiveElevator a, int keepY) {
        if (a.platformY == UNKNOWN) {
            for (int y : a.floorYs) {
                if (y != keepY) {
                    setPlatform(a, y, false);
                }
            }
        } else if (a.platformY != NONE) {
            setPlatform(a, a.platformY, false);
        }
    }

    /**
     * Pose (dans l'air uniquement) ou retire (nos blocs uniquement) le plancher de l'étage
     * {@code floorY}, une case sous chaque case de l'empreinte. Jamais dans un chunk non chargé.
     */
    private void setPlatform(ActiveElevator a, int floorY, boolean place) {
        setShell(a.level, a.footprint, floorY, place, null);
    }

    /** Case (x, z) à ne pas toucher lors d'un retrait. */
    @FunctionalInterface
    interface CellFilter {
        boolean keep(int x, int z);
    }

    /**
     * Pose (dans l'air uniquement) ou retire (nos blocs uniquement) la « coque » invisible de la cabine
     * arrêtée à l'étage {@code floorY} : le plancher une case sous chaque case de l'empreinte, et les
     * parois ({@link CabinWallBlock}) sur la hauteur intérieure, côtés murés selon {@link CabinWalls},
     * plafond dans la couche haute. Jamais dans un chunk non chargé.
     */
    static void setShell(ServerLevel level, CabinFootprint fp, int floorY, boolean place, @Nullable CellFilter keep) {
        Block floorBlock = ModBlocks.CABIN_FLOOR.get();
        CabinWallBlock wallBlock = (CabinWallBlock) ModBlocks.CABIN_WALL.get();
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        for (int x = fp.minX(); x < fp.maxX(); x++) {
            for (int z = fp.minZ(); z < fp.maxZ(); z++) {
                if (!place && keep != null && keep.keep(x, z)) {
                    continue;
                }
                int sides = CabinWalls.sides(fp, x, z);
                for (int dy = -1; dy < CabinFootprint.INTERIOR_HEIGHT; dy++) {
                    int y = floorY + dy;
                    boolean ceiling = dy == CabinFootprint.INTERIOR_HEIGHT - 1;
                    if (dy >= 0 && sides == 0 && !ceiling) {
                        continue;
                    }
                    pos.set(x, y, z);
                    if (level.isOutsideBuildHeight(y) || !level.isLoaded(pos)) {
                        continue;
                    }
                    BlockState current = level.getBlockState(pos);
                    if (place) {
                        if (current.isAir()) {
                            BlockState wanted = dy < 0 ? floorBlock.defaultBlockState() : wallBlock.stateFor(sides, ceiling);
                            level.setBlock(pos.immutable(), wanted, Block.UPDATE_CLIENTS);
                        }
                    } else if (current.is(floorBlock) || current.is(wallBlock)) {
                        level.setBlock(pos.immutable(), Blocks.AIR.defaultBlockState(), Block.UPDATE_CLIENTS);
                    }
                }
            }
        }
    }

    /**
     * Retire un état d'ascenseur du monde : cabine et plancher retirés, joueurs de la cabine
     * (passagers et, cabine arrêtée, joueurs à pied) déposés à l'étage {@code safeY}.
     *
     * <p>Avec un {@code successor} (même ascenseur reconstruit, autre taille ou orientation) : son
     * plancher est posé dans le même appel, avant de déplacer les joueurs ; un joueur dont la case
     * reste dans la nouvelle empreinte y est posé, les autres vont sur le palier devant la porte.
     * Sans successeur (suppression) : tous vont sur le palier, jamais dans la gaine.
     */
    private void deactivate(ActiveElevator a, @Nullable ActiveElevator successor, int safeY) {
        boolean levelLoaded = server.getLevel(a.stored.dim()) == a.level;
        boolean present = levelLoaded && isPresent(a);
        List<ServerPlayer> riders = new ArrayList<>();
        CabinEntity cabin = a.cabin;
        if (cabin != null && !cabin.isRemoved()) {
            for (Entity rider : cabin.getPassengers()) {
                rider.stopRiding();
                if (rider instanceof ServerPlayer p && !p.isPassenger()) {
                    riders.add(p);
                }
            }
            cabin.discard();
        }
        a.cabin = null;
        List<ServerPlayer> standing = present && !a.boarded ? playersStandingIn(a, a.trip.y()) : List.of();
        if (present) {
            removePlatformEverywhere(a, NONE);
            a.platformY = NONE;
            // Portes fermées avant de déposer quiconque : personne ne reste dans une ouverture.
            closeAllDoors(a);
            clearSignals(a);
        } else if (successor != null || ElevatorData.get(server).byId(a.id).isEmpty()) {
            // Gaine non chargée : planchers et portes remis en ordre au chargement de ses chunks.
            CabinStateData.get(server).addPendingCleanup(a.stored);
        }
        if (successor != null) {
            successor.present = isPresent(successor);
            reconcilePlatform(successor);
        }
        if (!levelLoaded) {
            return;
        }
        for (ServerPlayer p : riders) {
            putDown(a, successor, p, safeY, true);
        }
        for (ServerPlayer p : standing) {
            putDown(a, successor, p, safeY, false);
        }
    }

    /** Dépose un joueur dans la nouvelle empreinte s'il y est encore, sinon sur le palier. */
    private void putDown(ActiveElevator a, @Nullable ActiveElevator successor, ServerPlayer p, int safeY,
                         boolean wasRider) {
        if (successor != null && successor.footprint.containsXZ(p.getX(), p.getZ())) {
            double x = successor.footprint.clampX(p.getX(), RIDER_MARGIN);
            double z = successor.footprint.clampZ(p.getZ(), RIDER_MARGIN);
            if (!wasRider && Math.abs(p.getY() - safeY) < 1.0E-3 && x == p.getX() && z == p.getZ()) {
                return; // déjà en place, sur le nouveau plancher
            }
            relocate(p, x, safeY, z);
            return;
        }
        CabinFootprint door = successor != null ? successor.footprint : a.footprint;
        int[] ys = successor != null ? successor.floorYs : a.floorYs;
        Vec3 spot = landingSpot(a.level, p, door, ys, safeY);
        relocate(p, spot.x, spot.y, spot.z);
    }

    // --- Hooks de sélection (SelectFloorPacket) --------------------------------------------------

    /** Vrai si cet ascenseur est actuellement géré (chargé et actif). */
    public boolean isActive(UUID elevatorId) {
        return active.containsKey(elevatorId);
    }

    @Override
    public Optional<TripController> tripFor(UUID elevatorId) {
        ActiveElevator a = active.get(elevatorId);
        return a == null ? Optional.empty() : Optional.of(a.trip);
    }

    /** Pieds du joueur dans l'empreinte, à la hauteur actuelle de la cabine (tolérance verticale). */
    @Override
    public boolean isInsideCabin(ServerPlayer player, StoredElevator elevator) {
        ActiveElevator a = active.get(elevator.elevator().id());
        if (a == null || player.isSpectator() || player.level() != a.level) {
            return false;
        }
        return a.footprint.contains(player.getX(), player.getY(), player.getZ(), a.trip.y());
    }

    /** Deux choix dans le même tick : seul le premier est retenu. */
    @Override
    public void onFloorSelected(ServerPlayer player, StoredElevator elevator, int floorIndex) {
        ActiveElevator a = active.get(elevator.elevator().id());
        if (a == null) {
            return;
        }
        if (a.trip.hasPendingSelection()) {
            player.displayClientMessage(Component.literal("Un autre étage est déjà choisi."), true);
            return;
        }
        a.trip.select(floorIndex);
    }

    // --- Actions des blocs et de la cabine -------------------------------------------------------

    /** Ouvre le panneau d'étages (construit selon les rôles réels du joueur). */
    public boolean openPanel(ServerPlayer player, UUID elevatorId) {
        ActiveElevator a = active.get(elevatorId);
        if (a == null) {
            return false;
        }
        ModNetwork.sendPanel(player, a.stored.elevator(), a.trip.currentFloor());
        return true;
    }

    /** Ouvre l'écran d'administration (OP uniquement). */
    public boolean openAdmin(ServerPlayer player, UUID elevatorId) {
        if (!player.hasPermissions(2)) {
            return false;
        }
        Optional<StoredElevator> stored = ElevatorData.get(server).byId(elevatorId);
        if (stored.isEmpty()) {
            return false;
        }
        ModNetwork.sendAdminPanel(player, stored.get(), "");
        return true;
    }

    /**
     * Appel de la cabine à un étage (bouton d'appel). Refusé, avec un message discret, si le joueur
     * n'a pas le rôle de l'étage. Renvoie vrai si l'appel est enregistré.
     */
    public boolean handleCall(ServerPlayer player, UUID elevatorId, int floorIndex) {
        ActiveElevator a = active.get(elevatorId);
        if (a == null || player.level() != a.level) {
            player.displayClientMessage(Component.literal("Ascenseur indisponible."), true);
            return false;
        }
        Elevator elevator = a.stored.elevator();
        if (floorIndex < 0 || floorIndex >= elevator.floors().size()) {
            player.displayClientMessage(Component.literal("Ce bouton n'est relié à aucun étage."), true);
            return false;
        }
        if (!ElevatorRules.canCall(elevator, floorIndex, ServerRoles.of(player))) {
            player.displayClientMessage(Component.literal("Cet étage est réservé."), true);
            return false;
        }
        a.trip.call(floorIndex);
        player.displayClientMessage(Component.literal("Ascenseur appelé."), true);
        return true;
    }

    /** Clic droit sur la cabine : administration pour un OP accroupi, sinon panneau si le joueur est dedans. */
    void onCabinUse(ServerPlayer player, UUID elevatorId) {
        if (player.isShiftKeyDown() && player.hasPermissions(2)) {
            openAdmin(player, elevatorId);
            return;
        }
        ActiveElevator a = active.get(elevatorId);
        if (a == null) {
            return;
        }
        if (isInsideCabin(player, a.stored)) {
            openPanel(player, elevatorId);
            return;
        }
        if (!player.isPassenger() && player.level() == a.level && a.footprint.containsXZ(player.getX(), player.getZ())) {
            // Secours : un joueur dans la gaine (hors de la cabine) appelle la cabine à l'étage le plus proche.
            int floor = FloorRemap.nearest(a.floorYs, player.getY());
            a.trip.call(floor);
            player.displayClientMessage(Component.literal("Ascenseur appelé : il vient vous chercher."), true);
            return;
        }
        player.displayClientMessage(Component.literal("Entrez dans la cabine pour choisir un étage."), true);
    }

    /** Explication d'un choix d'étage refusé (barre d'action), pour ne jamais l'ignorer en silence. */
    public static void explainRefusedSelection(ServerPlayer player, boolean inside, TripController trip,
                                               boolean roleOk) {
        String why;
        if (!inside) {
            why = "Entrez dans la cabine pour choisir un étage.";
        } else if (!trip.acceptsSelection()) {
            why = "Ascenseur en mouvement : choisissez au prochain arrêt.";
        } else if (!roleOk) {
            why = "Cet étage est réservé.";
        } else {
            return; // étage actuel : rien à faire
        }
        player.displayClientMessage(Component.literal(why), true);
    }

    /**
     * Vrai si la cabine est arrêtée à cet étage portes ouvertes (ou en train de s'ouvrir) : c'est
     * l'état où la porte d'étage doit être ouverte. Faux si l'ascenseur n'est pas actif.
     */
    public boolean isDoorOpenAt(UUID elevatorId, int floorIndex) {
        ActiveElevator a = active.get(elevatorId);
        return a != null && a.trip.currentFloor() == floorIndex && doorsOpen(a.trip);
    }

    // --- Utilitaires -----------------------------------------------------------------------------

    private void saveRest(ActiveElevator a, int y) {
        CabinStateData.get(server).setRestY(a.id, y);
    }

    private static boolean sameGeometry(StoredElevator a, StoredElevator b) {
        return a.dim().equals(b.dim())
                && a.anchor().equals(b.anchor())
                && a.facing() == b.facing()
                && a.elevator().size() == b.elevator().size();
    }

    private static int[] floorYs(Elevator e) {
        List<Floor> floors = e.floors();
        int[] ys = new int[floors.size()];
        for (int i = 0; i < ys.length; i++) {
            ys[i] = floors.get(i).y();
        }
        return ys;
    }

    /** Hauteur de l'étage le plus proche de la cabine. */
    private static int nearestFloorY(ActiveElevator a) {
        return a.floorYs[FloorRemap.nearest(a.floorYs, a.trip.y())];
    }
}
