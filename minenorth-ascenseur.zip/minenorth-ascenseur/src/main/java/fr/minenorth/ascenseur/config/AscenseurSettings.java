package fr.minenorth.ascenseur.config;

import java.util.List;
import java.util.Locale;

/** Réglages du mod, avec analyse tolérante du fichier TOML (pur Java, testable). */
public record AscenseurSettings(double vitesseBlocsParSeconde, double dureePortesSecondes) {
    public static final double SPEED_MIN = 0.5;
    public static final double SPEED_MAX = 12.0;
    public static final double DOORS_MIN = 0.5;
    public static final double DOORS_MAX = 10.0;
    public static final double DEFAULT_SPEED = 4.0;
    public static final double DEFAULT_DOORS = 2.0;

    public static final AscenseurSettings DEFAULTS = new AscenseurSettings(DEFAULT_SPEED, DEFAULT_DOORS);

    public double blocksPerTick() {
        return vitesseBlocsParSeconde / 20.0;
    }

    public int doorTicks() {
        return (int) Math.round(dureePortesSecondes * 20.0);
    }

    /** Analyse les lignes du fichier ; toute valeur absente ou invalide revient à la valeur par défaut. */
    public static AscenseurSettings parse(List<String> lines) {
        double speed = DEFAULT_SPEED;
        double doors = DEFAULT_DOORS;
        if (lines != null) {
            for (String raw : lines) {
                if (raw == null) {
                    continue;
                }
                String line = raw.trim();
                if (line.isEmpty() || line.startsWith("#")) {
                    continue;
                }
                int eq = line.indexOf('=');
                if (eq < 0) {
                    continue;
                }
                String key = line.substring(0, eq).trim().toLowerCase(Locale.ROOT);
                String value = line.substring(eq + 1);
                int comment = value.indexOf('#');
                if (comment >= 0) {
                    value = value.substring(0, comment);
                }
                value = value.trim();
                if (key.equals("vitesse_blocs_par_seconde")) {
                    speed = number(value, DEFAULT_SPEED);
                } else if (key.equals("duree_portes_secondes")) {
                    doors = number(value, DEFAULT_DOORS);
                }
            }
        }
        return new AscenseurSettings(clamp(speed, SPEED_MIN, SPEED_MAX), clamp(doors, DOORS_MIN, DOORS_MAX));
    }

    private static double number(String value, double fallback) {
        try {
            double d = Double.parseDouble(value);
            return Double.isNaN(d) || Double.isInfinite(d) ? fallback : d;
        } catch (NumberFormatException e) {
            return fallback;
        }
    }

    private static double clamp(double v, double min, double max) {
        return Math.max(min, Math.min(max, v));
    }
}
