package fr.minenorth.ascenseur.model;

/**
 * Règles de sélection. Seul le joueur qui choisit est vérifié : les passagers sont
 * transportés quel que soit leur rôle (voyage groupé).
 */
public final class ElevatorRules {
    private ElevatorRules() {
    }

    public static boolean canSelect(Elevator e, int floor, Roles r, boolean insideCabin, TripController t) {
        return insideCabin
                && t.acceptsSelection()
                && floor != t.currentFloor()
                && canCall(e, floor, r);
    }

    public static boolean canCall(Elevator e, int floor, Roles r) {
        if (floor < 0 || floor >= e.floors().size()) {
            return false;
        }
        return FloorAccess.parse(e.floors().get(floor).access()).canUse(r);
    }
}
