package fr.minenorth.ascenseur.model;

/** Un bouton du panneau : étage, libellé du rôle requis, autorisé pour le joueur, étage actuel. */
public record FloorView(int index, String name, int y, String roleLabel, boolean allowed, boolean current) {

    /** Format « 3 · Garde à vue · Police » ; pas de rôle affiché pour un étage public. */
    public String tooltip() {
        String base = index + " · " + name;
        if (roleLabel == null || roleLabel.isEmpty() || roleLabel.equals(new FloorAccess.Public().label())) {
            return base;
        }
        return base + " · " + roleLabel;
    }
}
