package fr.minenorth.ascenseur.model;

/**
 * Correspondance des étages par hauteur quand la liste des étages change (réglage admin).
 * Un étage est « le même » s'il garde exactement la même hauteur Y, quel que soit son index.
 */
public final class FloorRemap {
    private FloorRemap() {
    }

    /**
     * Pour chaque index de {@code oldYs}, l'index de la même hauteur dans {@code newYs}, ou -1 si
     * cette hauteur n'existe plus.
     */
    public static int[] byHeight(int[] oldYs, int[] newYs) {
        int[] map = new int[oldYs.length];
        for (int i = 0; i < oldYs.length; i++) {
            map[i] = indexOf(newYs, oldYs[i]);
        }
        return map;
    }

    /** Index de la hauteur {@code y} dans {@code ys}, ou -1. */
    public static int indexOf(int[] ys, int y) {
        for (int i = 0; i < ys.length; i++) {
            if (ys[i] == y) {
                return i;
            }
        }
        return -1;
    }

    /** Index de l'étage le plus proche de {@code y} (le plus bas en cas d'égalité). */
    public static int nearest(int[] ys, double y) {
        int best = 0;
        for (int i = 1; i < ys.length; i++) {
            if (Math.abs(ys[i] - y) < Math.abs(ys[best] - y)) {
                best = i;
            }
        }
        return best;
    }
}
