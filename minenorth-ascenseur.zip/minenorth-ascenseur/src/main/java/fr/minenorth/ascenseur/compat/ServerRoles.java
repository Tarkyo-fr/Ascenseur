package fr.minenorth.ascenseur.compat;

import fr.minenorth.api.MineNorth;
import fr.minenorth.ascenseur.model.Roles;
import net.minecraft.server.level.ServerPlayer;

/** Rôles d'un joueur côté serveur ; chaque lien est sûr en cas d'absence du mod concerné. */
public final class ServerRoles implements Roles {
    private final ServerPlayer p;

    private ServerRoles(ServerPlayer p) { this.p = p; }

    public static ServerRoles of(ServerPlayer p) { return new ServerRoles(p); }

    @Override public boolean isOp() { return p.hasPermissions(2); }

    @Override public boolean isPolice() {
        try {
            return MineNorth.police().isPolice(p);
        } catch (Throwable t) {
            return false;
        }
    }

    @Override public boolean isSecours() { return SecoursCompat.isSecours(p); }

    @Override public boolean isMairie() { return MairieCompat.isStaff(p); }

    @Override public boolean hasNode(String node) { return Permissions.hasNode(p, node); }

    @Override public boolean entrepriseExists(int id) { return !EntrepriseCompat.name(p.server, id).isBlank(); }

    @Override public boolean entrepriseCanOpen(int id, int minGrade) { return EntrepriseCompat.canOpen(p, id, minGrade); }
}
