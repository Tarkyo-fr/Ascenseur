package fr.minenorth.ascenseur.model;

/**
 * Empreinte au sol d'une cabine (rectangle de cases), calculée à partir de l'ancre, de la taille
 * et de l'orientation. Java pur : l'orientation est un vecteur unitaire horizontal (fx, fz).
 *
 * <p>Convention d'orientation (à respecter par les blocs) :
 * <ul>
 *   <li>{@code facing} est la direction vers laquelle s'ouvre la porte de la cabine, c'est-à-dire
 *       de l'intérieur de la cabine vers le palier ;</li>
 *   <li>l'ancre est la case avant gauche, vue de l'intérieur de la cabine en regardant la porte
 *       (vue du palier en regardant la cabine, c'est la case avant droite) ;</li>
 *   <li>la largeur s'étend vers la droite de {@code facing} (rotation horaire : nord donne est,
 *       est donne sud, sud donne ouest, ouest donne nord) ;</li>
 *   <li>la profondeur s'étend vers l'arrière, à l'opposé de {@code facing}, en s'éloignant de la porte.</li>
 * </ul>
 * Pour une cabine 2×4, la porte est donc sur un petit côté (2 cases) et un lit entre dans le sens
 * de la longueur. La rangée de porte est celle des cases {@code cell(a, 0)} ; les cases du palier
 * juste devant la porte sont {@code cell(a, -1)}.
 *
 * <p>Coordonnées : les cases sont des coordonnées de blocs ; {@link #minX()} et {@link #maxX()}
 * bornent le rectangle en coordonnées continues ({@code maxX} exclu), idem pour Z.
 */
public final class CabinFootprint {
    /** Hauteur intérieure de la cabine, en blocs (du plancher au plafond). */
    public static final int INTERIOR_HEIGHT = 3;
    /** Tolérance verticale sous le plancher pour considérer des pieds « dans la cabine ». */
    public static final double FEET_BELOW = 0.5;
    /** Tolérance verticale au-dessus du plancher (saut compris) pour des pieds « dans la cabine ». */
    public static final double FEET_ABOVE = 1.5;
    /**
     * Distance minimale entre un joueur et le bord de l'empreinte : demi-largeur d'un joueur (0,3),
     * épaisseur d'une paroi ({@link CabinWalls#THICKNESS}) et une petite marge.
     */
    public static final double RIDER_MARGIN = 0.37;

    private final int anchorX;
    private final int anchorZ;
    private final int width;
    private final int depth;
    private final int facingX;
    private final int facingZ;
    private final int minX;
    private final int maxX;
    private final int minZ;
    private final int maxZ;

    private CabinFootprint(int anchorX, int anchorZ, int width, int depth, int facingX, int facingZ) {
        this.anchorX = anchorX;
        this.anchorZ = anchorZ;
        this.width = width;
        this.depth = depth;
        this.facingX = facingX;
        this.facingZ = facingZ;
        int oppositeX = cellX(width - 1, depth - 1);
        int oppositeZ = cellZ(width - 1, depth - 1);
        this.minX = Math.min(anchorX, oppositeX);
        this.maxX = Math.max(anchorX, oppositeX) + 1;
        this.minZ = Math.min(anchorZ, oppositeZ);
        this.maxZ = Math.max(anchorZ, oppositeZ) + 1;
    }

    /**
     * @param facingX composante X de l'orientation (-1, 0 ou 1)
     * @param facingZ composante Z de l'orientation (-1, 0 ou 1) ; exactement une des deux est non nulle
     */
    public static CabinFootprint of(int anchorX, int anchorZ, CabinSize size, int facingX, int facingZ) {
        if (size == null) {
            throw new IllegalArgumentException("Taille de cabine manquante.");
        }
        if (Math.abs(facingX) + Math.abs(facingZ) != 1) {
            throw new IllegalArgumentException("Orientation invalide : " + facingX + ", " + facingZ);
        }
        return new CabinFootprint(anchorX, anchorZ, size.width(), size.depth(), facingX, facingZ);
    }

    /** Composante X de la droite de l'orientation (rotation horaire). */
    public int rightX() {
        return -facingZ;
    }

    /** Composante Z de la droite de l'orientation (rotation horaire). */
    public int rightZ() {
        return facingX;
    }

    /** X de la case située à {@code across} cases à droite de l'ancre et {@code back} cases vers l'arrière. */
    public int cellX(int across, int back) {
        return anchorX + across * rightX() - back * facingX;
    }

    /** Z de la case située à {@code across} cases à droite de l'ancre et {@code back} cases vers l'arrière. */
    public int cellZ(int across, int back) {
        return anchorZ + across * rightZ() - back * facingZ;
    }

    public int width() {
        return width;
    }

    public int depth() {
        return depth;
    }

    public int facingX() {
        return facingX;
    }

    public int facingZ() {
        return facingZ;
    }

    public int minX() {
        return minX;
    }

    /** Borne X exclue. */
    public int maxX() {
        return maxX;
    }

    public int minZ() {
        return minZ;
    }

    /** Borne Z exclue. */
    public int maxZ() {
        return maxZ;
    }

    /** Nombre de cases le long de l'axe X. */
    public int spanX() {
        return maxX - minX;
    }

    /** Nombre de cases le long de l'axe Z. */
    public int spanZ() {
        return maxZ - minZ;
    }

    public double centerX() {
        return (minX + maxX) / 2.0;
    }

    public double centerZ() {
        return (minZ + maxZ) / 2.0;
    }

    /** Vrai si le point (x, z) est dans le rectangle (bord max exclu). */
    public boolean containsXZ(double x, double z) {
        return x >= minX && x < maxX && z >= minZ && z < maxZ;
    }

    /**
     * Vrai si des pieds en (x, y, z) sont dans la cabine dont le plancher est à {@code floorY} :
     * dans le rectangle et entre {@code floorY - FEET_BELOW} et {@code floorY + FEET_ABOVE}.
     */
    public boolean contains(double x, double y, double z, double floorY) {
        return containsXZ(x, z) && y >= floorY - FEET_BELOW && y <= floorY + FEET_ABOVE;
    }

    /**
     * Embrasure de la porte de la cabine : bande de la largeur de la cabine, de {@code depth} blocs de
     * part et d'autre du plan de façade (bord de l'empreinte côté porte). Renvoie {x0, z0, x1, z1}.
     */
    public double[] doorway(double depth) {
        if (facingX == 0) {
            double edge = facingZ < 0 ? minZ : maxZ;
            return new double[] {minX, edge - depth, maxX, edge + depth};
        }
        double edge = facingX < 0 ? minX : maxX;
        return new double[] {edge - depth, minZ, edge + depth, maxZ};
    }

    /** Vrai si les deux empreintes ont au moins une colonne (case X/Z) en commun. */
    public boolean overlaps(CabinFootprint other) {
        return minX < other.maxX && other.minX < maxX && minZ < other.maxZ && other.minZ < maxZ;
    }

    /** Ramène x dans le rectangle, à au moins {@code margin} des bords. */
    public double clampX(double x, double margin) {
        return clampInside(x, centerX(), spanX() / 2.0, margin);
    }

    /** Ramène z dans le rectangle, à au moins {@code margin} des bords. */
    public double clampZ(double z, double margin) {
        return clampInside(z, centerZ(), spanZ() / 2.0, margin);
    }

    /**
     * Ramène {@code value} dans {@code [center - half + margin, center + half - margin]} ;
     * si la marge ne laisse aucune place, renvoie le centre.
     */
    public static double clampInside(double value, double center, double half, double margin) {
        double low = center - half + margin;
        double high = center + half - margin;
        if (low > high) {
            return center;
        }
        return Math.max(low, Math.min(high, value));
    }
}
