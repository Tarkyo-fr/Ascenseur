package fr.minenorth.ascenseur.model;

import java.util.Locale;
import java.util.Optional;

/** Dimensions de la cabine (largeur x profondeur, en blocs). */
public enum CabinSize {
    S1X1(1, 1),
    S1X2(1, 2),
    S2X2(2, 2),
    S2X4(2, 4),
    S4X4(4, 4);

    private final int width;
    private final int depth;

    CabinSize(int width, int depth) {
        this.width = width;
        this.depth = depth;
    }

    public int width() {
        return width;
    }

    public int depth() {
        return depth;
    }

    /** Parse une taille de la forme "2x4" ; vide si inconnue. */
    public static Optional<CabinSize> parse(String text) {
        if (text == null) {
            return Optional.empty();
        }
        String t = text.trim().toLowerCase(Locale.ROOT);
        for (CabinSize s : values()) {
            if (t.equals(s.width + "x" + s.depth)) {
                return Optional.of(s);
            }
        }
        return Optional.empty();
    }
}
