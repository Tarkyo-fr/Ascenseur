package fr.minenorth.ascenseur.network;

import fr.minenorth.ascenseur.cabin.ElevatorService;
import fr.minenorth.ascenseur.cabin.ElevatorBlocks;
import fr.minenorth.ascenseur.model.CabinFootprint;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import fr.minenorth.ascenseur.data.ElevatorData;
import fr.minenorth.ascenseur.data.StoredElevator;
import fr.minenorth.ascenseur.model.CabinSize;
import fr.minenorth.ascenseur.model.Elevator;
import fr.minenorth.ascenseur.model.ElevatorStyle;
import fr.minenorth.ascenseur.model.Floor;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Supplier;

/** Client vers serveur : enregistre la configuration d'un ascenseur (OP uniquement). */
public record AdminSavePacket(UUID id, String name, String size, List<Floor> floors, int color, int glass) {

    public static void encode(AdminSavePacket p, FriendlyByteBuf b) {
        b.writeUUID(p.id);
        b.writeUtf(p.name, PacketLimits.MAX_NAME);
        b.writeUtf(p.size, PacketLimits.MAX_SIZE);
        PacketLimits.writeFloors(b, p.floors);
        b.writeByte(p.color);
        b.writeByte(p.glass);
    }

    public static AdminSavePacket decode(FriendlyByteBuf b) {
        UUID id = b.readUUID();
        String name = b.readUtf(PacketLimits.MAX_NAME);
        String size = b.readUtf(PacketLimits.MAX_SIZE);
        List<Floor> floors = PacketLimits.readFloors(b);
        int color = b.readByte();
        int glass = b.readByte();
        return new AdminSavePacket(id, name, size, floors, color, glass);
    }

    public static void handle(AdminSavePacket p, Supplier<NetworkEvent.Context> c) {
        c.get().enqueueWork(() -> {
            ServerPlayer sender = c.get().getSender();
            if (sender != null) {
                process(sender, p);
            }
        });
        c.get().setPacketHandled(true);
    }

    private static void process(ServerPlayer player, AdminSavePacket p) {
        if (!player.hasPermissions(2)) {
            return;
        }
        ElevatorData data = ElevatorData.get(player.server);
        Optional<StoredElevator> stored = data.byId(p.id());
        if (stored.isEmpty()) {
            return;
        }
        CabinSize size = CabinSize.parse(p.size()).orElse(null);
        Optional<String> error = Elevator.validate(p.name(), size, p.floors());
        if (error.isEmpty()) {
            error = ElevatorStyle.validate(p.color(), p.glass());
        }
        ElevatorStyle shown = ElevatorStyle.sanitize(p.color(), p.glass());
        int doorSide = ModNetwork.doorSideBit(stored.get());
        if (error.isPresent()) {
            ModNetwork.sendAdminPanel(player, p.id(), p.name(), p.size(), p.floors(), error.get(), shown, doorSide);
            return;
        }
        StoredElevator old = stored.get();
        Optional<String> placement = placementError(player, old, size, p.floors());
        if (placement.isPresent()) {
            ModNetwork.sendAdminPanel(player, p.id(), p.name(), p.size(), p.floors(), placement.get(), shown, doorSide);
            return;
        }
        Elevator updated = new Elevator(p.id(), p.name().strip(), size, p.floors());
        StoredElevator saved = new StoredElevator(updated, old.dim(), old.anchor(), old.facing(),
                new ElevatorStyle(p.color(), p.glass()));
        data.put(saved);
        // Contrôleur et cabine suivent immédiatement les nouveaux étages.
        ElevatorService.notifyElevatorUpdated(saved);
        // Portes et boutons suivent les étages par hauteur (et la nouvelle empreinte).
        ElevatorService service = ElevatorService.current();
        if (service != null) {
            service.relink(p.id(), old);
        }
        ModNetwork.sendAdminPanel(player, saved, "");
    }

    /**
     * Contrôles serveur liés au monde : chaque étage (plancher et hauteur intérieure) dans les limites
     * de construction de la dimension, et nouvelle empreinte sans chevauchement d'une autre gaine.
     */
    private static Optional<String> placementError(ServerPlayer player, StoredElevator old, CabinSize size,
                                                   List<Floor> floors) {
        ServerLevel level = player.server.getLevel(old.dim());
        if (level != null) {
            for (int i = 0; i < floors.size(); i++) {
                int y = floors.get(i).y();
                if (y < level.getMinBuildHeight() || y + CabinFootprint.INTERIOR_HEIGHT > level.getMaxBuildHeight()) {
                    return Optional.of("Hauteur hors du monde pour l'étage " + (i + 1) + " ("
                            + level.getMinBuildHeight() + " à " + (level.getMaxBuildHeight() - CabinFootprint.INTERIOR_HEIGHT) + ").");
                }
            }
        }
        Direction facing = old.facing().getAxis().isHorizontal() ? old.facing() : Direction.NORTH;
        CabinFootprint fp = CabinFootprint.of(old.anchor().getX(), old.anchor().getZ(), size,
                facing.getStepX(), facing.getStepZ());
        return ElevatorBlocks.overlapError(player.server, old.dim(), fp, old.elevator().id());
    }
}
