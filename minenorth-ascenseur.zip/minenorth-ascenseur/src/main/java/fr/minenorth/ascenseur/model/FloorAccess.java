package fr.minenorth.ascenseur.model;

/** Règle d'accès d'un étage ; mêmes règles que les portes du mod Portes. */
public sealed interface FloorAccess {

    String PREFIX = "entreprise:";

    static FloorAccess parse(String raw) {
        if (raw == null) return new Unknown("");
        switch (raw) {
            case "PUBLIC": return new Public();
            case "POLICE": return new Police();
            case "POMPIER": return new Pompier();
            case "MAIRIE": return new Mairie();
            default: break;
        }
        if (raw.startsWith(PREFIX)) {
            String[] parts = raw.split(":", -1);
            if (parts.length == 3) {
                try {
                    int id = Integer.parseInt(parts[1].trim());
                    int grade = Integer.parseInt(parts[2].trim());
                    if (id > 0) return new Entreprise(id, Math.max(-1, Math.min(99, grade)));
                } catch (NumberFormatException ignored) {
                    // tombe sur Unknown
                }
            }
        }
        return new Unknown(raw);
    }

    String format();

    boolean canUse(Roles r);

    String label();

    record Public() implements FloorAccess {
        public String format() { return "PUBLIC"; }
        public boolean canUse(Roles r) { return true; }
        public String label() { return "Public"; }
    }

    record Police() implements FloorAccess {
        public String format() { return "POLICE"; }
        public boolean canUse(Roles r) { return r.isOp() || r.hasNode("grade.police") || r.isPolice(); }
        public String label() { return "Police"; }
    }

    record Pompier() implements FloorAccess {
        public String format() { return "POMPIER"; }
        public boolean canUse(Roles r) { return r.isOp() || r.hasNode("grade.pompier") || r.isSecours(); }
        public String label() { return "Pompier/SAMU"; }
    }

    record Mairie() implements FloorAccess {
        public String format() { return "MAIRIE"; }
        public boolean canUse(Roles r) { return r.isOp() || r.hasNode("grade.mairie") || r.isMairie(); }
        public String label() { return "Mairie"; }
    }

    record Entreprise(int id, int minGrade) implements FloorAccess {
        public String format() { return PREFIX + id + ":" + minGrade; }
        public boolean canUse(Roles r) {
            return r.isOp() || (r.entrepriseExists(id) && r.entrepriseCanOpen(id, minGrade));
        }
        public String label() { return "Entreprise"; }
    }

    record Unknown(String raw) implements FloorAccess {
        public String format() { return raw; }
        public boolean canUse(Roles r) { return r.isOp(); }
        public String label() { return "Verrouillé"; }
    }
}
