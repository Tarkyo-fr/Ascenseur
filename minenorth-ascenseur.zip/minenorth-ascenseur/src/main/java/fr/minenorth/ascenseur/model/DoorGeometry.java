package fr.minenorth.ascenseur.model;

/**
 * Géométrie des portes d'étage (Java pur), pour les quatre orientations de cabine.
 *
 * <p>La porte d'étage est dans la rangée de palier {@code cell(a, -1)}. Son panneau est plaqué sur le
 * côté de sa case qui touche la cabine, c'est-à-dire le plan de façade de la cabine : ce côté est
 * l'opposé de l'orientation {@code facing} de la cabine. Le panneau couvre toute la largeur de la case
 * et toute sa hauteur ; seule la case du bas d'une ouverture garde un seuil quand la porte est ouverte.
 */
public final class DoorGeometry {
    /** Épaisseur du panneau et du seuil, en pixels (1/16 de bloc). */
    public static final int PANEL_PX = 2;

    private DoorGeometry() {
    }

    /** Côté (vecteur unitaire dx, dz) de la case de palier où est plaqué le panneau : vers la cabine. */
    public static int[] panelSide(int facingX, int facingZ) {
        return new int[] {-facingX, -facingZ};
    }

    /**
     * Rectangle horizontal du panneau dans sa case, en pixels {x0, z0, x1, z1} (0 à 16), pour un
     * panneau plaqué sur le côté (dx, dz) : pleine largeur le long du côté, {@link #PANEL_PX} d'épaisseur.
     */
    public static int[] panelRectPx(int sideX, int sideZ) {
        if (sideZ < 0) {
            return new int[] {0, 0, 16, PANEL_PX};
        }
        if (sideZ > 0) {
            return new int[] {0, 16 - PANEL_PX, 16, 16};
        }
        if (sideX > 0) {
            return new int[] {16 - PANEL_PX, 0, 16, 16};
        }
        return new int[] {0, 0, PANEL_PX, 16};
    }

    /** Vrai pour la case du bas de l'ouverture (seuil visible porte ouverte). */
    public static boolean isThreshold(int floorY, int y) {
        return y == floorY;
    }

    /**
     * Direction de glissement (dx, dz) du vantail droit de la cabine à l'ouverture : vers la droite
     * de {@code facing} (vue de l'intérieur) ; le vantail gauche glisse à l'opposé.
     */
    public static int[] rightLeafSlide(int facingX, int facingZ) {
        return new int[] {-facingZ, facingX};
    }
}
