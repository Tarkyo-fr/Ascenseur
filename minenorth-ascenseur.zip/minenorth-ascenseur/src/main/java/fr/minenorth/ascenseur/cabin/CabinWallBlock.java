package fr.minenorth.ascenseur.cabin;

import fr.minenorth.ascenseur.model.CabinWalls;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.material.PushReaction;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Paroi invisible de la cabine arrêtée : posée avec le plancher invisible dans les cases de
 * l'empreinte (hauteur intérieure), retirée au départ. Sa collision est une plaque mince sur chaque
 * côté muré de la case ({@link CabinWalls}) et, dans la couche haute, le plafond. Mêmes règles que le
 * plancher : invisible, sans contour (impossible à viser ou à copier), incassable en survie, sans
 * butin ni objet, jamais déplacée par un piston, ne fait jamais suffoquer ; posée seulement dans l'air.
 */
public class CabinWallBlock extends Block {
    public static final BooleanProperty NORTH = BlockStateProperties.NORTH;
    public static final BooleanProperty EAST = BlockStateProperties.EAST;
    public static final BooleanProperty SOUTH = BlockStateProperties.SOUTH;
    public static final BooleanProperty WEST = BlockStateProperties.WEST;
    public static final BooleanProperty UP = BlockStateProperties.UP;

    private static final double T = CabinWalls.THICKNESS * 16.0;
    private static final VoxelShape[] SHAPES = new VoxelShape[32];

    static {
        for (int mask = 0; mask < 32; mask++) {
            VoxelShape s = Shapes.empty();
            if ((mask & CabinWalls.NORTH) != 0) {
                s = Shapes.or(s, Block.box(0, 0, 0, 16, 16, T));
            }
            if ((mask & CabinWalls.EAST) != 0) {
                s = Shapes.or(s, Block.box(16 - T, 0, 0, 16, 16, 16));
            }
            if ((mask & CabinWalls.SOUTH) != 0) {
                s = Shapes.or(s, Block.box(0, 0, 16 - T, 16, 16, 16));
            }
            if ((mask & CabinWalls.WEST) != 0) {
                s = Shapes.or(s, Block.box(0, 0, 0, T, 16, 16));
            }
            if ((mask & 16) != 0) {
                s = Shapes.or(s, Block.box(0, 16 - T, 0, 16, 16, 16));
            }
            SHAPES[mask] = s.optimize();
        }
    }

    public CabinWallBlock() {
        super(Properties.of()
                .strength(-1.0F, 3600000.8F)
                .noLootTable()
                .noOcclusion()
                .forceSolidOn() // jamais remplacée par un liquide
                .pushReaction(PushReaction.BLOCK)
                .isValidSpawn((state, level, pos, type) -> false)
                .isSuffocating((state, level, pos) -> false)
                .isViewBlocking((state, level, pos) -> false));
        registerDefaultState(stateDefinition.any().setValue(NORTH, false).setValue(EAST, false)
                .setValue(SOUTH, false).setValue(WEST, false).setValue(UP, false));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(NORTH, EAST, SOUTH, WEST, UP);
    }

    /** État pour un masque de côtés {@link CabinWalls} et, si {@code ceiling}, le plafond. */
    public BlockState stateFor(int sides, boolean ceiling) {
        return defaultBlockState()
                .setValue(NORTH, (sides & CabinWalls.NORTH) != 0)
                .setValue(EAST, (sides & CabinWalls.EAST) != 0)
                .setValue(SOUTH, (sides & CabinWalls.SOUTH) != 0)
                .setValue(WEST, (sides & CabinWalls.WEST) != 0)
                .setValue(UP, ceiling);
    }

    private static int mask(BlockState state) {
        return (state.getValue(NORTH) ? CabinWalls.NORTH : 0)
                | (state.getValue(EAST) ? CabinWalls.EAST : 0)
                | (state.getValue(SOUTH) ? CabinWalls.SOUTH : 0)
                | (state.getValue(WEST) ? CabinWalls.WEST : 0)
                | (state.getValue(UP) ? 16 : 0);
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.INVISIBLE;
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return Shapes.empty();
    }

    @Override
    public VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return SHAPES[mask(state)];
    }

    @Override
    public boolean propagatesSkylightDown(BlockState state, BlockGetter level, BlockPos pos) {
        return true;
    }

    @Override
    public float getShadeBrightness(BlockState state, BlockGetter level, BlockPos pos) {
        return 1.0F;
    }
}
