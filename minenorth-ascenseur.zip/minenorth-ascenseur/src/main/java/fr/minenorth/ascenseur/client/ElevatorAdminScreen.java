package fr.minenorth.ascenseur.client;

import fr.minenorth.ascenseur.model.CabinSize;
import fr.minenorth.ascenseur.model.CabinWalls;
import fr.minenorth.ascenseur.model.Elevator;
import fr.minenorth.ascenseur.model.ElevatorStyle;
import net.minecraft.world.item.DyeColor;
import fr.minenorth.ascenseur.model.Floor;
import fr.minenorth.ascenseur.model.FloorAccess;
import fr.minenorth.ascenseur.network.AdminPanelPacket;
import fr.minenorth.ascenseur.network.AdminSavePacket;
import fr.minenorth.ascenseur.network.ModNetwork;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** Écran d'administration d'un ascenseur (OP) : nom, taille de cabine et liste des étages. */
public class ElevatorAdminScreen extends Screen {
    private static final int MAX_PANEL_W = 440;
    private static final int MAX_PANEL_H = 330;
    /** Hauteur fixe au-dessus de la liste (titre, nom, en-têtes) et au-dessous (défilement, message, boutons). */
    private static final int LIST_TOP = 110;
    private static final int LIST_BOTTOM_SPACE = 50;
    private static final int ROW_H = 22;
    private static final int MAX_GRADE = 99;
    private static final int MIN_GRADE = -1;

    /** Les types d'accès proposés, dans l'ordre du sélecteur. UNKNOWN : règle non reconnue, conservée telle quelle. */
    private enum Kind {
        PUBLIC("Public"),
        POLICE("Police"),
        POMPIER("Pompier/SAMU"),
        MAIRIE("Mairie"),
        ENTREPRISE("Entreprise"),
        UNKNOWN("Verrouillé");

        final String label;

        Kind(String label) {
            this.label = label;
        }
    }

    /** État modifiable d'un étage pendant l'édition. */
    private static final class Row {
        String name;
        String yText;
        Kind kind;
        int companyId;
        String gradeText;
        String rawAccess;

        static Row from(Floor f) {
            Row r = new Row();
            r.name = f.name();
            r.yText = String.valueOf(f.y());
            r.rawAccess = f.access();
            r.companyId = 0;
            r.gradeText = String.valueOf(MAX_GRADE);
            FloorAccess access = FloorAccess.parse(f.access());
            if (access instanceof FloorAccess.Public) {
                r.kind = Kind.PUBLIC;
            } else if (access instanceof FloorAccess.Police) {
                r.kind = Kind.POLICE;
            } else if (access instanceof FloorAccess.Pompier) {
                r.kind = Kind.POMPIER;
            } else if (access instanceof FloorAccess.Mairie) {
                r.kind = Kind.MAIRIE;
            } else if (access instanceof FloorAccess.Entreprise e) {
                r.kind = Kind.ENTREPRISE;
                r.companyId = e.id();
                r.gradeText = String.valueOf(e.minGrade());
            } else {
                r.kind = Kind.UNKNOWN;
            }
            return r;
        }

        int grade() {
            try {
                return Math.max(MIN_GRADE, Math.min(MAX_GRADE, Integer.parseInt(gradeText.trim())));
            } catch (NumberFormatException e) {
                return MAX_GRADE;
            }
        }

        /** Format exact attendu par le serveur : PUBLIC, POLICE, POMPIER, MAIRIE, entreprise:id:grade. */
        String accessString() {
            return switch (kind) {
                case PUBLIC -> "PUBLIC";
                case POLICE -> "POLICE";
                case POMPIER -> "POMPIER";
                case MAIRIE -> "MAIRIE";
                case ENTREPRISE -> FloorAccess.PREFIX + companyId + ":" + grade();
                case UNKNOWN -> rawAccess;
            };
        }
    }

    private final UUID elevatorId;
    private final List<Row> rows = new ArrayList<>();
    private final List<String> companyIds = new ArrayList<>();
    private final List<String> companyNames = new ArrayList<>();
    private String name;
    private CabinSize size;
    /** Personnalisation : couleur (-1 = d'origine, 0 à 15 = teinte), côtés vitrés et côté porte (non vitrable). */
    private int color = ElevatorStyle.DEFAULT_COLOR;
    private int glass;
    private int doorSide;
    private static final int STYLE_Y = 74;
    private static final int SWATCH = 10;
    private String error;
    private String status = "";
    private int scroll;

    private int left;
    private int top;
    /** Taille du panneau, ajustée à l'écran (échelle d'interface comprise) : Enregistrer reste visible. */
    private int panelW = MAX_PANEL_W;
    private int panelH = MAX_PANEL_H;
    private int visibleRows = 8;

    public ElevatorAdminScreen(AdminPanelPacket p) {
        super(Component.literal("Administration de l'ascenseur"));
        this.elevatorId = p.id();
        load(p);
        this.status = "";
    }

    public UUID elevatorId() {
        return elevatorId;
    }

    private void load(AdminPanelPacket p) {
        name = p.name();
        size = CabinSize.parse(p.size()).orElse(CabinSize.S1X1);
        color = p.color();
        glass = p.glass();
        doorSide = p.doorSide();
        error = p.error() == null ? "" : p.error();
        rows.clear();
        for (Floor f : p.floors()) {
            rows.add(Row.from(f));
        }
        companyIds.clear();
        companyNames.clear();
        for (String entry : p.companies()) {
            int bar = entry.indexOf('|');
            if (bar > 0) {
                companyIds.add(entry.substring(0, bar).trim());
                companyNames.add(entry.substring(bar + 1).trim());
            }
        }
        clampScroll();
    }

    /** Réponse du serveur : erreur affichée, ou confirmation si l'enregistrement a réussi. */
    public void refresh(AdminPanelPacket p) {
        load(p);
        status = error.isEmpty() ? "Enregistré." : "";
        rebuild();
    }

    @Override
    protected void init() {
        rebuild();
    }

    private void clampScroll() {
        scroll = Math.max(0, Math.min(scroll, Math.max(0, rows.size() - visibleRows)));
    }

    private void rebuild() {
        clearWidgets();
        panelW = Math.min(MAX_PANEL_W, this.width - 8);
        panelH = Math.min(MAX_PANEL_H, this.height - 8);
        visibleRows = Math.max(1, (panelH - LIST_TOP - LIST_BOTTOM_SPACE) / ROW_H);
        left = (this.width - panelW) / 2;
        top = (this.height - panelH) / 2;
        int x = left + 10;

        // Nom et taille.
        EditBox nameBox = new EditBox(this.font, x + 36, top + 50, 200, 18, Component.literal("Nom"));
        nameBox.setMaxLength(32);
        nameBox.setValue(name);
        nameBox.setResponder(s -> name = s);
        addRenderableWidget(nameBox);
        addRenderableWidget(new MineNorthButton(x + 300, top + 49, 120, 20,
                Component.literal("Cabine " + size.width() + "x" + size.depth()), MineNorthStyle.DARK, () -> {
            CabinSize[] all = CabinSize.values();
            size = all[(size.ordinal() + 1) % all.length];
            rebuild();
        }));

        // Côtés vitrés (le côté porte ne peut pas l'être).
        int gx = glassX();
        String[] labels = {"N", "E", "S", "O"};
        int[] bits = {CabinWalls.NORTH, CabinWalls.EAST, CabinWalls.SOUTH, CabinWalls.WEST};
        for (int i = 0; i < 4; i++) {
            int bit = bits[i];
            boolean on = (glass & bit) != 0;
            addRenderableWidget(new MineNorthButton(gx + i * 24, top + STYLE_Y - 4, 22, 18,
                    Component.literal(labels[i]), on ? MineNorthStyle.GREEN : MineNorthStyle.DARK, () -> {
                glass ^= bit;
                rebuild();
            }).enabled(bit != doorSide));
        }

        // Lignes d'étages visibles.
        clampScroll();
        int end = Math.min(rows.size(), scroll + visibleRows);
        for (int i = scroll; i < end; i++) {
            addRowWidgets(i, top + LIST_TOP + (i - scroll) * ROW_H);
        }

        // Barre du bas.
        int by = top + panelH - 30;
        addRenderableWidget(new MineNorthButton(x, by, 80, 20, Component.literal("+ Étage"), MineNorthStyle.DARK,
                this::addFloor).enabled(rows.size() < Elevator.MAX_FLOORS));
        addRenderableWidget(new MineNorthButton(left + panelW - 10 - 110, by, 110, 20,
                Component.literal("Enregistrer"), MineNorthStyle.GREEN, this::save));
        addRenderableWidget(new MineNorthButton(left + panelW - 10 - 110 - 6 - 80, by, 80, 20,
                Component.literal("Fermer"), MineNorthStyle.DARK, this::onClose));
    }

    private void addRowWidgets(int index, int y) {
        Row row = rows.get(index);
        int x = left + 10 + 18;

        EditBox nameBox = new EditBox(this.font, x, y, 80, 18, Component.literal("Nom de l'étage"));
        nameBox.setMaxLength(24);
        nameBox.setValue(row.name);
        nameBox.setResponder(s -> row.name = s);
        addRenderableWidget(nameBox);
        x += 84;

        EditBox yBox = new EditBox(this.font, x, y, 36, 18, Component.literal("Hauteur"));
        yBox.setMaxLength(6);
        yBox.setFilter(s -> s.matches("-?\\d{0,5}"));
        yBox.setValue(row.yText);
        yBox.setResponder(s -> row.yText = s);
        addRenderableWidget(yBox);
        x += 40;

        addRenderableWidget(new MineNorthButton(x, y - 1, 62, 20, Component.literal("Ma position"),
                MineNorthStyle.DARK, () -> {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player != null) {
                row.yText = String.valueOf(mc.player.getBlockY());
                rebuild();
            }
        }));
        x += 66;

        addRenderableWidget(new MineNorthButton(x, y - 1, 72, 20, Component.literal(row.kind.label),
                MineNorthStyle.DARK, () -> {
            row.kind = nextKind(row.kind);
            if (row.kind == Kind.ENTREPRISE && !companyIds.isEmpty() && companyIndex(row) < 0) {
                row.companyId = parseId(companyIds.get(0));
            }
            rebuild();
        }));
        x += 76;

        if (row.kind == Kind.ENTREPRISE) {
            int ci = companyIndex(row);
            String label = ci >= 0 ? companyNames.get(ci)
                    : (row.companyId > 0 ? "#" + row.companyId : "(aucune)");
            label = this.font.plainSubstrByWidth(label, 52);
            addRenderableWidget(new MineNorthButton(x, y - 1, 58, 20, Component.literal(label),
                    MineNorthStyle.PINK, () -> {
                if (!companyIds.isEmpty()) {
                    int next = (companyIndex(row) + 1) % companyIds.size();
                    row.companyId = parseId(companyIds.get(next));
                    rebuild();
                }
            }).enabled(!companyIds.isEmpty()));
            x += 62;

            EditBox gradeBox = new EditBox(this.font, x, y, 28, 18, Component.literal("Grade minimum"));
            gradeBox.setMaxLength(3);
            gradeBox.setFilter(s -> s.matches("-?\\d{0,2}"));
            gradeBox.setValue(row.gradeText);
            gradeBox.setResponder(s -> row.gradeText = s);
            addRenderableWidget(gradeBox);
        }

        addRenderableWidget(new MineNorthButton(left + panelW - 10 - 52, y - 1, 52, 20,
                Component.literal("Supprimer"), MineNorthStyle.ALERT, () -> {
            rows.remove(index);
            rebuild();
        }).enabled(rows.size() > Elevator.MIN_FLOORS));
    }

    private static Kind nextKind(Kind current) {
        return switch (current) {
            case PUBLIC -> Kind.POLICE;
            case POLICE -> Kind.POMPIER;
            case POMPIER -> Kind.MAIRIE;
            case MAIRIE -> Kind.ENTREPRISE;
            case ENTREPRISE, UNKNOWN -> Kind.PUBLIC;
        };
    }

    private int companyIndex(Row row) {
        for (int i = 0; i < companyIds.size(); i++) {
            if (parseId(companyIds.get(i)) == row.companyId) {
                return i;
            }
        }
        return -1;
    }

    private static int parseId(String text) {
        try {
            return Integer.parseInt(text.trim());
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    private void addFloor() {
        if (rows.size() >= Elevator.MAX_FLOORS) {
            return;
        }
        int lastY = 0;
        if (!rows.isEmpty()) {
            try {
                lastY = Integer.parseInt(rows.get(rows.size() - 1).yText.trim());
            } catch (NumberFormatException ignored) {
                // garde 0
            }
        }
        Row r = Row.from(new Floor("Étage " + rows.size(), lastY + 4, "PUBLIC"));
        rows.add(r);
        scroll = Math.max(0, rows.size() - visibleRows);
        rebuild();
    }

    private void save() {
        List<Floor> floors = new ArrayList<>();
        for (int i = 0; i < rows.size(); i++) {
            Row r = rows.get(i);
            int y;
            try {
                y = Integer.parseInt(r.yText.trim());
            } catch (NumberFormatException e) {
                error = "Hauteur invalide pour l'étage " + (i + 1) + ".";
                status = "";
                return;
            }
            Minecraft mc = Minecraft.getInstance();
            if (mc.level != null && (y < mc.level.getMinBuildHeight()
                    || y + fr.minenorth.ascenseur.model.CabinFootprint.INTERIOR_HEIGHT > mc.level.getMaxBuildHeight())) {
                error = "Hauteur hors du monde pour l'étage " + (i + 1) + ".";
                status = "";
                return;
            }
            floors.add(new Floor(r.name == null ? "" : r.name.trim(), y, r.accessString()));
        }
        String sizeText = size.width() + "x" + size.depth();
        // Contrôle rapide côté client ; le serveur reste l'autorité.
        var problem = Elevator.validate(name, size, floors);
        if (problem.isPresent()) {
            error = problem.get();
            status = "";
            return;
        }
        error = "";
        status = "Envoi...";
        ModNetwork.CHANNEL.sendToServer(new AdminSavePacket(elevatorId, name.trim(), sizeText, floors, color, glass & ~doorSide));
    }


    private int swatchX() {
        return left + 10 + 44;
    }

    private int glassX() {
        return swatchX() + 17 * (SWATCH + 1) + 40;
    }

    /** Couleur d'aperçu d'une pastille (-1 : aspect d'origine, clair). */
    private static int swatchColor(int index) {
        return index < 0 ? 0xFFE6E6E6 : 0xFF000000 | DyeColor.byId(index).getTextColor();
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        int y = top + STYLE_Y - 3;
        if (mouseY >= y && mouseY < y + SWATCH) {
            for (int i = -1; i <= ElevatorStyle.MAX_COLOR; i++) {
                int x = swatchX() + (i + 1) * (SWATCH + 1);
                if (mouseX >= x && mouseX < x + SWATCH) {
                    color = i;
                    return true;
                }
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    private void renderStyleRow(GuiGraphics g) {
        g.drawString(this.font, "Couleur", left + 10, top + STYLE_Y - 2, MineNorthStyle.BLUE, false);
        int y = top + STYLE_Y - 3;
        for (int i = -1; i <= ElevatorStyle.MAX_COLOR; i++) {
            int x = swatchX() + (i + 1) * (SWATCH + 1);
            if (i == color) {
                g.fill(x - 1, y - 1, x + SWATCH + 1, y + SWATCH + 1, 0xFFFFFFFF);
            }
            g.fill(x, y, x + SWATCH, y + SWATCH, swatchColor(i));
        }
        g.drawString(this.font, "Vitres", glassX() - 34, top + STYLE_Y - 2, MineNorthStyle.BLUE, false);
    }
    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double delta) {
        if (rows.size() > visibleRows) {
            int before = scroll;
            scroll += delta < 0 ? 1 : -1;
            clampScroll();
            if (scroll != before) {
                rebuild();
            }
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, delta);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderBackground(g);
        MineNorthStyle.panel(g, left, top, panelW, panelH, "Ascenseur", "Configuration des étages");
        g.drawString(this.font, "Nom", left + 10, top + 55, MineNorthStyle.BLUE, false);

        // En-têtes de colonnes et numéros d'étage.
        int headerY = top + 96;
        int x = left + 10 + 18;
        g.drawString(this.font, "Étage", x, headerY, MineNorthStyle.MUTED, false);
        g.drawString(this.font, "Y", x + 84, headerY, MineNorthStyle.MUTED, false);
        g.drawString(this.font, "Accès", x + 84 + 40 + 66, headerY, MineNorthStyle.MUTED, false);
        int end = Math.min(rows.size(), scroll + visibleRows);
        for (int i = scroll; i < end; i++) {
            int y = top + LIST_TOP + (i - scroll) * ROW_H;
            g.drawString(this.font, String.valueOf(i), left + 10, y + 5, MineNorthStyle.CYAN, false);
        }
        String range = rows.isEmpty() ? "" : "Étages " + (scroll) + " à " + (end - 1) + " sur " + rows.size()
                + " (molette pour défiler)";
        g.drawString(this.font, range, left + 10, top + LIST_TOP + visibleRows * ROW_H + 2, MineNorthStyle.MUTED, false);

        if (!error.isEmpty()) {
            g.drawString(this.font, this.font.plainSubstrByWidth(error, panelW - 20), left + 10,
                    top + panelH - 46, MineNorthStyle.ALERT, false);
        } else if (!status.isEmpty()) {
            g.drawString(this.font, status, left + 10, top + panelH - 46, MineNorthStyle.OK, false);
        }
        renderStyleRow(g);
        super.render(g, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
