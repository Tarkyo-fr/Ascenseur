package fr.minenorth.ascenseur.cabin;

import fr.minenorth.ascenseur.model.CabinFootprint;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.game.ClientboundAddEntityPacket;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Cabine mobile : rendu de la cabine et véhicule des joueurs pendant un trajet.
 *
 * <p>La position est imposée par {@link ElevatorService} (pas de physique). Position de l'entité :
 * centre de l'empreinte en X/Z, plancher en Y. Pendant un trajet, les joueurs présents sont
 * passagers : chacun garde sa position X/Z (ramenée dans l'empreinte) et ses pieds sont posés sur
 * le plancher. Un passager n'est jamais compté comme « en vol » par le serveur et ne cumule pas de
 * distance de chute.
 *
 * <p>Côté client, le mouvement est prédit à partir de la cible et de la vitesse synchronisées
 * (même calcul que le serveur), et recalé sur la position serveur en cas de dérive : le trajet
 * est fluide même si les paquets de position arrivent irrégulièrement.
 */
public class CabinEntity extends Entity {
    private static final EntityDataAccessor<Integer> SPAN_X =
            SynchedEntityData.defineId(CabinEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> SPAN_Z =
            SynchedEntityData.defineId(CabinEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DOOR_SIDE =
            SynchedEntityData.defineId(CabinEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> MOVING =
            SynchedEntityData.defineId(CabinEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Integer> TARGET_Y =
            SynchedEntityData.defineId(CabinEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Float> SPEED =
            SynchedEntityData.defineId(CabinEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Boolean> DOORS_OPEN =
            SynchedEntityData.defineId(CabinEntity.class, EntityDataSerializers.BOOLEAN);
    /** Couleur (-1 d'origine, 0 à 15), côtés vitrés (bits CabinWalls, côté porte exclu), affichage d'étage compact. */
    private static final EntityDataAccessor<Integer> COLOR =
            SynchedEntityData.defineId(CabinEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> GLASS =
            SynchedEntityData.defineId(CabinEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> INDICATOR =
            SynchedEntityData.defineId(CabinEntity.class, EntityDataSerializers.INT);

    /** Distance minimale entre un passager et la paroi (demi-largeur d'un joueur + marge). */
    private static final double RIDER_MARGIN = CabinFootprint.RIDER_MARGIN;
    /** Écart client/serveur au-delà duquel la prédiction client est abandonnée au profit du serveur. */
    private static final double RESYNC_DISTANCE = 1.0;

    /** Ascenseur propriétaire (serveur uniquement). */
    @Nullable
    private UUID elevatorId;

    // Interpolation client vers la dernière position reçue du serveur.
    private double serverX;
    private double serverY;
    private double serverZ;
    private int lerpSteps;
    // Animation client des portes de la cabine (0 fermées, 1 ouvertes).
    private float doorOpen = 1.0F;
    private float doorOpenO = 1.0F;
    /** Avancée de l'animation des portes par tick (environ 1 s). */
    private static final float DOOR_STEP = 0.05F;

    public CabinEntity(EntityType<? extends CabinEntity> type, Level level) {
        super(type, level);
        this.noPhysics = true;
        this.blocksBuilding = true;
        this.setNoGravity(true);
    }

    @Override
    protected void defineSynchedData() {
        entityData.define(SPAN_X, 1);
        entityData.define(SPAN_Z, 1);
        entityData.define(DOOR_SIDE, Direction.NORTH.get2DDataValue());
        entityData.define(MOVING, false);
        entityData.define(TARGET_Y, 0);
        entityData.define(SPEED, 0.0F);
        entityData.define(DOORS_OPEN, true);
        entityData.define(COLOR, -1);
        entityData.define(GLASS, 0);
        entityData.define(INDICATOR, -1);
    }

    /** Lie la cabine à son ascenseur et à son empreinte (serveur, avant l'ajout au monde). */
    void configure(UUID elevatorId, CabinFootprint footprint, Direction doorSide) {
        this.elevatorId = elevatorId;
        entityData.set(SPAN_X, footprint.spanX());
        entityData.set(SPAN_Z, footprint.spanZ());
        entityData.set(DOOR_SIDE, doorSide.get2DDataValue());
    }

    /** Met à jour l'état synchronisé ; les valeurs inchangées ne sont pas renvoyées aux clients. */
    /** Personnalisation et affichage d'étage ; envoyés aux clients seulement s'ils changent. */
    void syncLook(int color, int glass, int indicator) {
        if (entityData.get(COLOR) != color) {
            entityData.set(COLOR, color);
        }
        if (entityData.get(GLASS) != glass) {
            entityData.set(GLASS, glass);
        }
        if (entityData.get(INDICATOR) != indicator) {
            entityData.set(INDICATOR, indicator);
        }
    }

    public int color() {
        return entityData.get(COLOR);
    }

    public int glass() {
        return entityData.get(GLASS);
    }

    /** Affichage d'étage compact ({@code FloorIndicator.pack}). */
    public int indicator() {
        return entityData.get(INDICATOR);
    }

    void syncState(boolean moving, int targetY, float speed, boolean doorsOpen) {
        if (entityData.get(MOVING) != moving) {
            entityData.set(MOVING, moving);
        }
        if (entityData.get(TARGET_Y) != targetY) {
            entityData.set(TARGET_Y, targetY);
        }
        if (entityData.get(SPEED) != speed) {
            entityData.set(SPEED, speed);
        }
        if (entityData.get(DOORS_OPEN) != doorsOpen) {
            entityData.set(DOORS_OPEN, doorsOpen);
        }
    }

    @Nullable
    public UUID elevatorId() {
        return elevatorId;
    }

    public int spanX() {
        return entityData.get(SPAN_X);
    }

    public int spanZ() {
        return entityData.get(SPAN_Z);
    }

    /** Côté de la porte de la cabine. */
    public Direction doorSide() {
        return Direction.from2DDataValue(entityData.get(DOOR_SIDE));
    }

    public boolean doorsOpen() {
        return entityData.get(DOORS_OPEN);
    }

    /** Ouverture animée des portes (client), entre 0 (fermées) et 1 (ouvertes). */
    public float doorOpenness(float partialTick) {
        return doorOpenO + (doorOpen - doorOpenO) * partialTick;
    }

    public boolean isMoving() {
        return entityData.get(MOVING);
    }

    // --- Mouvement -------------------------------------------------------------------------------

    @Override
    public void tick() {
        if (level().isClientSide) {
            clientTick();
        } else if (!ElevatorService.isLiveCabin(this)) {
            // Cabine orpheline (ascenseur supprimé, service arrêté) : le service en recrée une au besoin.
            discard();
        }
    }

    private void clientTick() {
        doorOpenO = doorOpen;
        float doorTarget = doorsOpen() ? 1.0F : 0.0F;
        doorOpen += Math.max(-DOOR_STEP, Math.min(DOOR_STEP, doorTarget - doorOpen));
        double x = getX();
        double y = getY();
        double z = getZ();
        if (lerpSteps > 0) {
            x += (serverX - x) / lerpSteps;
            z += (serverZ - z) / lerpSteps;
        }
        if (isMoving()) {
            double speed = entityData.get(SPEED);
            double delta = entityData.get(TARGET_Y) - y;
            y = Math.abs(delta) <= speed ? y + delta : y + Math.copySign(speed, delta);
            if (Math.abs(serverY - y) > Math.max(RESYNC_DISTANCE, 3 * speed)) {
                y = serverY;
            }
        } else if (lerpSteps > 0) {
            y += (serverY - y) / lerpSteps;
        }
        if (lerpSteps > 0) {
            lerpSteps--;
        }
        setPos(x, y, z);
    }

    @Override
    public void lerpTo(double x, double y, double z, float yRot, float xRot, int steps, boolean teleport) {
        serverX = x;
        serverY = y;
        serverZ = z;
        lerpSteps = Math.max(1, steps);
    }

    @Override
    public void recreateFromPacket(ClientboundAddEntityPacket packet) {
        super.recreateFromPacket(packet);
        serverX = getX();
        serverY = getY();
        serverZ = getZ();
        lerpSteps = 0;
    }

    /** Aucune physique : seule la position imposée par le service compte. */
    @Override
    public void move(MoverType type, Vec3 movement) {
    }

    @Override
    public void push(double x, double y, double z) {
    }

    @Override
    public void push(Entity entity) {
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public boolean isPushedByFluid() {
        return false;
    }

    @Override
    public boolean canChangeDimensions() {
        return false;
    }

    // --- Boîte englobante ------------------------------------------------------------------------

    /** Boîte = empreinte exacte, du plancher au plafond. */
    @Override
    protected AABB makeBoundingBox() {
        double hx = entityData.get(SPAN_X) / 2.0;
        double hz = entityData.get(SPAN_Z) / 2.0;
        Vec3 p = position();
        return new AABB(p.x - hx, p.y, p.z - hz, p.x + hx, p.y + CabinFootprint.INTERIOR_HEIGHT, p.z + hz);
    }

    @Override
    public AABB getBoundingBoxForCulling() {
        return getBoundingBox().inflate(0.25);
    }

    @Override
    public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
        super.onSyncedDataUpdated(key);
        if (SPAN_X.equals(key) || SPAN_Z.equals(key)) {
            setBoundingBox(makeBoundingBox());
        }
    }

    // --- Passagers -------------------------------------------------------------------------------

    @Override
    protected boolean canAddPassenger(Entity passenger) {
        return true;
    }

    /** Les passagers restent debout. */
    @Override
    public boolean shouldRiderSit() {
        return false;
    }

    /** Chaque passager garde sa place (ramenée dans l'empreinte), pieds sur le plancher. */
    @Override
    protected void positionRider(Entity passenger, Entity.MoveFunction move) {
        if (!hasPassenger(passenger)) {
            return;
        }
        move.accept(passenger, clampX(passenger.getX()), getY(), clampZ(passenger.getZ()));
    }

    /** Descente sur place, sur le plancher, jamais dans une paroi. */
    @Override
    public Vec3 getDismountLocationForPassenger(LivingEntity passenger) {
        return new Vec3(clampX(passenger.getX()), getY(), clampZ(passenger.getZ()));
    }

    double clampX(double x) {
        return CabinFootprint.clampInside(x, getX(), spanX() / 2.0, RIDER_MARGIN);
    }

    double clampZ(double z) {
        return CabinFootprint.clampInside(z, getZ(), spanZ() / 2.0, RIDER_MARGIN);
    }

    // --- Interaction -----------------------------------------------------------------------------

    @Override
    public boolean isPickable() {
        return !isRemoved();
    }

    /**
     * Clic droit : panneau d'étages pour un joueur dans la cabine, panneau d'administration pour un
     * OP accroupi. Le serveur revalide tout dans {@link ElevatorService#onCabinUse}.
     */
    @Override
    public InteractionResult interact(Player player, InteractionHand hand) {
        if (hand != InteractionHand.MAIN_HAND) {
            return InteractionResult.PASS;
        }
        if (level().isClientSide) {
            return InteractionResult.SUCCESS;
        }
        if (player instanceof ServerPlayer sp && elevatorId != null) {
            ElevatorService service = ElevatorService.current();
            if (service != null) {
                service.onCabinUse(sp, elevatorId);
            }
        }
        return InteractionResult.CONSUME;
    }

    private boolean feetInside(Player player) {
        return Math.abs(player.getX() - getX()) <= spanX() / 2.0
                && Math.abs(player.getZ() - getZ()) <= spanZ() / 2.0
                && player.getY() >= getY() - CabinFootprint.FEET_BELOW
                && player.getY() <= getY() + CabinFootprint.FEET_ABOVE;
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        return false;
    }

    /** Attaquable seulement pour recevoir le clic gauche (suppression par un OP) ; jamais de dégâts. */
    @Override
    public boolean isAttackable() {
        return true;
    }

    /**
     * Clic gauche : un OP en créatif et accroupi supprime l'ascenseur (données d'abord, puis le monde) ;
     * un non-OP accroupi est prévenu que l'ascenseur est protégé. Un clic sans être accroupi (passagers
     * qui tapent dans la cabine) ne fait rien. Toujours « ignoré » pour le combat : aucun dégât.
     */
    @Override
    public boolean skipAttackInteraction(Entity attacker) {
        if (!level().isClientSide && attacker instanceof ServerPlayer player && player.isShiftKeyDown()
                && elevatorId != null && level() instanceof net.minecraft.server.level.ServerLevel server) {
            if (player.hasPermissions(2) && player.isCreative()) {
                ElevatorBlocks.deleteElevator(server, elevatorId, player);
            } else if (!player.hasPermissions(2)) {
                player.displayClientMessage(net.minecraft.network.chat.Component.literal("§cCet ascenseur est protégé."), true);
            }
        }
        return true;
    }

    /**
     * En mouvement, la cabine est solide pour les entités qui ne la montent pas (comme un bateau) :
     * on ne la traverse pas depuis la gaine. Les passagers ne la heurtent pas (même véhicule). À
     * l'arrêt, ce sont les parois invisibles ({@link CabinWallBlock}) qui font obstacle, et le joueur
     * peut entrer par la porte.
     */
    @Override
    public boolean canBeCollidedWith() {
        return isMoving() && !isRemoved();
    }

    @Override
    public boolean ignoreExplosion() {
        return true;
    }

    @Override
    public boolean displayFireAnimation() {
        return false;
    }

    // --- Sauvegarde : jamais (type « noSave ») -------------------------------------------------------

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
    }
}
