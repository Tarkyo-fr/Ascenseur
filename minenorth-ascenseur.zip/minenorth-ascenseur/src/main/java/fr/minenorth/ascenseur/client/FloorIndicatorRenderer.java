package fr.minenorth.ascenseur.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import fr.minenorth.ascenseur.MineNorthAscenseur;
import fr.minenorth.ascenseur.block.FloorIndicatorBlock;
import fr.minenorth.ascenseur.block.FloorIndicatorBlockEntity;
import fr.minenorth.ascenseur.block.ModBlocks;
import fr.minenorth.ascenseur.model.DoorGeometry;
import fr.minenorth.ascenseur.model.FloorIndicator;
import net.minecraft.client.gui.Font;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.core.Direction;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Texte de l'afficheur d'étage (étage actuel et flèche, ou tiret), dessiné sur la face de l'écran qui
 * regarde le palier, en pleine luminosité.
 */
public class FloorIndicatorRenderer implements BlockEntityRenderer<FloorIndicatorBlockEntity> {
    private static final float TEXT_HEIGHT = 0.4F;
    private static final int COLOR = 0xFFFF9A2E;
    private final Font font;

    public FloorIndicatorRenderer(BlockEntityRendererProvider.Context context) {
        this.font = context.getFont();
    }

    @Override
    public void render(FloorIndicatorBlockEntity be, float partialTick, PoseStack pose, MultiBufferSource buffers,
                       int light, int overlay) {
        Direction panelSide = be.getBlockState().getValue(FloorIndicatorBlock.FACING);
        Direction front = panelSide.getOpposite();
        boolean linked = be.getElevatorId() != null;
        // Non relié : petit texte explicite (un OP le relie accroupi, main vide, clic droit).
        String text = linked ? FloorIndicator.text(be.getShown()) : "non lié";
        float scale = (linked ? TEXT_HEIGHT : 0.16F) / 9.0F;
        pose.pushPose();
        pose.translate(0.5F, 0.5F, 0.5F);
        // Le +Z local est tourné vers le palier (face lisible du texte).
        pose.mulPose(Axis.YP.rotationDegrees(front.toYRot() == 0 ? 0 : 360.0F - front.toYRot()));
        // Face avant du panneau : à PANEL_PX du bord côté cabine (z = -0.5 en local).
        pose.translate(0.0F, 0.0F, -0.5F + DoorGeometry.PANEL_PX / 16.0F + 0.002F);
        pose.scale(scale, -scale, scale);
        font.drawInBatch(text, -font.width(text) / 2.0F, -4.0F, COLOR, false, pose.last().pose(), buffers,
                Font.DisplayMode.POLYGON_OFFSET, 0, LightTexture.FULL_BRIGHT);
        pose.popPose();
    }

    /** Enregistrement (client uniquement). */
    @Mod.EventBusSubscriber(modid = MineNorthAscenseur.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static final class Registration {
        private Registration() {
        }

        @SubscribeEvent
        public static void register(EntityRenderersEvent.RegisterRenderers event) {
            event.registerBlockEntityRenderer(ModBlocks.FLOOR_INDICATOR_BE.get(), FloorIndicatorRenderer::new);
        }
    }
}
