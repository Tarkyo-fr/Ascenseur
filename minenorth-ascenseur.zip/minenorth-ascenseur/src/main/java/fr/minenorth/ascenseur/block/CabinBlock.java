package fr.minenorth.ascenseur.block;

import fr.minenorth.ascenseur.cabin.ElevatorBlocks;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Bloc cabine : l'ancre de l'ascenseur (case avant gauche de la cabine, au sol de l'étage de départ),
 * rendu comme une plaque de sol discrète (repère de configuration) ; la console de la cabine est
 * dessinée par le rendu de la cabine et suit la cabine.
 *
 * <p>Il n'a aucune collision (les passagers ne doivent jamais buter dessus) mais reste visable et
 * cliquable. {@code FACING} est l'orientation de l'ascenseur (direction de la porte de la cabine) :
 * l'opposé de la direction du joueur qui le pose. Seul un OP peut le poser ; la pose crée
 * l'ascenseur, le retrait du bloc le supprime.
 */
public class CabinBlock extends BaseEntityBlock {
    public static final DirectionProperty FACING = HorizontalDirectionalBlock.FACING;

    /** Plaque de sol discrète (repère d'ancre), 1 px de haut, au centre de la case. */
    private static final VoxelShape PLATE = Block.box(3, 0, 3, 13, 1, 13);

    public CabinBlock() {
        super(Properties.of().mapColor(MapColor.METAL).strength(3.0f).noCollission().noOcclusion()
                .forceSolidOn() // jamais remplacé par un liquide (sinon l'ancre disparaîtrait)
                .pushReaction(PushReaction.BLOCK));
        registerDefaultState(stateDefinition.any().setValue(FACING, Direction.NORTH));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING);
    }

    /** Refus (rien n'est posé) pour un non-OP, une ancre déjà prise ou une hauteur hors limites. */
    @Override
    @Nullable
    public BlockState getStateForPlacement(BlockPlaceContext ctx) {
        Player player = ctx.getPlayer();
        if (player == null || !player.hasPermissions(2)) {
            if (player instanceof ServerPlayer sp) {
                ElevatorBlocks.refuseCabinPlacement(sp);
            }
            return null;
        }
        Direction facing = ctx.getHorizontalDirection().getOpposite();
        if (ctx.getLevel() instanceof ServerLevel server && player instanceof ServerPlayer sp
                && !ElevatorBlocks.canCreateAt(server, ctx.getClickedPos(), sp)) {
            return null;
        }
        return defaultBlockState().setValue(FACING, facing);
    }

    /** Crée l'ascenseur par défaut et écrit son identifiant dans l'entité de bloc. */
    @Override
    public void setPlacedBy(Level level, BlockPos pos, BlockState state, @Nullable LivingEntity placer, ItemStack stack) {
        super.setPlacedBy(level, pos, state, placer, stack);
        if (level instanceof ServerLevel server && placer instanceof ServerPlayer player && player.hasPermissions(2)) {
            ElevatorBlocks.createElevator(server, pos, state.getValue(FACING), player);
        }
    }

    // Pas de suppression dans onRemove : seule une casse par un OP (ElevatorProtection) ou la
    // commande /ascenseur remove suppriment un ascenseur ; tout autre retrait (liquide, /setblock,
    // mod tiers) laisse l'ascenseur intact, et reposer le repère au même endroit le reprend.

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return PLATE;
    }

    @Override
    public VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return Shapes.empty();
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new CabinBlockEntity(pos, state);
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    /** Clic droit : panneau d'étages ; OP accroupi : panneau d'administration. */
    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        if (hand != InteractionHand.MAIN_HAND) {
            return InteractionResult.PASS;
        }
        if (level.isClientSide) {
            return InteractionResult.SUCCESS;
        }
        if (player instanceof ServerPlayer sp && level instanceof ServerLevel server) {
            ElevatorBlocks.useCabinBlock(server, pos, sp);
        }
        return InteractionResult.CONSUME;
    }
}
