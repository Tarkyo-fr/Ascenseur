package fr.minenorth.ascenseur.compat;

import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.server.permission.PermissionAPI;
import net.minecraftforge.server.permission.events.PermissionGatherEvent;
import net.minecraftforge.server.permission.nodes.PermissionNode;
import net.minecraftforge.server.permission.nodes.PermissionTypes;

import java.util.HashMap;
import java.util.Map;

/** Nœuds de permission Forge des grades, enregistrés sous l'espace de noms minenorthascenseur. */
@Mod.EventBusSubscriber
public final class Permissions {
    private Permissions() {}

    private static final String[] NODES = {"grade.police", "grade.pompier", "grade.medical", "grade.mairie"};
    private static final Map<String, PermissionNode<Boolean>> PERMISSION_NODES = new HashMap<>();

    @SubscribeEvent
    public static void gatherPermissions(PermissionGatherEvent.Nodes event) {
        for (String permission : NODES) {
            if (PERMISSION_NODES.containsKey(permission)) continue;
            PermissionNode<Boolean> node = new PermissionNode<>("minenorthascenseur", permission, PermissionTypes.BOOLEAN,
                    (player, uuid, context) -> player != null && player.hasPermissions(2));
            PERMISSION_NODES.put(permission, node);
            event.addNodes(node);
        }
    }

    /** Vrai pour les OP, sinon la valeur du nœud ; faux si le nœud est inconnu ou si l'API de permissions échoue. */
    public static boolean hasNode(ServerPlayer p, String node) {
        if (p == null) return false;
        if (p.hasPermissions(2)) return true;
        PermissionNode<Boolean> n = PERMISSION_NODES.get(node);
        if (n == null) return false;
        try {
            return Boolean.TRUE.equals(PermissionAPI.getPermission(p, n));
        } catch (Throwable t) {
            return false;
        }
    }
}
