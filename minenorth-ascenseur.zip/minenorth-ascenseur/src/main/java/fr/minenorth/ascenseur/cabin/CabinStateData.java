package fr.minenorth.ascenseur.cabin;

import fr.minenorth.ascenseur.data.ElevatorNbt;
import fr.minenorth.ascenseur.data.StoredElevator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.OptionalInt;
import java.util.UUID;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

/**
 * Hauteur d'arrêt de chaque cabine, sauvegardée avec le monde : au redémarrage, la cabine reprend
 * à cet étage ({@code TripController.reset}). Pendant un trajet, c'est l'étage de destination
 * (les passagers déconnectés y sont déposés), sinon l'étage où la cabine est arrêtée.
 * Jamais une hauteur entre deux étages.
 */
public final class CabinStateData extends SavedData {
    private static final String DATA_NAME = "minenorthascenseur_cabins";

    private final Map<UUID, Integer> restY = new HashMap<>();
    /**
     * Gaines à nettoyer quand leurs chunks seront chargés (ascenseur supprimé ou empreinte changée
     * alors que la gaine n'était pas chargée) : planchers invisibles et portes d'étage restés en place.
     */
    private final List<StoredElevator> pendingCleanups = new ArrayList<>();

    public static CabinStateData get(MinecraftServer server) {
        return server.overworld().getDataStorage()
                .computeIfAbsent(CabinStateData::load, CabinStateData::new, DATA_NAME);
    }

    private static CabinStateData load(CompoundTag tag) {
        CabinStateData d = new CabinStateData();
        ListTag list = tag.getList("Cabins", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag entry = list.getCompound(i);
            if (entry.hasUUID("Id")) {
                d.restY.put(entry.getUUID("Id"), entry.getInt("RestY"));
            } else {
                com.mojang.logging.LogUtils.getLogger().warn("[Ascenseur] Hauteur d'arrêt sans identifiant ignorée au chargement.");
            }
        }
        ListTag pending = tag.getList("PendingCleanups", Tag.TAG_COMPOUND);
        for (int i = 0; i < pending.size(); i++) {
            try {
                d.pendingCleanups.add(ElevatorNbt.fromTag(pending.getCompound(i)));
            } catch (RuntimeException e) {
                com.mojang.logging.LogUtils.getLogger().warn("[Ascenseur] Nettoyage en attente illisible ignoré : {}", e.toString());
            }
        }
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag list = new ListTag();
        for (Map.Entry<UUID, Integer> e : restY.entrySet()) {
            CompoundTag entry = new CompoundTag();
            entry.putUUID("Id", e.getKey());
            entry.putInt("RestY", e.getValue());
            list.add(entry);
        }
        tag.put("Cabins", list);
        ListTag pending = new ListTag();
        for (StoredElevator s : pendingCleanups) {
            pending.add(ElevatorNbt.toTag(s));
        }
        tag.put("PendingCleanups", pending);
        return tag;
    }

    public OptionalInt restY(UUID id) {
        Integer y = restY.get(id);
        return y == null ? OptionalInt.empty() : OptionalInt.of(y);
    }

    public void setRestY(UUID id, int y) {
        Integer old = restY.put(id, y);
        if (old == null || old != y) {
            setDirty();
        }
    }

    public List<StoredElevator> pendingCleanups() {
        return Collections.unmodifiableList(pendingCleanups);
    }

    public void addPendingCleanup(StoredElevator stored) {
        pendingCleanups.add(stored);
        setDirty();
    }

    public void removePendingCleanup(StoredElevator stored) {
        if (pendingCleanups.remove(stored)) {
            setDirty();
        }
    }

    public void remove(UUID id) {
        if (restY.remove(id) != null) {
            setDirty();
        }
    }
}
