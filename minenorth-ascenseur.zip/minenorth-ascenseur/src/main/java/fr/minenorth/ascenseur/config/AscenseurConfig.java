package fr.minenorth.ascenseur.config;

import fr.minenorth.ascenseur.cabin.CabinTuning;
import net.minecraftforge.fml.loading.FMLPaths;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

/** Fichier {@code config/Minenorth-ascenseur/ascenseur.toml} (créé avec les valeurs par défaut). */
public final class AscenseurConfig {
    private AscenseurConfig() {
    }

    private static final String DEFAULT_FILE = """
            # Ascenseurs MineNorth
            # Modifier puis taper /ascenseur reload (niveau 2). Les nouvelles valeurs s'appliquent aux
            # ascenseurs activés ensuite (redémarrage du serveur ou modification de l'ascenseur) ;
            # un ascenseur déjà actif garde ses valeurs jusque-là.

            # Vitesse de la cabine, en blocs par seconde (0.5 à 12.0).
            vitesse_blocs_par_seconde = 4.0

            # Durée d'ouverture ou de fermeture des portes, en secondes (0.5 à 10.0).
            duree_portes_secondes = 2.0
            """;

    private static Path file() {
        return FMLPaths.CONFIGDIR.get().resolve("Minenorth-ascenseur").resolve("ascenseur.toml");
    }

    /** Lit le fichier (le crée au besoin) et applique les valeurs ; ne lève jamais d'exception. */
    public static AscenseurSettings load() {
        AscenseurSettings result = AscenseurSettings.DEFAULTS;
        try {
            Path f = file();
            Files.createDirectories(f.getParent());
            if (!Files.exists(f)) {
                Files.writeString(f, DEFAULT_FILE, StandardCharsets.UTF_8);
            }
            List<String> lines = Files.readAllLines(f, StandardCharsets.UTF_8);
            result = AscenseurSettings.parse(lines);
        } catch (IOException | RuntimeException ignored) {
            // valeurs par défaut
        }
        CabinTuning.apply(result);
        return result;
    }
}
