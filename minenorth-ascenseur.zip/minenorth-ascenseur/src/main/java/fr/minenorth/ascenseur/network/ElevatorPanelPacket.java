package fr.minenorth.ascenseur.network;

import fr.minenorth.ascenseur.client.ClientNetworkHandler;
import fr.minenorth.ascenseur.model.FloorView;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.List;
import java.util.UUID;
import java.util.function.Supplier;

/** Serveur vers client : ouvre le panneau d'étages de la cabine. */
public record ElevatorPanelPacket(UUID elevatorId, String elevatorName, List<FloorView> floors) {

    public static void encode(ElevatorPanelPacket p, FriendlyByteBuf b) {
        b.writeUUID(p.elevatorId);
        b.writeUtf(p.elevatorName, PacketLimits.MAX_NAME);
        b.writeCollection(p.floors, (buf, v) -> {
            buf.writeVarInt(v.index());
            buf.writeUtf(v.name(), PacketLimits.MAX_NAME);
            buf.writeInt(v.y());
            buf.writeUtf(v.roleLabel() == null ? "" : v.roleLabel(), PacketLimits.MAX_NAME);
            buf.writeBoolean(v.allowed());
            buf.writeBoolean(v.current());
        });
    }

    public static ElevatorPanelPacket decode(FriendlyByteBuf b) {
        UUID id = b.readUUID();
        String name = b.readUtf(PacketLimits.MAX_NAME);
        List<FloorView> floors = PacketLimits.readList(b, PacketLimits.MAX_FLOORS, buf -> new FloorView(
                buf.readVarInt(),
                buf.readUtf(PacketLimits.MAX_NAME),
                buf.readInt(),
                buf.readUtf(PacketLimits.MAX_NAME),
                buf.readBoolean(),
                buf.readBoolean()));
        return new ElevatorPanelPacket(id, name, floors);
    }

    public static void handle(ElevatorPanelPacket p, Supplier<NetworkEvent.Context> c) {
        c.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> ClientNetworkHandler.openElevatorPanel(p)));
        c.get().setPacketHandled(true);
    }
}
