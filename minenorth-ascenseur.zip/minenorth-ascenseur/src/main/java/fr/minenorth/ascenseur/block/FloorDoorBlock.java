package fr.minenorth.ascenseur.block;

import fr.minenorth.ascenseur.cabin.ElevatorBlocks;
import fr.minenorth.ascenseur.model.DoorGeometry;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Porte d'étage : panneau mince de la largeur d'une case, plaqué sur le côté {@code FACING} de sa
 * case. Posée par un OP devant la cabine, elle est tournée vers la cabine (plan de façade de la
 * cabine) et remplit toute l'ouverture (largeur de cabine × hauteur intérieure) ; casser une porte
 * retire toute l'ouverture.
 *
 * <p>Fermée (OPEN = false), elle est un obstacle. Elle n'est ouverte que lorsque la cabine de son
 * ascenseur est arrêtée à son étage, portes ouvertes ; c'est {@code ElevatorService} qui pose cet
 * état (arrivée, départ, activation, retrait). Elle ne fait jamais suffoquer.
 */
public class FloorDoorBlock extends BaseEntityBlock {
    public static final DirectionProperty FACING = HorizontalDirectionalBlock.FACING;
    public static final BooleanProperty OPEN = BlockStateProperties.OPEN;

    /** Case du bas de l'ouverture : seule à garder un seuil visible (et visable) porte ouverte. */
    public static final BooleanProperty THRESHOLD = BooleanProperty.create("seuil");
    /** Teinte des panneaux (0 à 15, couleurs de colorant) ou {@link #DEFAULT_COLOR} : aspect d'origine. */
    public static final int DEFAULT_COLOR = 16;
    public static final IntegerProperty COLOR = IntegerProperty.create("couleur", 0, DEFAULT_COLOR);

    /** Panneau fermé et seuil ouvert, par index 2D du côté (sud 0, ouest 1, nord 2, est 3), via {@link DoorGeometry}. */
    private static final VoxelShape[] CLOSED = new VoxelShape[4];
    private static final VoxelShape[] OPEN_SILL = new VoxelShape[4];

    static {
        for (Direction d : Direction.Plane.HORIZONTAL) {
            int[] r = DoorGeometry.panelRectPx(d.getStepX(), d.getStepZ());
            CLOSED[d.get2DDataValue()] = Block.box(r[0], 0, r[1], r[2], 16, r[3]);
            OPEN_SILL[d.get2DDataValue()] = Block.box(r[0], 0, r[1], r[2], 1, r[3]);
        }
    }

    public FloorDoorBlock() {
        super(Properties.of().mapColor(MapColor.METAL).strength(3.0f).noOcclusion()
                .forceSolidOn() // jamais remplacée par un liquide
                .pushReaction(PushReaction.BLOCK)
                .isSuffocating((state, level, pos) -> false)
                .isViewBlocking((state, level, pos) -> false));
        registerDefaultState(stateDefinition.any().setValue(FACING, Direction.NORTH).setValue(OPEN, false)
                .setValue(THRESHOLD, true).setValue(COLOR, DEFAULT_COLOR));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING, OPEN, THRESHOLD, COLOR);
    }

    @Override
    @Nullable
    public BlockState getStateForPlacement(BlockPlaceContext ctx) {
        if (!ElevatorBlocks.mayPlace(ctx.getPlayer())) {
            return null; // OP uniquement
        }
        return defaultBlockState().setValue(FACING, ctx.getHorizontalDirection()).setValue(OPEN, false);
    }

    /** Index 2D (sud 0, ouest 1, nord 2, est 3) du côté de la case où se trouve le panneau. */
    private static int side(BlockState state) {
        return state.getValue(FACING).get2DDataValue();
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        if (state.getValue(OPEN)) {
            return state.getValue(THRESHOLD) ? OPEN_SILL[side(state)] : Shapes.empty();
        }
        return CLOSED[side(state)];
    }

    @Override
    public VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        if (state.getValue(OPEN)) {
            return Shapes.empty();
        }
        return CLOSED[side(state)];
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new FloorDoorBlockEntity(pos, state);
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    /** Pose par un OP : liaison à l'ascenseur dont la rangée de palier contient la porte. */
    @Override
    public void setPlacedBy(Level level, BlockPos pos, BlockState state, @Nullable LivingEntity placer, ItemStack stack) {
        super.setPlacedBy(level, pos, state, placer, stack);
        if (level instanceof ServerLevel server && placer instanceof ServerPlayer player && player.hasPermissions(2)) {
            ElevatorBlocks.linkPlacedDoor(server, pos, player);
        }
    }

    /** Porte retirée (casse par un OP) : le reste de son ouverture est retiré aussi. */
    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean moved) {
        if (!state.is(newState.getBlock()) && level instanceof ServerLevel server
                && level.getBlockEntity(pos) instanceof FloorDoorBlockEntity be) {
            ElevatorBlocks.removeOpening(server, pos, be.getElevatorId(), be.getFloorIndex());
        }
        super.onRemove(state, level, pos, newState, moved);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        if (hand != InteractionHand.MAIN_HAND) {
            return InteractionResult.PASS;
        }
        if (level.isClientSide) {
            return InteractionResult.SUCCESS;
        }
        if (ElevatorBlocks.isManualLinkGesture(player) && level instanceof ServerLevel s && player instanceof ServerPlayer op) {
            ElevatorBlocks.manualLink(s, pos, op); // OP accroupi, main vide : liaison manuelle
            return InteractionResult.CONSUME;
        }
        if (player instanceof ServerPlayer sp && level instanceof ServerLevel server) {
            if (ElevatorBlocks.doorLink(server, pos).isEmpty()) {
                sp.displayClientMessage(Component.literal("Cette porte n'est reliée à aucun ascenseur."), true);
            } else if (!state.getValue(OPEN)) {
                sp.displayClientMessage(Component.literal("Appelez l'ascenseur avec le bouton d'appel."), true);
            }
        }
        return InteractionResult.CONSUME;
    }
}
