package fr.minenorth.ascenseur.data;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

/** Registre persistant des ascenseurs, stocké dans l'overworld. */
public class ElevatorData extends SavedData {
    private static final String DATA_NAME = "minenorthascenseur_elevators";

    private final Map<UUID, StoredElevator> elevators = new LinkedHashMap<>();

    public static ElevatorData get(MinecraftServer server) {
        ServerLevel overworld = server.overworld();
        return overworld.getDataStorage().computeIfAbsent(ElevatorData::load, ElevatorData::new, DATA_NAME);
    }

    private static ElevatorData load(CompoundTag tag) {
        ElevatorData d = new ElevatorData();
        ListTag list = tag.getList("Elevators", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            try {
                StoredElevator s = ElevatorNbt.fromTag(list.getCompound(i));
                d.elevators.put(s.elevator().id(), s);
            } catch (RuntimeException e) {
                // entrée corrompue ou invalide : ignorée plutôt que de bloquer le chargement du monde
                com.mojang.logging.LogUtils.getLogger().warn("[Ascenseur] Ascenseur illisible ignoré au chargement : {}", e.toString());
            }
        }
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag list = new ListTag();
        for (StoredElevator s : elevators.values()) {
            list.add(ElevatorNbt.toTag(s));
        }
        tag.put("Elevators", list);
        return tag;
    }

    public Optional<StoredElevator> byId(UUID id) {
        return Optional.ofNullable(elevators.get(id));
    }

    public Optional<StoredElevator> atAnchor(ResourceKey<Level> dim, BlockPos anchor) {
        for (StoredElevator s : elevators.values()) {
            if (s.dim().equals(dim) && s.anchor().equals(anchor)) {
                return Optional.of(s);
            }
        }
        return Optional.empty();
    }

    public void put(StoredElevator stored) {
        elevators.put(stored.elevator().id(), stored);
        setDirty();
    }

    public void remove(UUID id) {
        if (elevators.remove(id) != null) {
            setDirty();
        }
    }

    public Collection<StoredElevator> all() {
        return Collections.unmodifiableCollection(elevators.values());
    }
}
