package fr.minenorth.ascenseur.block;

import fr.minenorth.ascenseur.cabin.ElevatorBlocks;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/** Bouton d'appel : petit bloc plaqué contre le mur, orienté vers le joueur à la pose. */
public class CallButtonBlock extends BaseEntityBlock {
    public static final DirectionProperty FACING = HorizontalDirectionalBlock.FACING;

    // Boîtier (plaque à collerette) plaqué contre le mur ; le voyant est au centre.
    private static final VoxelShape NORTH = Block.box(4, 3, 14, 12, 13, 16);
    private static final VoxelShape SOUTH = Block.box(4, 3, 0, 12, 13, 2);
    private static final VoxelShape WEST = Block.box(14, 3, 4, 16, 13, 12);
    private static final VoxelShape EAST = Block.box(0, 3, 4, 2, 13, 12);
    /** Voyant allumé : un appel pour cet étage est en attente ou la cabine y arrive. */
    public static final BooleanProperty LIT = BlockStateProperties.LIT;

    public CallButtonBlock() {
        super(Properties.of().mapColor(MapColor.METAL).strength(3.0f).noOcclusion()
                .forceSolidOn() // jamais remplacé par un liquide
                .lightLevel(s -> s.getValue(BlockStateProperties.LIT) ? 7 : 0)
                .pushReaction(net.minecraft.world.level.material.PushReaction.BLOCK));
        registerDefaultState(stateDefinition.any().setValue(FACING, Direction.NORTH).setValue(LIT, false));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING, LIT);
    }

    @Override
    @Nullable
    public BlockState getStateForPlacement(BlockPlaceContext ctx) {
        if (!ElevatorBlocks.mayPlace(ctx.getPlayer())) {
            return null; // OP uniquement
        }
        return defaultBlockState().setValue(FACING, ctx.getHorizontalDirection().getOpposite());
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return switch (state.getValue(FACING)) {
            case SOUTH -> SOUTH;
            case WEST -> WEST;
            case EAST -> EAST;
            default -> NORTH;
        };
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new CallButtonBlockEntity(pos, state);
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    /** Pose par un OP : liaison de la porte d'étage liée la plus proche (sinon règle des portes). */
    @Override
    public void setPlacedBy(Level level, BlockPos pos, BlockState state, @Nullable LivingEntity placer, ItemStack stack) {
        super.setPlacedBy(level, pos, state, placer, stack);
        if (level instanceof ServerLevel server && placer instanceof ServerPlayer player && player.hasPermissions(2)) {
            ElevatorBlocks.linkPlacedButton(server, pos, player);
        }
    }

    /** Appel de la cabine ; inerte (message discret) sans le rôle de l'étage. */
    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        if (hand != InteractionHand.MAIN_HAND) {
            return InteractionResult.PASS;
        }
        if (level.isClientSide) {
            return InteractionResult.SUCCESS;
        }
        if (ElevatorBlocks.isManualLinkGesture(player) && level instanceof ServerLevel s && player instanceof ServerPlayer op) {
            ElevatorBlocks.manualLink(s, pos, op); // OP accroupi, main vide : liaison manuelle
            return InteractionResult.CONSUME;
        }
        if (player instanceof ServerPlayer sp && level instanceof ServerLevel server) {
            ElevatorBlocks.pressButton(server, pos, sp);
        }
        return InteractionResult.CONSUME;
    }
}
