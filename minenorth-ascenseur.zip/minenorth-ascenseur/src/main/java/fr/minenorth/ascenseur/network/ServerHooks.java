package fr.minenorth.ascenseur.network;

import fr.minenorth.ascenseur.data.StoredElevator;
import fr.minenorth.ascenseur.model.TripController;
import net.minecraft.server.level.ServerPlayer;

import java.util.Optional;
import java.util.UUID;

/**
 * Points d'accroche serveur pour le choix d'un étage. Task 10 installe sa propre implémentation
 * avec {@link #setSelectionService(SelectionService)} ; tant que rien n'est installé, tout est refusé.
 */
public final class ServerHooks {
    private ServerHooks() {
    }

    /** À implémenter par Task 10 (cabines en service, voyages en cours). */
    public interface SelectionService {
        /** Contrôleur de trajet de cet ascenseur, vide si la cabine n'est pas active. */
        Optional<TripController> tripFor(UUID elevatorId);

        /** Vrai si le joueur se trouve réellement dans la cabine de cet ascenseur. */
        boolean isInsideCabin(ServerPlayer player, StoredElevator elevator);

        /** Appelé uniquement après revalidation complète : démarre le voyage vers cet étage. */
        void onFloorSelected(ServerPlayer player, StoredElevator elevator, int floorIndex);
    }

    /** Implémentation par défaut : rien n'est sélectionnable tant que Task 10 n'est pas branchée. */
    private static final SelectionService DENY_ALL = new SelectionService() {
        @Override
        public Optional<TripController> tripFor(UUID elevatorId) {
            return Optional.empty();
        }

        @Override
        public boolean isInsideCabin(ServerPlayer player, StoredElevator elevator) {
            return false;
        }

        @Override
        public void onFloorSelected(ServerPlayer player, StoredElevator elevator, int floorIndex) {
            // TODO(Task 10) : jamais appelé avec l'implémentation par défaut.
        }
    };

    private static volatile SelectionService selectionService = DENY_ALL;

    public static SelectionService selectionService() {
        return selectionService;
    }

    public static void setSelectionService(SelectionService service) {
        selectionService = service == null ? DENY_ALL : service;
    }
}
