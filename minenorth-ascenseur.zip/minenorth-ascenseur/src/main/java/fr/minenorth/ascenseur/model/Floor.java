package fr.minenorth.ascenseur.model;

/** Un étage : nom affiché, hauteur Y du sol de la cabine et règle d'accès (texte brut). */
public record Floor(String name, int y, String access) {
}
