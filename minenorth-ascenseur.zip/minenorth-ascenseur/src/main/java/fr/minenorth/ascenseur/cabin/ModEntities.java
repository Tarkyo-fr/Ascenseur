package fr.minenorth.ascenseur.cabin;

import fr.minenorth.ascenseur.MineNorthAscenseur;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** Enregistrement des entités de l'ascenseur. */
public final class ModEntities {
    private ModEntities() {
    }

    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, MineNorthAscenseur.MOD_ID);

    /**
     * Cabine mobile. Jamais sauvegardée ni invocable : {@link ElevatorService} la recrée à partir
     * des données des ascenseurs, ce qui évite les doublons après un redémarrage. Position envoyée
     * à chaque tick ({@code updateInterval(1)}) pour un mouvement fluide.
     */
    public static final RegistryObject<EntityType<CabinEntity>> CABIN = ENTITIES.register("cabine",
            () -> EntityType.Builder.<CabinEntity>of(CabinEntity::new, MobCategory.MISC)
                    .sized(1.0F, 3.0F)
                    .noSave()
                    .noSummon()
                    .fireImmune()
                    .clientTrackingRange(10)
                    .updateInterval(1)
                    .setShouldReceiveVelocityUpdates(false)
                    .build("cabine"));

    public static void register(IEventBus bus) {
        ENTITIES.register(bus);
    }
}
