package fr.minenorth.ascenseur.model;

import java.util.List;

/**
 * Liaison manuelle (OP accroupi, main vide, clic droit) d'un afficheur, d'un bouton ou d'une porte
 * d'étage : choix de l'ascenseur et de l'étage (Java pur).
 *
 * <p>L'ascenseur est le plus proche dans la même dimension, à au plus {@link #MAX_DISTANCE} blocs
 * horizontalement de sa gaine (distance du bloc au rectangle de l'empreinte) ; l'étage est celui dont la
 * hauteur est la plus proche de celle du bloc (égalité : le plus bas), à au plus
 * {@link #MAX_VERTICAL} blocs.
 */
public final class ManualLinking {
    public static final double MAX_DISTANCE = 24.0;
    public static final int MAX_VERTICAL = 6;

    private ManualLinking() {
    }

    /** Un ascenseur candidat. */
    public record Candidate(String dimension, CabinFootprint footprint, int[] floorYs) {
    }

    public enum Failure { NO_ELEVATOR, NO_FLOOR }

    /** Résultat : index du candidat et de l'étage, ou la raison de l'échec ({@code failure} non nul). */
    public record Pick(int elevator, int floor, Failure failure) {
        public boolean ok() {
            return failure == null;
        }
    }

    /** Distance horizontale du centre de la case (x, z) au rectangle de l'empreinte (0 dedans). */
    public static double distance(CabinFootprint fp, int x, int z) {
        double cx = x + 0.5;
        double cz = z + 0.5;
        double dx = Math.max(Math.max(fp.minX() - cx, 0), cx - fp.maxX());
        double dz = Math.max(Math.max(fp.minZ() - cz, 0), cz - fp.maxZ());
        return Math.sqrt(dx * dx + dz * dz);
    }

    public static Pick pick(List<Candidate> candidates, String dimension, int x, int y, int z) {
        int best = -1;
        double bestDist = Double.MAX_VALUE;
        for (int i = 0; i < candidates.size(); i++) {
            Candidate c = candidates.get(i);
            if (!c.dimension().equals(dimension)) {
                continue;
            }
            double d = distance(c.footprint(), x, z);
            if (d <= MAX_DISTANCE && d < bestDist) {
                bestDist = d;
                best = i;
            }
        }
        if (best < 0) {
            return new Pick(-1, -1, Failure.NO_ELEVATOR);
        }
        int[] ys = candidates.get(best).floorYs();
        if (ys.length == 0) {
            return new Pick(best, -1, Failure.NO_FLOOR);
        }
        int floor = FloorRemap.nearest(ys, y);
        if (Math.abs(ys[floor] - y) > MAX_VERTICAL) {
            return new Pick(best, -1, Failure.NO_FLOOR);
        }
        return new Pick(best, floor, null);
    }
}
