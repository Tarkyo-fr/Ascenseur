package fr.minenorth.ascenseur.model;

/** Affichage d'étage (Java pur) : étage actuel de la cabine et sens de marche. */
public final class FloorIndicator {
    public static final int UP = 1;
    public static final int NONE = 0;
    public static final int DOWN = -1;

    private FloorIndicator() {
    }

    /** Sens de marche : vers la cible en mouvement, aucun à l'arrêt. */
    public static int direction(TripController.Phase phase, double y, double targetY) {
        if (phase != TripController.Phase.MOVING || targetY == y) {
            return NONE;
        }
        return targetY > y ? UP : DOWN;
    }

    /** Texte affiché : « — » si l'ascenseur est indisponible, sinon l'étage (0 en bas) et la flèche. */
    public static String text(boolean active, int floorIndex, int direction) {
        if (!active || floorIndex < 0) {
            return "—";
        }
        String arrow = direction == UP ? " ↑" : direction == DOWN ? " ↓" : "";
        return floorIndex + arrow;
    }

    /** Valeur compacte (une seule donnée synchronisée) : étage, sens et disponibilité. */
    public static int pack(boolean active, int floorIndex, int direction) {
        if (!active || floorIndex < 0) {
            return -1;
        }
        return floorIndex * 4 + (direction + 1);
    }

    public static boolean packedActive(int packed) {
        return packed >= 0;
    }

    public static int packedFloor(int packed) {
        return packed < 0 ? -1 : packed / 4;
    }

    public static int packedDirection(int packed) {
        return packed < 0 ? NONE : packed % 4 - 1;
    }

    /** Texte d'une valeur compacte. */
    public static String text(int packed) {
        return text(packedActive(packed), packedFloor(packed), packedDirection(packed));
    }
}
