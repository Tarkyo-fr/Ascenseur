package fr.minenorth.ascenseur.cabin;

import fr.minenorth.ascenseur.config.AscenseurSettings;

/**
 * Réglages de mouvement de la cabine, lus depuis {@code config/Minenorth-ascenseur/ascenseur.toml}
 * (voir {@link fr.minenorth.ascenseur.config.AscenseurConfig}). Les valeurs sont prises à l'activation
 * d'un ascenseur : un {@code /ascenseur reload} s'applique aux ascenseurs activés ensuite.
 */
public final class CabinTuning {
    private CabinTuning() {
    }

    private static volatile AscenseurSettings settings = AscenseurSettings.DEFAULTS;

    public static void apply(AscenseurSettings s) {
        settings = s;
    }

    /** Vitesse de la cabine, en blocs par tick serveur (20 ticks par seconde). */
    public static double blocksPerTick() {
        return settings.blocksPerTick();
    }

    /** Durée d'ouverture ou de fermeture des portes, en ticks. */
    public static int doorTicks() {
        return settings.doorTicks();
    }
}
