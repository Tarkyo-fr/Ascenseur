package fr.minenorth.ascenseur.network;

import fr.minenorth.ascenseur.compat.ServerRoles;
import fr.minenorth.ascenseur.data.ElevatorData;
import fr.minenorth.ascenseur.data.StoredElevator;
import fr.minenorth.ascenseur.model.ElevatorRules;
import fr.minenorth.ascenseur.model.TripController;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.Optional;
import java.util.UUID;
import java.util.function.Supplier;

/** Client vers serveur : le joueur choisit un étage. Le serveur revalide tout. */
public record SelectFloorPacket(UUID elevatorId, int floorIndex) {

    public static void encode(SelectFloorPacket p, FriendlyByteBuf b) {
        b.writeUUID(p.elevatorId);
        b.writeVarInt(p.floorIndex);
    }

    public static SelectFloorPacket decode(FriendlyByteBuf b) {
        return new SelectFloorPacket(b.readUUID(), b.readVarInt());
    }

    public static void handle(SelectFloorPacket p, Supplier<NetworkEvent.Context> c) {
        c.get().enqueueWork(() -> {
            ServerPlayer sender = c.get().getSender();
            if (sender != null) {
                process(sender, p);
            }
        });
        c.get().setPacketHandled(true);
    }

    private static void process(ServerPlayer player, SelectFloorPacket p) {
        Optional<StoredElevator> stored = ElevatorData.get(player.server).byId(p.elevatorId());
        if (stored.isEmpty()) {
            return;
        }
        // Hooks fournis par Task 10 : par défaut, cabine inconnue donc tout est refusé.
        ServerHooks.SelectionService service = ServerHooks.selectionService();
        Optional<TripController> trip = service.tripFor(p.elevatorId());
        if (trip.isEmpty()) {
            return;
        }
        boolean inside = service.isInsideCabin(player, stored.get());
        boolean allowed = ElevatorRules.canSelect(
                stored.get().elevator(), p.floorIndex(), ServerRoles.of(player), inside, trip.get());
        if (allowed) {
            service.onFloorSelected(player, stored.get(), p.floorIndex());
        } else {
            boolean roleOk = ElevatorRules.canCall(stored.get().elevator(), p.floorIndex(), ServerRoles.of(player));
            fr.minenorth.ascenseur.cabin.ElevatorService.explainRefusedSelection(player, inside, trip.get(), roleOk);
        }
    }
}
