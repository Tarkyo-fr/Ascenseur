package fr.minenorth.ascenseur.data;

import fr.minenorth.ascenseur.model.CabinSize;
import fr.minenorth.ascenseur.model.Elevator;
import fr.minenorth.ascenseur.model.ElevatorStyle;
import fr.minenorth.ascenseur.model.Floor;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;

import java.util.ArrayList;
import java.util.List;

/**
 * Conversion d'un ascenseur vers et depuis NBT.
 *
 * <p>Le coeur ({@link #write} / {@link #read}) n'utilise pas {@link ResourceKey} : cette classe exige le
 * bootstrap des registres Forge, absent de la JVM des tests JUnit. Il reste ainsi testable.
 */
public final class ElevatorNbt {
    private ElevatorNbt() {
    }

    /** Contenu lu depuis un tag, avant conversion de la dimension en {@link ResourceKey}. */
    record Parts(Elevator elevator, ResourceLocation dim, BlockPos anchor, Direction facing, ElevatorStyle style) {
    }

    public static CompoundTag toTag(StoredElevator s) {
        CompoundTag tag = write(s.elevator(), s.dim().location(), s.anchor(), s.facing());
        writeStyle(tag, s.style());
        return tag;
    }

    public static CompoundTag toTag(Elevator e, ResourceKey<Level> dim, BlockPos anchor, Direction facing) {
        return write(e, dim.location(), anchor, facing);
    }

    /** Personnalisation ; absente des anciennes sauvegardes (lue alors comme le style par défaut). */
    static void writeStyle(CompoundTag tag, ElevatorStyle style) {
        tag.putInt("Color", style.colorIndex());
        tag.putInt("Glass", style.glassMask());
    }

    static ElevatorStyle readStyle(CompoundTag tag) {
        if (!tag.contains("Color")) {
            return ElevatorStyle.DEFAULT;
        }
        return ElevatorStyle.sanitize(tag.getInt("Color"), tag.getInt("Glass"));
    }

    /** @throws IllegalArgumentException si l'entrée est invalide (dimension, taille ou ascenseur). */
    public static StoredElevator fromTag(CompoundTag tag) {
        Parts p = read(tag);
        return new StoredElevator(p.elevator(), ResourceKey.create(Registries.DIMENSION, p.dim()), p.anchor(), p.facing(), p.style());
    }

    static CompoundTag write(Elevator e, ResourceLocation dim, BlockPos anchor, Direction facing) {
        CompoundTag tag = new CompoundTag();
        tag.putUUID("Id", e.id());
        tag.putString("Name", e.name());
        tag.putString("Size", e.size().width() + "x" + e.size().depth());
        ListTag floors = new ListTag();
        for (Floor f : e.floors()) {
            CompoundTag ft = new CompoundTag();
            ft.putString("Name", f.name());
            ft.putInt("Y", f.y());
            ft.putString("Access", f.access() == null ? "" : f.access());
            floors.add(ft);
        }
        tag.put("Floors", floors);
        tag.putString("Dim", dim.toString());
        tag.put("Anchor", NbtUtils.writeBlockPos(anchor));
        tag.putString("Facing", horizontal(facing).getName());
        return tag;
    }

    static Parts read(CompoundTag tag) {
        if (!tag.hasUUID("Id")) {
            throw new IllegalArgumentException("Identifiant manquant.");
        }
        ResourceLocation dim = ResourceLocation.tryParse(tag.getString("Dim"));
        if (dim == null) {
            throw new IllegalArgumentException("Dimension invalide.");
        }
        CabinSize size = CabinSize.parse(tag.getString("Size")).orElse(null);
        List<Floor> floors = new ArrayList<>();
        ListTag list = tag.getList("Floors", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag ft = list.getCompound(i);
            floors.add(new Floor(ft.getString("Name"), ft.getInt("Y"), ft.getString("Access")));
        }
        Elevator elevator = new Elevator(tag.getUUID("Id"), tag.getString("Name"), size, floors);
        BlockPos anchor = NbtUtils.readBlockPos(tag.getCompound("Anchor"));
        Direction facing = horizontal(Direction.byName(tag.getString("Facing")));
        return new Parts(elevator, dim, anchor, facing, readStyle(tag));
    }

    private static Direction horizontal(Direction d) {
        return d != null && d.getAxis().isHorizontal() ? d : Direction.NORTH;
    }
}
