package fr.minenorth.ascenseur.cabin;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.PushReaction;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Plancher invisible posé sous la cabine quand elle est arrêtée à un étage (une case sous chaque
 * case de l'empreinte, sommet au niveau de l'étage) et retiré au départ.
 *
 * <p>Il sert de vrai sol : le serveur ne compte que les blocs (pas les entités) pour décider si un
 * joueur « flotte » (expulsion anti-fly après 80 ticks), et un sol en bloc évite toute saccade de
 * collision entre client et serveur. Invisible, sans contour (impossible à viser, donc à casser ou
 * à utiliser comme support de pose), incassable en survie, ne fait jamais suffoquer, sans butin
 * et sans objet.
 */
public class CabinFloorBlock extends Block {
    public CabinFloorBlock() {
        super(Properties.of()
                .strength(-1.0F, 3600000.8F)
                .noLootTable()
                .noOcclusion()
                .pushReaction(PushReaction.BLOCK)
                .isValidSpawn((state, level, pos, type) -> false)
                .isSuffocating((state, level, pos) -> false)
                .isViewBlocking((state, level, pos) -> false));
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.INVISIBLE;
    }

    /** Pas de contour : le bloc ne peut pas être visé. */
    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return Shapes.empty();
    }

    /** Collision pleine : c'est le sol de la cabine. */
    @Override
    public VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return Shapes.block();
    }

    @Override
    public boolean propagatesSkylightDown(BlockState state, BlockGetter level, BlockPos pos) {
        return true;
    }

    @Override
    public float getShadeBrightness(BlockState state, BlockGetter level, BlockPos pos) {
        return 1.0F;
    }
}
