package fr.minenorth.ascenseur.model;

/**
 * Parois de la cabine arrêtée, case par case (Java pur). Chaque case de l'empreinte reçoit une paroi
 * sur chacun de ses côtés qui est un bord de l'empreinte, sauf le côté de la porte (ouvert : la porte
 * d'étage ferme le palier). Les côtés sont codés en masque de bits.
 */
public final class CabinWalls {
    public static final int NORTH = 1;
    public static final int EAST = 2;
    public static final int SOUTH = 4;
    public static final int WEST = 8;
    /** Épaisseur d'une paroi (en blocs), identique au rendu. */
    public static final double THICKNESS = 1.0 / 16.0;

    private CabinWalls() {
    }

    /** Bit du côté de la porte de la cabine (direction {@code facing}). */
    public static int doorSide(CabinFootprint fp) {
        return sideOf(fp.facingX(), fp.facingZ());
    }

    /** Bit du côté désigné par le vecteur horizontal unitaire (dx, dz). */
    public static int sideOf(int dx, int dz) {
        if (dz < 0) {
            return NORTH;
        }
        if (dx > 0) {
            return EAST;
        }
        if (dz > 0) {
            return SOUTH;
        }
        return WEST;
    }

    /** Côtés à murer pour la case (x, z) ; 0 hors de l'empreinte ou pour une case intérieure. */
    public static int sides(CabinFootprint fp, int x, int z) {
        if (x < fp.minX() || x >= fp.maxX() || z < fp.minZ() || z >= fp.maxZ()) {
            return 0;
        }
        int mask = 0;
        if (z == fp.minZ()) {
            mask |= NORTH;
        }
        if (x == fp.maxX() - 1) {
            mask |= EAST;
        }
        if (z == fp.maxZ() - 1) {
            mask |= SOUTH;
        }
        if (x == fp.minX()) {
            mask |= WEST;
        }
        return mask & ~doorSide(fp);
    }
}
