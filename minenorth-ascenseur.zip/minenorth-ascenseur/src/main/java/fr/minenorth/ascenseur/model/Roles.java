package fr.minenorth.ascenseur.model;

/** Vue des rôles d'un joueur, sans dépendance à Minecraft (adaptée côté serveur). */
public interface Roles {
    boolean isOp();

    boolean isPolice();

    boolean isSecours();

    boolean isMairie();

    boolean hasNode(String node);

    boolean entrepriseExists(int id);

    boolean entrepriseCanOpen(int id, int minGrade);
}
