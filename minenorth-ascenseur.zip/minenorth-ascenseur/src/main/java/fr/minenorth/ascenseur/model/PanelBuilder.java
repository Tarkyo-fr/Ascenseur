package fr.minenorth.ascenseur.model;

import java.util.ArrayList;
import java.util.List;

/** Construit le panneau d'étages vu par un joueur (index 0 = étage le plus bas). */
public final class PanelBuilder {
    private PanelBuilder() {
    }

    public static List<FloorView> forPlayer(Elevator e, Roles r, int currentFloor) {
        List<Floor> floors = e.floors();
        List<FloorView> views = new ArrayList<>(floors.size());
        for (int i = 0; i < floors.size(); i++) {
            Floor f = floors.get(i);
            FloorAccess access = FloorAccess.parse(f.access());
            views.add(new FloorView(i, f.name(), f.y(), access.label(), access.canUse(r), i == currentFloor));
        }
        return views;
    }
}
