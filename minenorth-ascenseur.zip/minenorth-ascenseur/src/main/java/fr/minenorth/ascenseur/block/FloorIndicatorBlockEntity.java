package fr.minenorth.ascenseur.block;

import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Afficheur d'étage : ascenseur lié et valeur affichée ({@code FloorIndicator.pack}, -1 pour le tiret).
 * La valeur n'est envoyée aux clients proches que lorsqu'elle change.
 */
public class FloorIndicatorBlockEntity extends BlockEntity {
    private static final String TAG_ELEVATOR = "ElevatorId";
    private static final String TAG_VALUE = "Shown";

    @Nullable private UUID elevatorId;
    private int shown = -1;

    public FloorIndicatorBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlocks.FLOOR_INDICATOR_BE.get(), pos, state);
    }

    @Nullable public UUID getElevatorId() { return elevatorId; }

    public int getShown() { return shown; }

    public void setElevatorId(@Nullable UUID id) {
        this.elevatorId = id;
        sync();
    }

    /** Nouvelle valeur affichée ; rien n'est envoyé si elle ne change pas. */
    public void setShown(int value) {
        if (value != shown) {
            shown = value;
            sync();
        }
    }

    private void sync() {
        setChanged();
        if (level != null) level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        if (elevatorId != null) tag.putUUID(TAG_ELEVATOR, elevatorId);
        tag.putInt(TAG_VALUE, shown);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        elevatorId = tag.hasUUID(TAG_ELEVATOR) ? tag.getUUID(TAG_ELEVATOR) : null;
        shown = tag.contains(TAG_VALUE) ? tag.getInt(TAG_VALUE) : -1;
    }

    @Override
    public CompoundTag getUpdateTag() {
        CompoundTag tag = super.getUpdateTag();
        saveAdditional(tag);
        return tag;
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }
}
