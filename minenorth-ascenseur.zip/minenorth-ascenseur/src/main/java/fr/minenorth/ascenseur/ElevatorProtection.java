package fr.minenorth.ascenseur;

import fr.minenorth.ascenseur.block.ModBlocks;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.event.level.ExplosionEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Protection des blocs du mod : un non-OP ne casse ni la cabine, ni un bouton, ni une porte d'étage,
 * et les explosions les épargnent (ainsi que le plancher invisible). Les pistons ne les déplacent pas :
 * les quatre blocs ont {@code PushReaction.BLOCK}. Un OP casse normalement ; la cabine cassée passe
 * par {@code CabinBlock.onRemove}, qui retire l'ascenseur des données puis libère le service.
 */
@Mod.EventBusSubscriber(modid = MineNorthAscenseur.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class ElevatorProtection {
    private ElevatorProtection() {
    }

    private static boolean isModBlock(BlockState state) {
        Block b = state.getBlock();
        return b == ModBlocks.CABIN.get() || b == ModBlocks.CALL_BUTTON.get() || b == ModBlocks.FLOOR_DOOR.get()
                || b == ModBlocks.FLOOR_INDICATOR.get();
    }

    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onBreak(BlockEvent.BreakEvent event) {
        if (!(event.getPlayer() instanceof ServerPlayer player) || player.hasPermissions(2)) {
            return;
        }
        if (isModBlock(event.getState())) {
            event.setCanceled(true);
            player.displayClientMessage(Component.literal("§cCet ascenseur est protégé."), true);
        }
    }


    /**
     * Casse du repère d'ancre par un OP (après tous les autres écouteurs, si personne n'a annulé) :
     * seul chemin de suppression par bloc. L'ascenseur est retiré des données puis du monde.
     */
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onAnchorBroken(BlockEvent.BreakEvent event) {
        if (event.isCanceled() || !(event.getPlayer() instanceof ServerPlayer player) || !player.hasPermissions(2)
                || !(event.getLevel() instanceof ServerLevel level) || !event.getState().is(ModBlocks.CABIN.get())) {
            return;
        }
        if (fr.minenorth.ascenseur.cabin.ElevatorBlocks.removeElevatorAt(level, event.getPos())) {
            player.displayClientMessage(Component.literal("Ascenseur supprimé."), true);
        }
    }
    @SubscribeEvent
    public static void onExplosion(ExplosionEvent.Detonate event) {
        if (!(event.getLevel() instanceof ServerLevel level)) {
            return;
        }
        event.getAffectedBlocks().removeIf(pos -> {
            BlockState state = level.getBlockState(pos);
            return isModBlock(state) || state.is(ModBlocks.CABIN_FLOOR.get()) || state.is(ModBlocks.CABIN_WALL.get());
        });
    }
}
