package fr.minenorth.ascenseur.network;

import fr.minenorth.ascenseur.client.ClientNetworkHandler;
import fr.minenorth.ascenseur.model.Floor;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.List;
import java.util.UUID;
import java.util.function.Supplier;

/**
 * Serveur vers client (OP seulement) : ouvre ou rafraîchit l'écran d'administration.
 * {@code size} au format "2x4", {@code companies} au format "id|nom", {@code error} vide si aucune erreur.
 * {@code color} et {@code glass} : personnalisation ({@code ElevatorStyle}) ; {@code doorSide} : bit
 * ({@code CabinWalls}) du côté porte, qui ne peut pas être vitré.
 */
public record AdminPanelPacket(UUID id, String name, String size, List<Floor> floors,
                               List<String> companies, String error, int color, int glass, int doorSide) {

    public static void encode(AdminPanelPacket p, FriendlyByteBuf b) {
        b.writeUUID(p.id);
        b.writeUtf(p.name, PacketLimits.MAX_NAME);
        b.writeUtf(p.size, PacketLimits.MAX_SIZE);
        PacketLimits.writeFloors(b, p.floors);
        b.writeCollection(p.companies, (buf, s) -> buf.writeUtf(s, PacketLimits.MAX_NAME));
        b.writeUtf(p.error, PacketLimits.MAX_ERROR);
        b.writeByte(p.color);
        b.writeByte(p.glass);
        b.writeByte(p.doorSide);
    }

    public static AdminPanelPacket decode(FriendlyByteBuf b) {
        UUID id = b.readUUID();
        String name = b.readUtf(PacketLimits.MAX_NAME);
        String size = b.readUtf(PacketLimits.MAX_SIZE);
        List<Floor> floors = PacketLimits.readFloors(b);
        List<String> companies = PacketLimits.readList(b, PacketLimits.MAX_COMPANIES,
                buf -> buf.readUtf(PacketLimits.MAX_NAME));
        String error = b.readUtf(PacketLimits.MAX_ERROR);
        int color = b.readByte();
        int glass = b.readByte() & 0x0F;
        int doorSide = b.readByte() & 0x0F;
        return new AdminPanelPacket(id, name, size, floors, companies, error, color, glass, doorSide);
    }

    public static void handle(AdminPanelPacket p, Supplier<NetworkEvent.Context> c) {
        c.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> ClientNetworkHandler.openAdminPanel(p)));
        c.get().setPacketHandled(true);
    }
}
