package fr.minenorth.ascenseur.cabin;

import fr.minenorth.ascenseur.block.CabinBlockEntity;
import fr.minenorth.ascenseur.block.CallButtonBlock;
import fr.minenorth.ascenseur.block.CallButtonBlockEntity;
import fr.minenorth.ascenseur.block.FloorDoorBlock;
import fr.minenorth.ascenseur.block.FloorDoorBlockEntity;
import fr.minenorth.ascenseur.block.FloorIndicatorBlock;
import fr.minenorth.ascenseur.block.FloorIndicatorBlockEntity;
import fr.minenorth.ascenseur.data.ElevatorData;
import fr.minenorth.ascenseur.data.StoredElevator;
import fr.minenorth.ascenseur.model.CabinFootprint;
import fr.minenorth.ascenseur.model.CabinSize;
import fr.minenorth.ascenseur.model.Elevator;
import fr.minenorth.ascenseur.model.Floor;
import fr.minenorth.ascenseur.model.FloorLinking;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.TreeSet;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Colle entre les blocs du mod (cabine, porte d'étage, bouton d'appel) et les ascenseurs : création
 * et suppression, liaison géométrique ({@link FloorLinking}), état ouvert/fermé des portes d'étage.
 * Serveur uniquement ; toute lecture du monde se limite aux chunks déjà chargés.
 */
public final class ElevatorBlocks {
    /** Hauteur du second étage par défaut au-dessus de l'ancre. */
    static final int DEFAULT_FLOOR_GAP = 4;

    private ElevatorBlocks() {
    }

    private static void tell(ServerPlayer player, String message) {
        player.displayClientMessage(Component.literal(message), true);
    }

    /** Empreinte de la cabine d'un ascenseur sauvegardé (orientation non horizontale : nord). */
    public static CabinFootprint footprintOf(StoredElevator stored) {
        Direction facing = horizontalFacing(stored);
        return CabinFootprint.of(stored.anchor().getX(), stored.anchor().getZ(), stored.elevator().size(),
                facing.getStepX(), facing.getStepZ());
    }

    static Direction horizontalFacing(StoredElevator stored) {
        return stored.facing().getAxis().isHorizontal() ? stored.facing() : Direction.NORTH;
    }

    static int[] floorYs(Elevator e) {
        List<Floor> floors = e.floors();
        int[] ys = new int[floors.size()];
        for (int i = 0; i < ys.length; i++) {
            ys[i] = floors.get(i).y();
        }
        return ys;
    }

    // --- Cabine : création, suppression, clic -------------------------------------------------------

    public static void refuseCabinPlacement(ServerPlayer player) {
        tell(player, "Seul un administrateur peut poser une cabine d'ascenseur.");
    }

    /** Vérifie qu'un ascenseur peut être créé avec cette ancre ; sinon prévient le joueur. */
    public static boolean canCreateAt(ServerLevel level, BlockPos pos, ServerPlayer player) {
        if (ElevatorData.get(level.getServer()).atAnchor(level.dimension(), pos).isPresent()) {
            return true; // repère reposé sur un ascenseur existant : il est simplement repris
        }
        if (pos.getY() + DEFAULT_FLOOR_GAP + CabinFootprint.INTERIOR_HEIGHT > level.getMaxBuildHeight()) {
            tell(player, "Trop haut : il faut de la place pour un second étage au-dessus.");
            return false;
        }
        CabinFootprint fp = CabinFootprint.of(pos.getX(), pos.getZ(), CabinSize.S1X1, 0, -1);
        Optional<String> overlap = overlapError(level.getServer(), level.dimension(), fp, null);
        if (overlap.isPresent()) {
            tell(player, overlap.get());
            return false;
        }
        return true;
    }

    /**
     * Message d'erreur si l'empreinte {@code fp} partage une colonne avec la gaine d'un autre
     * ascenseur de la même dimension ({@code self} exclu), sinon vide.
     */
    public static Optional<String> overlapError(net.minecraft.server.MinecraftServer server,
                                                net.minecraft.resources.ResourceKey<net.minecraft.world.level.Level> dim,
                                                CabinFootprint fp, @Nullable UUID self) {
        for (StoredElevator s : ElevatorData.get(server).all()) {
            if (s.dim().equals(dim) && !s.elevator().id().equals(self) && footprintOf(s).overlaps(fp)) {
                return Optional.of("La gaine chevaucherait celle de l'ascenseur « " + s.elevator().name() + " ».");
            }
        }
        return Optional.empty();
    }

    /**
     * Crée l'ascenseur par défaut (« Ascenseur », 1×1, deux étages publics à l'ancre et 4 blocs
     * au-dessus) et écrit son identifiant dans l'entité de bloc de la cabine. Si un ascenseur a déjà
     * cette ancre (repère retiré autrement que par une suppression), il est repris tel quel.
     */
    public static void createElevator(ServerLevel level, BlockPos pos, Direction facing, ServerPlayer player) {
        ElevatorData data = ElevatorData.get(level.getServer());
        Optional<StoredElevator> existing = data.atAnchor(level.dimension(), pos);
        if (existing.isPresent()) {
            if (level.getBlockEntity(pos) instanceof CabinBlockEntity be) {
                be.setElevatorId(existing.get().elevator().id());
            }
            tell(player, "Repère replacé : ascenseur « " + existing.get().elevator().name() + " » repris.");
            return;
        }
        UUID id = UUID.randomUUID();
        int y = pos.getY();
        List<Floor> floors = List.of(
                new Floor("Étage 0", y, "PUBLIC"),
                new Floor("Étage 1", y + DEFAULT_FLOOR_GAP, "PUBLIC"));
        Elevator elevator = new Elevator(id, "Ascenseur", CabinSize.S1X1, floors);
        data.put(new StoredElevator(elevator, level.dimension(), pos.immutable(), facing));
        if (level.getBlockEntity(pos) instanceof CabinBlockEntity be) {
            be.setElevatorId(id);
        }
        tell(player, "Ascenseur créé. Accroupi + clic droit sur la cabine pour le régler.");
    }

    /** Retrait du bloc cabine : l'ascenseur est retiré des données d'abord, puis du monde. */
    public static boolean removeElevatorAt(ServerLevel level, BlockPos pos) {
        ElevatorData data = ElevatorData.get(level.getServer());
        Optional<StoredElevator> stored = data.atAnchor(level.dimension(), pos);
        if (stored.isEmpty()) {
            return false;
        }
        UUID id = stored.get().elevator().id();
        data.remove(id);
        ElevatorService service = ElevatorService.current();
        if (service != null) {
            service.release(id, stored.get());
        }
        return true;
    }

    /**
     * Suppression en jeu (OP en créatif, accroupi, clic gauche sur la cabine) : l'ascenseur est retiré
     * des données d'abord, puis du monde ({@code release}) ; le repère au sol est retiré ensuite (son
     * {@code onRemove} ne trouve plus d'ascenseur et ne fait rien).
     */
    public static void deleteElevator(ServerLevel level, UUID id, ServerPlayer player) {
        ElevatorData data = ElevatorData.get(level.getServer());
        Optional<StoredElevator> stored = data.byId(id);
        if (stored.isEmpty()) {
            return;
        }
        data.remove(id);
        ElevatorService service = ElevatorService.current();
        if (service != null) {
            service.release(id, stored.get());
        }
        ServerLevel anchorLevel = level.getServer().getLevel(stored.get().dim());
        BlockPos anchor = stored.get().anchor();
        if (anchorLevel != null && anchorLevel.hasChunkAt(anchor)
                && anchorLevel.getBlockState(anchor).getBlock() instanceof fr.minenorth.ascenseur.block.CabinBlock) {
            anchorLevel.setBlock(anchor, net.minecraft.world.level.block.Blocks.AIR.defaultBlockState(), Block.UPDATE_ALL);
        }
        tell(player, "Ascenseur « " + stored.get().elevator().name() + " » supprimé.");
    }

    /** Clic droit sur la cabine : OP accroupi, administration ; sinon panneau d'étages. */
    public static void useCabinBlock(ServerLevel level, BlockPos pos, ServerPlayer player) {
        ElevatorData data = ElevatorData.get(level.getServer());
        Optional<StoredElevator> stored = data.atAnchor(level.dimension(), pos);
        ElevatorService service = ElevatorService.current();
        if (stored.isEmpty() || service == null) {
            tell(player, "Cette cabine n'est reliée à aucun ascenseur.");
            return;
        }
        UUID id = stored.get().elevator().id();
        if (player.isShiftKeyDown() && player.hasPermissions(2)) {
            service.openAdmin(player, id);
        } else if (!service.openPanel(player, id)) {
            tell(player, "Ascenseur indisponible.");
        }
    }

    // --- Liaison des portes et des boutons ----------------------------------------------------------

    private static List<FloorLinking.Shaft> shafts(ServerLevel level) {
        List<FloorLinking.Shaft> shafts = new ArrayList<>();
        for (StoredElevator s : ElevatorData.get(level.getServer()).all()) {
            if (s.dim().equals(level.dimension())) {
                shafts.add(shaftOf(s));
            }
        }
        return shafts;
    }

    private static FloorLinking.Shaft shaftOf(StoredElevator s) {
        return new FloorLinking.Shaft(s.elevator().id(), footprintOf(s), floorYs(s.elevator()));
    }

    /** Liaison valide d'un bloc (ascenseur existant, étage existant), sinon vide. */
    private static Optional<FloorLinking.Link> validLink(ServerLevel level, @Nullable UUID id, int floor) {
        if (id == null || floor < 0) {
            return Optional.empty();
        }
        Optional<StoredElevator> s = ElevatorData.get(level.getServer()).byId(id);
        if (s.isEmpty() || floor >= s.get().elevator().floors().size()) {
            return Optional.empty();
        }
        return Optional.of(new FloorLinking.Link(id, floor));
    }

    /** Liaison valide de la porte d'étage en {@code pos}, sinon vide. */
    public static Optional<FloorLinking.Link> doorLink(ServerLevel level, BlockPos pos) {
        if (level.getBlockEntity(pos) instanceof FloorDoorBlockEntity be) {
            return validLink(level, be.getElevatorId(), be.getFloorIndex());
        }
        return Optional.empty();
    }

    private static String describe(ServerLevel level, FloorLinking.Link link) {
        return ElevatorData.get(level.getServer()).byId(link.elevatorId())
                .map(s -> "« " + s.elevator().name() + " », " + s.elevator().floors().get(link.floorIndex()).name())
                .orElse("?");
    }

    /**
     * Porte posée par un OP : si elle est dans la rangée de palier d'une cabine à la hauteur d'un
     * étage, toute l'ouverture de cet étage (largeur de cabine × hauteur intérieure) est remplie de
     * portes reliées, tournées vers la cabine (indépendamment du regard du joueur) ; les cases déjà
     * occupées par un autre bloc sont laissées telles quelles.
     */
    public static void linkPlacedDoor(ServerLevel level, BlockPos pos, ServerPlayer player) {
        Optional<FloorLinking.Link> link = FloorLinking.byGeometry(shafts(level), pos.getX(), pos.getY(), pos.getZ());
        if (link.isEmpty()) {
            tell(player, "Porte non reliée : posez-la juste devant l'ouverture de la cabine, à la hauteur d'un étage.");
            return;
        }
        Optional<StoredElevator> stored = ElevatorData.get(level.getServer()).byId(link.get().elevatorId());
        if (stored.isEmpty()) {
            return;
        }
        CabinFootprint fp = footprintOf(stored.get());
        Direction towardCabin = horizontalFacing(stored.get()).getOpposite();
        int floorY = stored.get().elevator().floors().get(link.get().floorIndex()).y();
        Block doorBlock = fr.minenorth.ascenseur.block.ModBlocks.FLOOR_DOOR.get();
        int skipped = 0;
        for (int[] c : FloorLinking.openingCells(fp, floorY)) {
            BlockPos at = new BlockPos(c[0], c[1], c[2]);
            if (!level.hasChunkAt(at)) {
                skipped++;
                continue;
            }
            BlockState current = level.getBlockState(at);
            if (!current.is(doorBlock) && !current.canBeReplaced()) {
                skipped++;
                continue;
            }
            boolean threshold = fr.minenorth.ascenseur.model.DoorGeometry.isThreshold(floorY, at.getY());
            BlockState wanted = doorBlock.defaultBlockState().setValue(FloorDoorBlock.FACING, towardCabin)
                    .setValue(FloorDoorBlock.THRESHOLD, threshold)
                    .setValue(FloorDoorBlock.COLOR, doorColor(stored.get().style()));
            if (!current.is(doorBlock) || current.getValue(FloorDoorBlock.FACING) != towardCabin
                    || current.getValue(FloorDoorBlock.THRESHOLD) != threshold) {
                level.setBlock(at, wanted, Block.UPDATE_ALL);
            }
            if (level.getBlockEntity(at) instanceof FloorDoorBlockEntity be) {
                be.setLink(link.get().elevatorId(), link.get().floorIndex());
            }
            refreshDoorState(level, at);
        }
        String extra = skipped > 0 ? " (" + skipped + " case(s) occupée(s) laissée(s) libre(s))" : "";
        tell(player, "Ouverture fermée par des portes : " + describe(level, link.get()) + "." + extra);
    }

    /** Garde contre la récursion : retirer une porte de l'ouverture ne relance pas le retrait. */
    private static boolean removingOpening;

    /** Valeur de la propriété « couleur » des portes : teinte, ou {@link FloorDoorBlock#DEFAULT_COLOR}. */
    static int doorColor(fr.minenorth.ascenseur.model.ElevatorStyle style) {
        return style.isDefaultColor() ? FloorDoorBlock.DEFAULT_COLOR : style.colorIndex();
    }

    /** Une porte reliée a été retirée : les autres portes de la même ouverture sont retirées aussi. */
    public static void removeOpening(ServerLevel level, BlockPos pos, @Nullable UUID id, int floorIndex) {
        if (removingOpening || id == null || floorIndex < 0) {
            return;
        }
        Optional<StoredElevator> stored = ElevatorData.get(level.getServer()).byId(id);
        if (stored.isEmpty() || floorIndex >= stored.get().elevator().floors().size()) {
            return;
        }
        CabinFootprint fp = footprintOf(stored.get());
        int floorY = stored.get().elevator().floors().get(floorIndex).y();
        removingOpening = true;
        try {
            for (int[] c : FloorLinking.openingCells(fp, floorY)) {
                BlockPos at = new BlockPos(c[0], c[1], c[2]);
                if (at.equals(pos) || !level.hasChunkAt(at)) {
                    continue;
                }
                if (level.getBlockState(at).getBlock() instanceof FloorDoorBlock
                        && level.getBlockEntity(at) instanceof FloorDoorBlockEntity be
                        && id.equals(be.getElevatorId()) && be.getFloorIndex() == floorIndex) {
                    level.setBlock(at, net.minecraft.world.level.block.Blocks.AIR.defaultBlockState(), Block.UPDATE_ALL);
                }
            }
        } finally {
            removingOpening = false;
        }
    }

    /** Geste de liaison manuelle : OP, accroupi, main principale vide. */
    public static boolean isManualLinkGesture(net.minecraft.world.entity.player.Player player) {
        return player.isShiftKeyDown() && player.getMainHandItem().isEmpty() && player.hasPermissions(2);
    }

    /**
     * Liaison manuelle d'un afficheur, d'un bouton ou d'une porte d'étage ({@link
     * fr.minenorth.ascenseur.model.ManualLinking}) : l'ascenseur le plus proche (24 blocs) et l'étage de
     * hauteur la plus proche (6 blocs). Une liaison existante est remplacée.
     */
    public static void manualLink(ServerLevel level, BlockPos pos, ServerPlayer player) {
        List<StoredElevator> stored = new ArrayList<>(ElevatorData.get(level.getServer()).all());
        List<fr.minenorth.ascenseur.model.ManualLinking.Candidate> candidates = new ArrayList<>();
        for (StoredElevator s : stored) {
            candidates.add(new fr.minenorth.ascenseur.model.ManualLinking.Candidate(
                    s.dim().location().toString(), footprintOf(s), floorYs(s.elevator())));
        }
        var pick = fr.minenorth.ascenseur.model.ManualLinking.pick(candidates,
                level.dimension().location().toString(), pos.getX(), pos.getY(), pos.getZ());
        if (!pick.ok()) {
            tell(player, pick.failure() == fr.minenorth.ascenseur.model.ManualLinking.Failure.NO_ELEVATOR
                    ? "§cAucun ascenseur à moins de 24 blocs" : "§cAucun étage proche de cette hauteur");
            return;
        }
        StoredElevator s = stored.get(pick.elevator());
        UUID id = s.elevator().id();
        int floor = pick.floor();
        BlockEntity be = level.getBlockEntity(pos);
        if (be instanceof FloorIndicatorBlockEntity indicator) {
            indicator.setElevatorId(id);
            ElevatorService service = ElevatorService.current();
            indicator.setShown(service == null ? -1 : service.indicatorValue(id));
        } else if (be instanceof CallButtonBlockEntity button) {
            button.setLink(id, floor);
        } else if (be instanceof FloorDoorBlockEntity door) {
            door.setLink(id, floor);
            refreshDoorState(level, pos);
        } else {
            return;
        }
        tell(player, "§aLié à « " + s.elevator().name() + " » — étage " + floor
                + " (" + s.elevator().floors().get(floor).name() + ")");
    }

    /** Afficheur posé par un OP : relié à la gaine s'il est 1 à 3 blocs au-dessus d'une ouverture. */
    public static void linkPlacedIndicator(ServerLevel level, BlockPos pos, ServerPlayer player) {
        Optional<FloorLinking.Link> link = FloorLinking.forIndicator(shafts(level), pos.getX(), pos.getY(), pos.getZ());
        if (link.isEmpty()) {
            tell(player, "Afficheur non relié : posez-le au-dessus d'une porte d'étage, 1 à 3 blocs plus haut.");
            return;
        }
        Optional<StoredElevator> stored = ElevatorData.get(level.getServer()).byId(link.get().elevatorId());
        if (stored.isEmpty()) {
            return;
        }
        Direction towardCabin = horizontalFacing(stored.get()).getOpposite();
        BlockState state = level.getBlockState(pos);
        if (state.getBlock() instanceof FloorIndicatorBlock && state.getValue(FloorIndicatorBlock.FACING) != towardCabin) {
            level.setBlock(pos, state.setValue(FloorIndicatorBlock.FACING, towardCabin), Block.UPDATE_ALL);
        }
        if (level.getBlockEntity(pos) instanceof FloorIndicatorBlockEntity be) {
            be.setElevatorId(link.get().elevatorId());
            ElevatorService service = ElevatorService.current();
            be.setShown(service == null ? -1 : service.indicatorValue(link.get().elevatorId()));
        }
        tell(player, "Afficheur relié : « " + stored.get().elevator().name() + " ».");
    }

    /**
     * Met à jour les afficheurs de la gaine (rangée de palier, 1 à 3 blocs au-dessus de chaque
     * ouverture, chunks chargés) ; appelé seulement quand la valeur change.
     */
    static void applyIndicators(ServerLevel level, UUID id, CabinFootprint fp, int[] floorYs, int value) {
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        for (int floorY : floorYs) {
            int top = floorY + CabinFootprint.INTERIOR_HEIGHT - 1;
            for (int a = 0; a < fp.width(); a++) {
                for (int dy = 1; dy <= FloorLinking.INDICATOR_REACH; dy++) {
                    p.set(fp.cellX(a, -1), top + dy, fp.cellZ(a, -1));
                    if (level.hasChunkAt(p) && level.getBlockState(p).getBlock() instanceof FloorIndicatorBlock
                            && level.getBlockEntity(p) instanceof FloorIndicatorBlockEntity be
                            && id.equals(be.getElevatorId())) {
                        be.setShown(value);
                    }
                }
            }
        }
    }

    /**
     * Allume ou éteint les boutons d'appel des étages dont le bit a changé dans {@code changed}
     * (autour de la rangée de palier, hauteur des ouvertures et jusqu'à 2 blocs au-dessus).
     */
    static void applyButtons(ServerLevel level, UUID id, CabinFootprint fp, int[] floorYs, long lit, long changed) {
        int margin = FloorLinking.BUTTON_REACH + 1;
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        for (int i = 0; i < floorYs.length && i < 64; i++) {
            if ((changed & (1L << i)) == 0) {
                continue;
            }
            boolean on = (lit & (1L << i)) != 0;
            int maxY = floorYs[i] + CabinFootprint.INTERIOR_HEIGHT - 1 + FloorLinking.BUTTON_REACH;
            for (int y = floorYs[i]; y <= maxY; y++) {
                for (int x = fp.minX() - margin; x < fp.maxX() + margin; x++) {
                    for (int z = fp.minZ() - margin; z < fp.maxZ() + margin; z++) {
                        p.set(x, y, z);
                        if (!level.hasChunkAt(p)) {
                            continue;
                        }
                        BlockState state = level.getBlockState(p);
                        if (state.getBlock() instanceof CallButtonBlock
                                && state.getValue(CallButtonBlock.LIT) != on
                                && level.getBlockEntity(p) instanceof CallButtonBlockEntity be
                                && id.equals(be.getElevatorId()) && be.getFloorIndex() == i) {
                            level.setBlock(p.immutable(), state.setValue(CallButtonBlock.LIT, on), Block.UPDATE_ALL);
                        }
                    }
                }
            }
        }
    }

    /** Pose d'une porte ou d'un bouton : OP uniquement ; un non-OP est prévenu (côté serveur). */
    public static boolean mayPlace(@Nullable net.minecraft.world.entity.player.Player player) {
        if (player != null && player.hasPermissions(2)) {
            return true;
        }
        if (player instanceof ServerPlayer sp) {
            tell(sp, "Seul un administrateur peut poser les blocs d'ascenseur.");
        }
        return false;
    }

    /** Bouton posé par un OP : liaison de la porte liée la plus proche, sinon règle des portes. */
    public static void linkPlacedButton(ServerLevel level, BlockPos pos, ServerPlayer player) {
        if (!(level.getBlockEntity(pos) instanceof CallButtonBlockEntity be)) {
            return;
        }
        Optional<FloorLinking.Link> link = FloorLinking.forButton(linkedDoorsAround(level, pos), shafts(level),
                pos.getX(), pos.getY(), pos.getZ());
        if (link.isEmpty()) {
            tell(player, "Bouton non relié : posez-le à côté d'une porte d'étage reliée.");
            return;
        }
        be.setLink(link.get().elevatorId(), link.get().floorIndex());
        tell(player, "Bouton relié : " + describe(level, link.get()) + ".");
    }

    /** Portes liées autour d'un bouton (portée {@link FloorLinking#BUTTON_REACH}, même hauteur ou dessous). */
    private static List<FloorLinking.LinkedDoor> linkedDoorsAround(ServerLevel level, BlockPos pos) {
        List<FloorLinking.LinkedDoor> doors = new ArrayList<>();
        int r = FloorLinking.BUTTON_REACH;
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        for (int dy = -r; dy <= 0; dy++) {
            for (int dx = -r; dx <= r; dx++) {
                for (int dz = -r; dz <= r; dz++) {
                    p.set(pos.getX() + dx, pos.getY() + dy, pos.getZ() + dz);
                    if (!level.hasChunkAt(p) || !(level.getBlockState(p).getBlock() instanceof FloorDoorBlock)) {
                        continue;
                    }
                    BlockPos at = p.immutable();
                    doorLink(level, at).ifPresent(l -> doors.add(new FloorLinking.LinkedDoor(at.getX(), at.getY(), at.getZ(), l)));
                }
            }
        }
        return doors;
    }

    /** Bouton d'appel pressé : appel de la cabine si le bouton est relié (rôle vérifié par le service). */
    public static void pressButton(ServerLevel level, BlockPos pos, ServerPlayer player) {
        Optional<FloorLinking.Link> link = Optional.empty();
        if (level.getBlockEntity(pos) instanceof CallButtonBlockEntity be) {
            link = validLink(level, be.getElevatorId(), be.getFloorIndex());
        }
        ElevatorService service = ElevatorService.current();
        if (link.isEmpty() || service == null) {
            tell(player, "Ce bouton n'est relié à aucun ascenseur.");
            return;
        }
        service.handleCall(player, link.get().elevatorId(), link.get().floorIndex());
    }

    /**
     * Après un réglage admin : les portes et boutons de la gaine (ancienne et nouvelle empreinte,
     * ouvertures des anciens et nouveaux étages, chunks chargés uniquement) sont reliés à nouveau.
     * Une porte prend l'étage dont l'ouverture contient sa hauteur, ou perd sa liaison si elle n'est
     * plus devant la cabine ; une porte libre bien placée est reliée. Un bouton prend la liaison de la
     * porte voisine, sinon l'étage de sa hauteur (index -1 s'il n'y en a plus).
     */
    static void relink(ServerLevel level, StoredElevator now, @Nullable StoredElevator previous) {
        UUID id = now.elevator().id();
        FloorLinking.Shaft shaft = shaftOf(now);
        List<FloorLinking.Shaft> shafts = List.of(shaft);
        CabinFootprint fp = shaft.footprint();
        int margin = FloorLinking.BUTTON_REACH + 1;
        int minX = fp.minX() - margin;
        int maxX = fp.maxX() + margin;
        int minZ = fp.minZ() - margin;
        int maxZ = fp.maxZ() + margin;
        TreeSet<Integer> ys = new TreeSet<>();
        addOpenings(ys, shaft.floorYs());
        if (previous != null && previous.dim().equals(now.dim())) {
            CabinFootprint old = footprintOf(previous);
            minX = Math.min(minX, old.minX() - margin);
            maxX = Math.max(maxX, old.maxX() + margin);
            minZ = Math.min(minZ, old.minZ() - margin);
            maxZ = Math.max(maxZ, old.maxZ() + margin);
            addOpenings(ys, floorYs(previous.elevator()));
        }
        ElevatorData data = ElevatorData.get(level.getServer());
        ElevatorService service = ElevatorService.current();
        List<BlockPos> buttons = new ArrayList<>();
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        for (int y : ys) {
            for (int x = minX; x < maxX; x++) {
                for (int z = minZ; z < maxZ; z++) {
                    p.set(x, y, z);
                    if (!level.hasChunkAt(p)) {
                        continue;
                    }
                    BlockState state = level.getBlockState(p);
                    if (state.getBlock() instanceof CallButtonBlock) {
                        buttons.add(p.immutable());
                        continue;
                    }
                    if (!(state.getBlock() instanceof FloorDoorBlock)
                            || !(level.getBlockEntity(p) instanceof FloorDoorBlockEntity be)) {
                        continue;
                    }
                    boolean ours = id.equals(be.getElevatorId());
                    boolean free = be.getElevatorId() == null || data.byId(be.getElevatorId()).isEmpty();
                    if (!ours && !free) {
                        continue;
                    }
                    Optional<FloorLinking.Link> link = FloorLinking.byGeometry(shafts, x, y, z);
                    if (link.isPresent()) {
                        be.setLink(id, link.get().floorIndex());
                    } else if (ours) {
                        be.setLink(null, -1);
                    }
                    BlockPos at = p.immutable();
                    boolean open = link.isPresent() && service != null && service.isDoorOpenAt(id, link.get().floorIndex());
                    setOpen(level, at, open);
                }
            }
        }
        for (BlockPos at : buttons) {
            if (!(level.getBlockEntity(at) instanceof CallButtonBlockEntity be)) {
                continue;
            }
            boolean ours = id.equals(be.getElevatorId());
            boolean free = be.getElevatorId() == null || data.byId(be.getElevatorId()).isEmpty();
            if (!ours && !free) {
                continue;
            }
            Optional<FloorLinking.Link> link = FloorLinking.forButton(linkedDoorsAround(level, at), shafts,
                    at.getX(), at.getY(), at.getZ());
            if (link.isPresent() && link.get().elevatorId().equals(id)) {
                be.setLink(id, link.get().floorIndex());
            } else if (ours) {
                be.setLink(id, FloorLinking.floorForBlockY(shaft.floorYs(), at.getY()));
            }
        }
    }

    private static void addOpenings(TreeSet<Integer> ys, int[] floorYs) {
        for (int fy : floorYs) {
            for (int dy = 0; dy < CabinFootprint.INTERIOR_HEIGHT; dy++) {
                ys.add(fy + dy);
            }
        }
    }

    // --- État des portes d'étage --------------------------------------------------------------------

    /** Ouverte si la cabine de son ascenseur est arrêtée à son étage, portes ouvertes ; sinon fermée. */
    static void refreshDoorState(ServerLevel level, BlockPos pos) {
        Optional<FloorLinking.Link> link = doorLink(level, pos);
        ElevatorService service = ElevatorService.current();
        boolean open = link.isPresent() && service != null
                && service.isDoorOpenAt(link.get().elevatorId(), link.get().floorIndex());
        setOpen(level, pos, open);
    }

    private static void setOpen(ServerLevel level, BlockPos pos, boolean open) {
        BlockState state = level.getBlockState(pos);
        if (state.getBlock() instanceof FloorDoorBlock && state.getValue(FloorDoorBlock.OPEN) != open) {
            level.setBlock(pos, state.setValue(FloorDoorBlock.OPEN, open), Block.UPDATE_ALL);
        }
    }

    /**
     * Met les portes de l'ouverture de l'étage {@code floorIndex} (rangée de palier, chunks chargés)
     * liées à {@code id} dans l'état voulu : ouverte seulement si son étage est {@code openFloor}.
     * Avec {@code skipRow}, les portes de cette rangée de palier sont ignorées (nouvelle empreinte).
     *
     * @return faux si une case n'était pas chargée
     */
    static boolean applyDoors(ServerLevel level, UUID id, CabinFootprint fp, int floorY, int openFloor,
                              @Nullable CabinFootprint skipRow, fr.minenorth.ascenseur.model.ElevatorStyle style) {
        int color = doorColor(style);
        boolean complete = true;
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        for (int a = 0; a < fp.width(); a++) {
            int x = fp.cellX(a, -1);
            int z = fp.cellZ(a, -1);
            if (skipRow != null && FloorLinking.inLandingRow(skipRow, x, z)) {
                continue;
            }
            for (int dy = 0; dy < CabinFootprint.INTERIOR_HEIGHT; dy++) {
                p.set(x, floorY + dy, z);
                if (!level.hasChunkAt(p)) {
                    complete = false;
                    continue;
                }
                BlockState state = level.getBlockState(p);
                if (!(state.getBlock() instanceof FloorDoorBlock)) {
                    continue;
                }
                BlockEntity be = level.getBlockEntity(p);
                if (!(be instanceof FloorDoorBlockEntity door) || !id.equals(door.getElevatorId())) {
                    continue;
                }
                boolean open = openFloor >= 0 && door.getFloorIndex() == openFloor;
                // Remise en ordre au passage : panneau tourné vers la cabine, seuil seulement en bas
                // (corrige aussi les portes posées avec une version antérieure).
                Direction towardCabin = Direction.fromDelta(-fp.facingX(), 0, -fp.facingZ());
                BlockState wanted = state.setValue(FloorDoorBlock.OPEN, open)
                        .setValue(FloorDoorBlock.FACING, towardCabin)
                        .setValue(FloorDoorBlock.THRESHOLD, fr.minenorth.ascenseur.model.DoorGeometry.isThreshold(floorY, p.getY()))
                        .setValue(FloorDoorBlock.COLOR, color);
                if (wanted != state) {
                    level.setBlock(p.immutable(), wanted, Block.UPDATE_ALL);
                }
            }
        }
        return complete;
    }
}
