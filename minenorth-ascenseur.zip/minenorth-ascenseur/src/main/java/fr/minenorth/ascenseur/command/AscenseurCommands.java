package fr.minenorth.ascenseur.command;

import com.mojang.brigadier.arguments.StringArgumentType;
import fr.minenorth.ascenseur.MineNorthAscenseur;
import fr.minenorth.ascenseur.cabin.ElevatorService;
import fr.minenorth.ascenseur.config.AscenseurConfig;
import fr.minenorth.ascenseur.config.AscenseurSettings;
import fr.minenorth.ascenseur.data.ElevatorData;
import fr.minenorth.ascenseur.data.StoredElevator;
import fr.minenorth.ascenseur.model.ElevatorNameMatcher;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayList;
import java.util.List;

/** Commandes {@code /ascenseur list | remove <nom> | reload} (niveau 2). */
@Mod.EventBusSubscriber(modid = MineNorthAscenseur.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class AscenseurCommands {
    private AscenseurCommands() {
    }

    @SubscribeEvent
    public static void register(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("ascenseur")
                .requires(s -> s.hasPermission(2))
                .then(Commands.literal("list").executes(c -> list(c.getSource())))
                .then(Commands.literal("reload").executes(c -> reload(c.getSource())))
                .then(Commands.literal("remove")
                        .then(Commands.argument("nom", StringArgumentType.greedyString())
                                .executes(c -> remove(c.getSource(), StringArgumentType.getString(c, "nom"))))));
    }

    private static int list(CommandSourceStack src) {
        ElevatorData data = ElevatorData.get(src.getServer());
        ElevatorService service = ElevatorService.current();
        if (data.all().isEmpty()) {
            src.sendSuccess(() -> Component.literal("§7Aucun ascenseur."), false);
            return 0;
        }
        int count = data.all().size();
        src.sendSuccess(() -> Component.literal("§6Ascenseurs (" + count + ") :"), false);
        for (StoredElevator s : data.all()) {
            boolean active = service != null && service.isActive(s.elevator().id());
            String line = "§e" + s.elevator().name() + " §7[" + ElevatorNameMatcher.shortId(s.elevator().id()) + "] §f"
                    + s.dim().location() + " " + s.anchor().getX() + " " + s.anchor().getY() + " " + s.anchor().getZ()
                    + " §7- cabine " + s.elevator().size().width() + "x" + s.elevator().size().depth()
                    + ", " + s.elevator().floors().size() + " étages, "
                    + (active ? "§aactif" : "§cinactif");
            src.sendSuccess(() -> Component.literal(line), false);
        }
        return count;
    }

    private static int remove(CommandSourceStack src, String input) {
        ElevatorData data = ElevatorData.get(src.getServer());
        List<ElevatorNameMatcher.Candidate> all = new ArrayList<>();
        for (StoredElevator s : data.all()) {
            all.add(new ElevatorNameMatcher.Candidate(s.elevator().id(), s.elevator().name()));
        }
        ElevatorNameMatcher.Result r = ElevatorNameMatcher.match(all, input);
        if (r.none()) {
            src.sendFailure(Component.literal("§cAucun ascenseur ne correspond à « " + input + " »."));
            return 0;
        }
        if (r.ambiguous()) {
            StringBuilder sb = new StringBuilder("§cPlusieurs ascenseurs correspondent, précisez le début de l'identifiant :");
            for (ElevatorNameMatcher.Candidate c : r.matches()) {
                sb.append("\n§e").append(c.name()).append(" §7[").append(ElevatorNameMatcher.shortId(c.id())).append("]");
            }
            src.sendFailure(Component.literal(sb.toString()));
            return 0;
        }
        ElevatorNameMatcher.Candidate c = r.single();
        StoredElevator stored = data.byId(c.id()).orElse(null);
        if (stored == null) {
            return 0;
        }
        // Les données d'abord, sinon le service réactiverait l'ascenseur au tick suivant.
        data.remove(c.id());
        ElevatorService service = ElevatorService.current();
        if (service != null) {
            service.release(c.id(), stored);
        }
        src.sendSuccess(() -> Component.literal("§aAscenseur « " + c.name() + " » supprimé. "
                + "§7Le bloc cabine reste en place : cassez-le ou retirez-le."), true);
        return 1;
    }

    private static int reload(CommandSourceStack src) {
        AscenseurSettings s = AscenseurConfig.load();
        src.sendSuccess(() -> Component.literal("§aConfiguration rechargée : vitesse " + s.vitesseBlocsParSeconde()
                + " blocs/s, portes " + s.dureePortesSecondes() + " s. §7S'applique aux ascenseurs activés ensuite."), true);
        return 1;
    }
}
