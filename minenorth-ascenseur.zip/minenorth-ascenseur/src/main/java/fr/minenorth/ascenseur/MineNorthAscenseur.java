package fr.minenorth.ascenseur;

import fr.minenorth.ascenseur.block.ModBlocks;
import fr.minenorth.ascenseur.cabin.ModEntities;
import fr.minenorth.ascenseur.network.ModNetwork;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(MineNorthAscenseur.MOD_ID)
public class MineNorthAscenseur {
    public static final String MOD_ID = "minenorthascenseur";

    public MineNorthAscenseur() {
        ModBlocks.register(FMLJavaModLoadingContext.get().getModEventBus());
        ModEntities.register(FMLJavaModLoadingContext.get().getModEventBus());
        ModNetwork.register();
        fr.minenorth.ascenseur.config.AscenseurConfig.load();
    }
}
