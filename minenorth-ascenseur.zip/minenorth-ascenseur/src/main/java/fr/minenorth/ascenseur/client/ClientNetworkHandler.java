package fr.minenorth.ascenseur.client;

import fr.minenorth.ascenseur.network.AdminPanelPacket;
import fr.minenorth.ascenseur.network.ElevatorPanelPacket;
import net.minecraft.client.Minecraft;

/** Points d'entrée côté client des paquets serveur vers client (ne jamais référencer depuis le serveur). */
public final class ClientNetworkHandler {
    private ClientNetworkHandler() {
    }

    public static void openElevatorPanel(ElevatorPanelPacket p) {
        Minecraft.getInstance().setScreen(new ElevatorPanelScreen(p));
    }

    /** Ouvre l'écran d'administration, ou rafraîchit celui déjà ouvert pour le même ascenseur. */
    public static void openAdminPanel(AdminPanelPacket p) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.screen instanceof ElevatorAdminScreen open && open.elevatorId().equals(p.id())) {
            open.refresh(p);
        } else {
            mc.setScreen(new ElevatorAdminScreen(p));
        }
    }
}
