package fr.minenorth.ascenseur.compat;

import fr.minenorth.api.MineNorth;
import net.minecraft.server.level.ServerPlayer;

/** Pompiers et SAMU via MineNorth API (sans réflexion). Faux si le mod Secours est absent. */
public final class SecoursCompat {
    private SecoursCompat() {}

    public static boolean isSecours(ServerPlayer p) {
        try {
            return MineNorth.secours().isSecours(p);
        } catch (Throwable t) {
            return false;
        }
    }
}
