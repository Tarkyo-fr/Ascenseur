package fr.minenorth.ascenseur.block;

import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/** Entité de bloc de la porte d'étage : ascenseur lié ({@code elevatorId}) et étage ({@code floorIndex}, -1 si non défini). */
public class FloorDoorBlockEntity extends BlockEntity {
    private static final String TAG_ELEVATOR = "ElevatorId";
    private static final String TAG_FLOOR = "FloorIndex";

    @Nullable private UUID elevatorId;
    private int floorIndex = -1;

    public FloorDoorBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlocks.FLOOR_DOOR_BE.get(), pos, state);
    }

    @Nullable public UUID getElevatorId() { return elevatorId; }

    public int getFloorIndex() { return floorIndex; }

    public void setElevatorId(@Nullable UUID id) {
        this.elevatorId = id;
        syncChanged();
    }

    public void setFloorIndex(int floorIndex) {
        this.floorIndex = floorIndex;
        syncChanged();
    }

    /** Liaison complète (ascenseur et étage) en une seule mise à jour. */
    public void setLink(@Nullable UUID id, int floorIndex) {
        if (java.util.Objects.equals(this.elevatorId, id) && this.floorIndex == floorIndex) {
            return;
        }
        this.elevatorId = id;
        this.floorIndex = floorIndex;
        syncChanged();
    }

    private void syncChanged() {
        setChanged();
        if (level != null) level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        if (elevatorId != null) tag.putUUID(TAG_ELEVATOR, elevatorId);
        tag.putInt(TAG_FLOOR, floorIndex);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        elevatorId = tag.hasUUID(TAG_ELEVATOR) ? tag.getUUID(TAG_ELEVATOR) : null;
        floorIndex = tag.contains(TAG_FLOOR) ? tag.getInt(TAG_FLOOR) : -1;
    }

    @Override
    public CompoundTag getUpdateTag() {
        CompoundTag tag = super.getUpdateTag();
        saveAdditional(tag);
        return tag;
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }
}
