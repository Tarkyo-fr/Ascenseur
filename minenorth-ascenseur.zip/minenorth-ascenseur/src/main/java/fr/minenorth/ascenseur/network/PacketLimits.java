package fr.minenorth.ascenseur.network;

import fr.minenorth.ascenseur.model.Elevator;
import fr.minenorth.ascenseur.model.Floor;
import net.minecraft.network.FriendlyByteBuf;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

/**
 * Bornes de décodage partagées par tous les paquets : aucune liste ni chaîne n'est lue
 * sans limite, afin qu'un client hostile ne puisse pas provoquer d'allocation démesurée.
 */
public final class PacketLimits {
    public static final int MAX_FLOORS = Elevator.MAX_FLOORS;
    public static final int MAX_COMPANIES = 256;
    public static final int MAX_NAME = 64;
    public static final int MAX_ACCESS = 64;
    public static final int MAX_SIZE = 8;
    public static final int MAX_ERROR = 256;

    private PacketLimits() {
    }

    /** Lit un VarInt de taille et refuse (sans allouer) toute valeur négative ou supérieure à {@code max}. */
    public static int readCount(FriendlyByteBuf b, int max) {
        int n = b.readVarInt();
        if (n < 0 || n > max) {
            throw new IllegalArgumentException("Taille de liste invalide : " + n + " (max " + max + ")");
        }
        return n;
    }

    public static <T> List<T> readList(FriendlyByteBuf b, int max, Function<FriendlyByteBuf, T> reader) {
        int n = readCount(b, max);
        List<T> list = new ArrayList<>(n);
        for (int i = 0; i < n; i++) {
            list.add(reader.apply(b));
        }
        return list;
    }

    public static List<Floor> readFloors(FriendlyByteBuf b) {
        return readList(b, MAX_FLOORS,
                buf -> new Floor(buf.readUtf(MAX_NAME), buf.readInt(), buf.readUtf(MAX_ACCESS)));
    }

    /** Tronque une chaîne à {@code max} caractères (null devient vide) ; ne lève jamais. */
    public static String truncate(String s, int max) {
        if (s == null) {
            return "";
        }
        return s.length() <= max ? s : s.substring(0, max);
    }

    /**
     * Nettoie la liste "id|nom" venant du mod Entreprises avant envoi : au plus {@link #MAX_COMPANIES}
     * entrées, chacune d'au plus {@link #MAX_NAME} caractères ; seul le nom est tronqué, jamais l'id.
     */
    public static List<String> sanitizeCompanies(List<String> companies) {
        List<String> out = new ArrayList<>();
        if (companies == null) {
            return out;
        }
        for (String entry : companies) {
            if (out.size() >= MAX_COMPANIES) {
                break;
            }
            if (entry == null) {
                continue;
            }
            // "id|nom" : l'id précède le nom, donc couper la fin ne touche que le nom.
            out.add(truncate(entry, MAX_NAME));
        }
        return out;
    }

    /** Copie des étages avec noms et accès tronqués aux bornes du réseau (au plus {@link #MAX_FLOORS}). */
    public static List<Floor> sanitizeFloors(List<Floor> floors) {
        List<Floor> out = new ArrayList<>();
        for (Floor f : floors) {
            if (out.size() >= MAX_FLOORS) {
                break;
            }
            out.add(new Floor(truncate(f.name(), MAX_NAME), f.y(), truncate(f.access(), MAX_ACCESS)));
        }
        return out;
    }

    public static void writeFloors(FriendlyByteBuf b, List<Floor> floors) {
        b.writeCollection(floors, (buf, f) -> {
            buf.writeUtf(f.name(), MAX_NAME);
            buf.writeInt(f.y());
            buf.writeUtf(f.access(), MAX_ACCESS);
        });
    }
}
