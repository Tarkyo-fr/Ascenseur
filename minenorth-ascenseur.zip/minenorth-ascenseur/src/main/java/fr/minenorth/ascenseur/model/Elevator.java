package fr.minenorth.ascenseur.model;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

/** Ascenseur immuable : identifiant, nom, taille de cabine et étages ordonnés. */
public final class Elevator {
    public static final int MIN_FLOORS = 2;
    public static final int MAX_FLOORS = 32;

    private final UUID id;
    private final String name;
    private final CabinSize size;
    private final List<Floor> floors;

    public Elevator(UUID id, String name, CabinSize size, List<Floor> floors) {
        if (id == null) {
            throw new IllegalArgumentException("Identifiant manquant.");
        }
        Optional<String> error = validate(name, size, floors);
        if (error.isPresent()) {
            throw new IllegalArgumentException(error.get());
        }
        this.id = id;
        this.name = name;
        this.size = size;
        this.floors = List.copyOf(floors);
    }

    public UUID id() {
        return id;
    }

    public String name() {
        return name;
    }

    public CabinSize size() {
        return size;
    }

    public List<Floor> floors() {
        return floors;
    }

    /** Vide si valide, sinon le premier message d'erreur (en français). */
    public static Optional<String> validate(String name, CabinSize size, List<Floor> floors) {
        if (name == null || name.isBlank()) {
            return Optional.of("Le nom de l'ascenseur ne peut pas être vide.");
        }
        if (size == null) {
            return Optional.of("La taille de la cabine est invalide.");
        }
        if (floors == null || floors.size() < MIN_FLOORS) {
            return Optional.of("Un ascenseur doit avoir au moins " + MIN_FLOORS + " étages.");
        }
        if (floors.size() > MAX_FLOORS) {
            return Optional.of("Un ascenseur ne peut pas avoir plus de " + MAX_FLOORS + " étages.");
        }
        Floor previous = null;
        for (int i = 0; i < floors.size(); i++) {
            Floor f = floors.get(i);
            if (f == null || f.name() == null || f.name().isBlank()) {
                return Optional.of("L'étage " + (i + 1) + " n'a pas de nom.");
            }
            if (previous != null && f.y() <= previous.y()) {
                return Optional.of("Les hauteurs des étages doivent être strictement croissantes ("
                        + f.name() + " : " + f.y() + ").");
            }
            previous = f;
        }
        return Optional.empty();
    }
}
