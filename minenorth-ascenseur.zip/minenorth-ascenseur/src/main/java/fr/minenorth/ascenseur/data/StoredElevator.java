package fr.minenorth.ascenseur.data;

import fr.minenorth.ascenseur.model.Elevator;
import fr.minenorth.ascenseur.model.ElevatorStyle;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;

/** Un ascenseur tel que sauvegardé : modèle, dimension, ancre, orientation et personnalisation. */
public record StoredElevator(Elevator elevator, ResourceKey<Level> dim, BlockPos anchor, Direction facing,
                             ElevatorStyle style) {
    public StoredElevator {
        style = style == null ? ElevatorStyle.DEFAULT : style;
    }

    /** Sans personnalisation : style par défaut. */
    public StoredElevator(Elevator elevator, ResourceKey<Level> dim, BlockPos anchor, Direction facing) {
        this(elevator, dim, anchor, facing, ElevatorStyle.DEFAULT);
    }
}
