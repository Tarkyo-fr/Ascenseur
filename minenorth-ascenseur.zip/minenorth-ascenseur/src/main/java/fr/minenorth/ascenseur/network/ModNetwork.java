package fr.minenorth.ascenseur.network;

import fr.minenorth.ascenseur.MineNorthAscenseur;
import fr.minenorth.ascenseur.compat.EntrepriseCompat;
import fr.minenorth.ascenseur.compat.ServerRoles;
import fr.minenorth.ascenseur.data.StoredElevator;
import fr.minenorth.ascenseur.model.CabinSize;
import fr.minenorth.ascenseur.model.CabinWalls;
import fr.minenorth.ascenseur.model.ElevatorStyle;
import net.minecraft.core.Direction;
import fr.minenorth.ascenseur.model.Elevator;
import fr.minenorth.ascenseur.model.Floor;
import fr.minenorth.ascenseur.model.FloorView;
import fr.minenorth.ascenseur.model.PanelBuilder;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.List;
import java.util.UUID;

/** Canal réseau du mod (identifiant minenorthascenseur:network). */
public final class ModNetwork {
    private static final String PROTOCOL = "1";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(MineNorthAscenseur.MOD_ID, "network"),
            () -> PROTOCOL,
            PROTOCOL::equals,
            PROTOCOL::equals);

    private ModNetwork() {
    }

    public static void register() {
        int id = 0;
        CHANNEL.registerMessage(id++, ElevatorPanelPacket.class,
                ElevatorPanelPacket::encode, ElevatorPanelPacket::decode, ElevatorPanelPacket::handle);
        CHANNEL.registerMessage(id++, SelectFloorPacket.class,
                SelectFloorPacket::encode, SelectFloorPacket::decode, SelectFloorPacket::handle);
        CHANNEL.registerMessage(id++, AdminPanelPacket.class,
                AdminPanelPacket::encode, AdminPanelPacket::decode, AdminPanelPacket::handle);
        CHANNEL.registerMessage(id++, AdminSavePacket.class,
                AdminSavePacket::encode, AdminSavePacket::decode, AdminSavePacket::handle);
    }

    /** Ouvre le panneau d'étages chez le joueur, construit selon ses rôles réels. */
    public static void sendPanel(ServerPlayer player, Elevator elevator, int currentFloor) {
        ElevatorPanelPacket packet = new ElevatorPanelPacket(
                elevator.id(),
                PacketLimits.truncate(elevator.name(), PacketLimits.MAX_NAME),
                PanelBuilder.forPlayer(elevator, ServerRoles.of(player), currentFloor).stream()
                        .map(v -> new FloorView(v.index(),
                                PacketLimits.truncate(v.name(), PacketLimits.MAX_NAME),
                                v.y(),
                                PacketLimits.truncate(v.roleLabel(), PacketLimits.MAX_NAME),
                                v.allowed(),
                                v.current()))
                        .toList());
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), packet);
    }

    /** Ouvre l'écran d'administration (à n'appeler que pour un OP). */
    public static void sendAdminPanel(ServerPlayer player, StoredElevator stored, String error) {
        Elevator elevator = stored.elevator();
        sendAdminPanel(player, elevator.id(), elevator.name(), sizeText(elevator.size()), elevator.floors(), error,
                stored.style(), doorSideBit(stored));
    }

    /** Bit {@code CabinWalls} du côté porte de la cabine. */
    public static int doorSideBit(StoredElevator stored) {
        Direction f = stored.facing().getAxis().isHorizontal() ? stored.facing() : Direction.NORTH;
        return CabinWalls.sideOf(f.getStepX(), f.getStepZ());
    }

    public static void sendAdminPanel(ServerPlayer player, UUID id, String name, String size,
                                      List<Floor> floors, String error, ElevatorStyle style, int doorSide) {
        // Les données stockées ou externes sont tronquées plutôt que de faire échouer l'encodage.
        List<String> companies = PacketLimits.sanitizeCompanies(EntrepriseCompat.companies(player.server));
        AdminPanelPacket packet = new AdminPanelPacket(id,
                PacketLimits.truncate(name, PacketLimits.MAX_NAME),
                PacketLimits.truncate(size, PacketLimits.MAX_SIZE),
                PacketLimits.sanitizeFloors(floors),
                companies,
                PacketLimits.truncate(error, PacketLimits.MAX_ERROR),
                style.colorIndex(), style.glassMask(), doorSide);
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), packet);
    }

    public static String sizeText(CabinSize size) {
        return size.width() + "x" + size.depth();
    }
}
