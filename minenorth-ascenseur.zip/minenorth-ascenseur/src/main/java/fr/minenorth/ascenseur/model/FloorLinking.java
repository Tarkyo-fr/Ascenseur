package fr.minenorth.ascenseur.model;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Liaison des portes d'étage et des boutons d'appel à un ascenseur, par la géométrie. Java pur.
 *
 * <p>Règle des portes : une porte appartient à l'ascenseur dont la rangée de palier (les cases
 * {@code cell(a, -1)} juste devant la porte de la cabine, voir {@link CabinFootprint}) contient sa
 * case X/Z, et à l'étage dont l'ouverture contient sa hauteur : {@code floorY <= y < floorY +
 * INTERIOR_HEIGHT}. On peut donc empiler des portes pour fermer toute la hauteur de l'ouverture.
 *
 * <p>Règle des boutons : le bouton prend la liaison de la porte liée la plus proche, à au plus
 * {@link #BUTTON_REACH} cases horizontalement et à la même hauteur ou jusqu'à {@link #BUTTON_REACH}
 * au-dessus (bouton à hauteur des yeux à côté d'une porte posée au sol) ; à défaut, la règle des portes.
 */
public final class FloorLinking {
    /** Distance maximale (cases) entre un bouton et la porte dont il copie la liaison. */
    public static final int BUTTON_REACH = 2;

    private FloorLinking() {
    }

    /** Une gaine candidate : ascenseur, empreinte de cabine et hauteurs d'étages (croissantes). */
    public record Shaft(UUID id, CabinFootprint footprint, int[] floorYs) {
    }

    /** Liaison résolue : ascenseur et index d'étage. */
    public record Link(UUID elevatorId, int floorIndex) {
    }

    /** Une porte déjà liée, à la position (x, y, z). */
    public record LinkedDoor(int x, int y, int z, Link link) {
    }

    /**
     * Index de l'étage dont l'ouverture contient la hauteur de bloc {@code y}, ou -1. Si des étages
     * sont à moins de {@link CabinFootprint#INTERIOR_HEIGHT} l'un de l'autre, le plus haut gagne
     * (donc un étage exactement à cette hauteur).
     */
    public static int floorForBlockY(int[] floorYs, int y) {
        for (int i = floorYs.length - 1; i >= 0; i--) {
            if (floorYs[i] <= y) {
                return y < floorYs[i] + CabinFootprint.INTERIOR_HEIGHT ? i : -1;
            }
        }
        return -1;
    }

    /** Vrai si la case (x, z) est dans la rangée de palier, juste devant la porte de la cabine. */
    public static boolean inLandingRow(CabinFootprint fp, int x, int z) {
        for (int a = 0; a < fp.width(); a++) {
            if (fp.cellX(a, -1) == x && fp.cellZ(a, -1) == z) {
                return true;
            }
        }
        return false;
    }

    /** Liaison d'une porte posée en (x, y, z) : première gaine qui correspond, sinon vide. */
    public static Optional<Link> byGeometry(List<Shaft> shafts, int x, int y, int z) {
        for (Shaft s : shafts) {
            if (!inLandingRow(s.footprint(), x, z)) {
                continue;
            }
            int floor = floorForBlockY(s.floorYs(), y);
            if (floor >= 0) {
                return Optional.of(new Link(s.id(), floor));
            }
        }
        return Optional.empty();
    }

    /** Liaison d'un bouton posé en (x, y, z) : porte liée la plus proche, sinon règle des portes. */
    public static Optional<Link> forButton(List<LinkedDoor> doors, List<Shaft> shafts, int x, int y, int z) {
        LinkedDoor best = null;
        int bestDist = Integer.MAX_VALUE;
        for (LinkedDoor d : doors) {
            int dx = d.x() - x;
            int dz = d.z() - z;
            int below = y - d.y();
            if (Math.abs(dx) > BUTTON_REACH || Math.abs(dz) > BUTTON_REACH || below < 0 || below > BUTTON_REACH) {
                continue;
            }
            int dist = dx * dx + dz * dz + below * below;
            if (dist < bestDist) {
                bestDist = dist;
                best = d;
            }
        }
        if (best != null) {
            return Optional.of(best.link());
        }
        return byGeometry(shafts, x, y, z);
    }

    /**
     * Cases de l'ouverture de palier d'un étage : la rangée {@code cell(a, -1)} sur toute la largeur
     * de la cabine et toute la hauteur intérieure, à partir de {@code floorY}. Chaque élément est
     * {x, y, z}. C'est là que les portes d'étage sont posées automatiquement.
     */
    public static List<int[]> openingCells(CabinFootprint fp, int floorY) {
        List<int[]> cells = new java.util.ArrayList<>();
        for (int a = 0; a < fp.width(); a++) {
            for (int dy = 0; dy < CabinFootprint.INTERIOR_HEIGHT; dy++) {
                cells.add(new int[] {fp.cellX(a, -1), floorY + dy, fp.cellZ(a, -1)});
            }
        }
        return cells;
    }

    /** Hauteur maximale (blocs) d'un afficheur d'étage au-dessus du haut de l'ouverture. */
    public static final int INDICATOR_REACH = 3;

    /**
     * Liaison d'un afficheur d'étage posé en (x, y, z) : dans la rangée de palier d'une gaine, de 1 à
     * {@link #INDICATOR_REACH} blocs au-dessus du haut de l'ouverture d'un étage (le plus proche gagne).
     */
    public static java.util.Optional<Link> forIndicator(List<Shaft> shafts, int x, int y, int z) {
        for (Shaft s : shafts) {
            if (!inLandingRow(s.footprint(), x, z)) {
                continue;
            }
            int best = -1;
            int bestOffset = Integer.MAX_VALUE;
            for (int i = 0; i < s.floorYs().length; i++) {
                int top = s.floorYs()[i] + CabinFootprint.INTERIOR_HEIGHT - 1;
                int offset = y - top;
                if (offset >= 1 && offset <= INDICATOR_REACH && offset < bestOffset) {
                    bestOffset = offset;
                    best = i;
                }
            }
            if (best >= 0) {
                return java.util.Optional.of(new Link(s.id(), best));
            }
        }
        return java.util.Optional.empty();
    }
}
