package fr.minenorth.ascenseur.cabin;

import fr.minenorth.ascenseur.MineNorthAscenseur;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingFallEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStartingEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Branchement de {@link ElevatorService} sur les événements serveur de Forge. */
@Mod.EventBusSubscriber(modid = MineNorthAscenseur.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class CabinEvents {
    private CabinEvents() {
    }

    @SubscribeEvent
    public static void onServerStarting(ServerStartingEvent event) {
        ElevatorService.start(event.getServer());
    }

    /** Après l'arrêt complet (les joueurs ont déjà été déconnectés et déposés à un étage). */
    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent event) {
        ElevatorService.stop();
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        ElevatorService service = ElevatorService.current();
        if (service == null) {
            return;
        }
        if (event.phase == TickEvent.Phase.START) {
            service.tickStart();
        } else {
            service.tickEnd();
        }
    }

    /**
     * Appelé avant que Minecraft ne retire le joueur : s'il est passager, il est déposé à l'étage de
     * destination. Sinon Minecraft supprimerait la cabine avec lui (véhicule à un seul joueur).
     */
    @SubscribeEvent
    public static void onLoggedOut(PlayerEvent.PlayerLoggedOutEvent event) {
        ElevatorService service = ElevatorService.current();
        if (service != null && event.getEntity() instanceof ServerPlayer player) {
            service.onPlayerLoggedOut(player);
        }
    }

    /** Connexion : un joueur revenu au-dessus du vide d'une gaine est déposé sur le palier (vérifié après quelques ticks). */
    @SubscribeEvent
    public static void onLoggedIn(PlayerEvent.PlayerLoggedInEvent event) {
        ElevatorService service = ElevatorService.current();
        if (service != null && event.getEntity() instanceof ServerPlayer player) {
            service.onPlayerLoggedIn(player);
        }
    }

    /**
     * Filet de sécurité : aucune chute ne blesse une créature (joueur, monture, animal…) dans la
     * colonne d'une gaine. Les montures ne sont pas transportées : elles tombent au fond, indemnes.
     */
    @SubscribeEvent
    public static void onFall(LivingFallEvent event) {
        ElevatorService service = ElevatorService.current();
        if (service != null && !event.getEntity().level().isClientSide() && service.isInShaft(event.getEntity())) {
            event.setCanceled(true);
        }
    }
}
