package fr.minenorth.ascenseur.client;

import fr.minenorth.ascenseur.model.FloorView;
import fr.minenorth.ascenseur.network.ElevatorPanelPacket;
import fr.minenorth.ascenseur.network.ModNetwork;
import fr.minenorth.ascenseur.network.SelectFloorPacket;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractButton;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

/** Panneau d'étages de la cabine : boutons ronds, du plus bas (en bas) au plus haut (en haut). */
public class ElevatorPanelScreen extends Screen {
    private static final int BUTTON = 24;
    private static final int GAP = 4;
    private static final int HEADER = 48;
    private static final int FOOTER = 12;
    private static final int MIN_WIDTH = 170;

    private final ElevatorPanelPacket data;
    private final List<FloorButton> buttons = new ArrayList<>();
    private int left;
    private int top;
    private int panelWidth;
    private int panelHeight;

    public ElevatorPanelScreen(ElevatorPanelPacket data) {
        super(Component.literal(data.elevatorName()));
        this.data = data;
    }

    @Override
    protected void init() {
        buttons.clear();
        List<FloorView> floors = data.floors();
        int available = Math.max(BUTTON, this.height - 40 - HEADER - FOOTER);
        int rows = Math.max(1, Math.min(floors.size(), (available + GAP) / (BUTTON + GAP)));
        int columns = Math.max(1, (floors.size() + rows - 1) / rows);
        if (rows > floors.size()) {
            rows = floors.size();
        }
        int gridWidth = columns * BUTTON + (columns - 1) * GAP;
        int gridHeight = rows * BUTTON + (rows - 1) * GAP;
        panelWidth = Math.max(MIN_WIDTH, gridWidth + 40);
        panelHeight = HEADER + gridHeight + FOOTER;
        left = (this.width - panelWidth) / 2;
        top = (this.height - panelHeight) / 2;
        int gridLeft = left + (panelWidth - gridWidth) / 2;
        int gridBottom = top + HEADER + gridHeight;

        for (int i = 0; i < floors.size(); i++) {
            FloorView view = floors.get(i);
            int column = i / rows;
            int row = i % rows;
            int x = gridLeft + column * (BUTTON + GAP);
            int y = gridBottom - BUTTON - row * (BUTTON + GAP);
            FloorButton button = new FloorButton(x, y, view, () -> select(view));
            buttons.add(button);
            addRenderableWidget(button);
        }
    }

    private void select(FloorView view) {
        ModNetwork.CHANNEL.sendToServer(new SelectFloorPacket(data.elevatorId(), view.index()));
        onClose();
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderBackground(g);
        MineNorthStyle.panel(g, left, top, panelWidth, panelHeight, data.elevatorName(), "Choisissez un étage");
        super.render(g, mouseX, mouseY, partialTick);
        for (FloorButton b : buttons) {
            if (b.isMouseOver(mouseX, mouseY)) {
                g.renderTooltip(this.font, Component.literal(b.view.tooltip()), mouseX, mouseY);
                break;
            }
        }
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    /** Bouton d'étage rond : étage actuel entouré, étages interdits éteints et non cliquables. */
    private static final class FloorButton extends AbstractButton {
        private final FloorView view;
        private final Runnable action;

        FloorButton(int x, int y, FloorView view, Runnable action) {
            super(x, y, BUTTON, BUTTON, Component.literal(String.valueOf(view.index())));
            this.view = view;
            this.action = action;
            this.active = view.allowed() && !view.current();
        }

        @Override
        public void onPress() {
            if (active) {
                action.run();
            }
        }

        @Override
        protected void updateWidgetNarration(NarrationElementOutput out) {
            defaultButtonNarrationText(out);
        }

        @Override
        public void renderWidget(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
            int radius = width / 2;
            int cx = getX() + radius;
            int cy = getY() + radius;
            boolean hover = isHoveredOrFocused() && active;
            int fill;
            if (view.current()) {
                fill = MineNorthStyle.GREEN;
            } else if (!view.allowed()) {
                fill = MineNorthStyle.DISABLED;
            } else {
                fill = hover ? MineNorthStyle.HOVER : MineNorthStyle.DARK;
            }
            if (view.current()) {
                disc(g, cx, cy, radius, MineNorthStyle.CYAN);
                disc(g, cx, cy, radius - 2, fill);
            } else {
                disc(g, cx, cy, radius, fill);
            }
            Minecraft mc = Minecraft.getInstance();
            String label = getMessage().getString();
            int textColor = view.allowed() ? MineNorthStyle.WHITE : MineNorthStyle.MUTED;
            g.drawString(mc.font, label, cx - mc.font.width(label) / 2, cy - 4, textColor, false);
        }

        /** Disque plein dessiné ligne par ligne. */
        private static void disc(GuiGraphics g, int cx, int cy, int radius, int color) {
            for (int dy = -radius; dy < radius; dy++) {
                double centerOffset = dy + 0.5;
                int half = (int) Math.round(Math.sqrt(Math.max(0, radius * radius - centerOffset * centerOffset)));
                g.fill(cx - half, cy + dy, cx + half, cy + dy + 1, color);
            }
        }
    }
}
