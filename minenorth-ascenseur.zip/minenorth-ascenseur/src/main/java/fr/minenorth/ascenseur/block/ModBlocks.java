package fr.minenorth.ascenseur.block;

import fr.minenorth.ascenseur.MineNorthAscenseur;
import fr.minenorth.ascenseur.cabin.CabinFloorBlock;
import fr.minenorth.ascenseur.cabin.CabinWallBlock;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** Enregistrements des blocs de l'ascenseur (blocs, entités de bloc, objets). */
public final class ModBlocks {
    private ModBlocks() {}

    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, MineNorthAscenseur.MOD_ID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MineNorthAscenseur.MOD_ID);
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, MineNorthAscenseur.MOD_ID);

    public static final RegistryObject<Block> CABIN = BLOCKS.register("cabine", CabinBlock::new);
    public static final RegistryObject<Block> CALL_BUTTON = BLOCKS.register("bouton_appel", CallButtonBlock::new);
    public static final RegistryObject<Block> FLOOR_DOOR = BLOCKS.register("porte_etage", FloorDoorBlock::new);
    /** Plancher invisible posé sous la cabine arrêtée (géré par ElevatorService, sans objet). */
    public static final RegistryObject<Block> CABIN_FLOOR = BLOCKS.register("plancher_cabine", CabinFloorBlock::new);
    /** Parois invisibles de la cabine arrêtée (gérées par ElevatorService, sans objet). */
    public static final RegistryObject<Block> CABIN_WALL = BLOCKS.register("paroi_cabine", CabinWallBlock::new);

    public static final RegistryObject<Item> CABIN_ITEM = ITEMS.register("cabine",
            () -> new BlockItem(CABIN.get(), new Item.Properties()));
    public static final RegistryObject<Item> CALL_BUTTON_ITEM = ITEMS.register("bouton_appel",
            () -> new BlockItem(CALL_BUTTON.get(), new Item.Properties()));
    public static final RegistryObject<Item> FLOOR_DOOR_ITEM = ITEMS.register("porte_etage",
            () -> new BlockItem(FLOOR_DOOR.get(), new Item.Properties()));

    public static final RegistryObject<BlockEntityType<CabinBlockEntity>> CABIN_BE = BLOCK_ENTITIES.register("cabine",
            () -> BlockEntityType.Builder.of(CabinBlockEntity::new, CABIN.get()).build(null));
    public static final RegistryObject<BlockEntityType<CallButtonBlockEntity>> CALL_BUTTON_BE = BLOCK_ENTITIES.register("bouton_appel",
            () -> BlockEntityType.Builder.of(CallButtonBlockEntity::new, CALL_BUTTON.get()).build(null));
    public static final RegistryObject<BlockEntityType<FloorDoorBlockEntity>> FLOOR_DOOR_BE = BLOCK_ENTITIES.register("porte_etage",
            () -> BlockEntityType.Builder.of(FloorDoorBlockEntity::new, FLOOR_DOOR.get()).build(null));

    public static final RegistryObject<Block> FLOOR_INDICATOR = BLOCKS.register("afficheur_etage", FloorIndicatorBlock::new);
    public static final RegistryObject<Item> FLOOR_INDICATOR_ITEM = ITEMS.register("afficheur_etage",
            () -> new BlockItem(FLOOR_INDICATOR.get(), new Item.Properties()));
    public static final RegistryObject<BlockEntityType<FloorIndicatorBlockEntity>> FLOOR_INDICATOR_BE =
            BLOCK_ENTITIES.register("afficheur_etage",
                    () -> BlockEntityType.Builder.of(FloorIndicatorBlockEntity::new, FLOOR_INDICATOR.get()).build(null));

    public static void register(IEventBus bus) {
        BLOCKS.register(bus);
        ITEMS.register(bus);
        BLOCK_ENTITIES.register(bus);
    }

    /** Les objets de ce mod vont dans l'onglet créatif commun « MineNorth » (fourni par minenorth_api). */
    @Mod.EventBusSubscriber(modid = MineNorthAscenseur.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD)
    public static final class SharedTab {
        private SharedTab() {}

        @SubscribeEvent
        public static void fill(BuildCreativeModeTabContentsEvent e) {
            if (!e.getTabKey().location().equals(new ResourceLocation("minenorthapi", "minenorth"))) return;
            e.accept(CABIN_ITEM);
            e.accept(CALL_BUTTON_ITEM);
            e.accept(FLOOR_DOOR_ITEM);
            e.accept(FLOOR_INDICATOR_ITEM);
        }
    }
}
