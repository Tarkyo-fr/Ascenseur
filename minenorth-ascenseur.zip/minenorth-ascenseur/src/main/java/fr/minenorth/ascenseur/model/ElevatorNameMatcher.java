package fr.minenorth.ascenseur.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

/** Résolution d'un ascenseur par nom ou par début d'identifiant (commande /ascenseur remove). */
public final class ElevatorNameMatcher {
    private ElevatorNameMatcher() {
    }

    /** Candidat : identifiant et nom. */
    public record Candidate(UUID id, String name) {
    }

    /** Résultat : exactement un ascenseur, aucun, ou plusieurs (ambigu). */
    public record Result(List<Candidate> matches) {
        public boolean none() {
            return matches.isEmpty();
        }

        public boolean ambiguous() {
            return matches.size() > 1;
        }

        public Candidate single() {
            return matches.get(0);
        }
    }

    /**
     * Cherche d'abord un début d'identifiant (si la saisie en ressemble : 4 caractères hexadécimaux
     * ou plus), puis un nom exact (sans casse), puis un nom contenant la saisie. Le premier niveau
     * qui donne des résultats gagne.
     */
    public static Result match(List<Candidate> all, String input) {
        String q = input == null ? "" : input.trim().toLowerCase(Locale.ROOT);
        if (q.isEmpty()) {
            return new Result(List.of());
        }
        List<Candidate> out = new ArrayList<>();
        if (q.length() >= 4 && q.matches("[0-9a-f-]+")) {
            for (Candidate c : all) {
                if (c.id().toString().startsWith(q)) {
                    out.add(c);
                }
            }
            if (!out.isEmpty()) {
                return new Result(List.copyOf(out));
            }
        }
        for (Candidate c : all) {
            if (c.name().toLowerCase(Locale.ROOT).equals(q)) {
                out.add(c);
            }
        }
        if (!out.isEmpty()) {
            return new Result(List.copyOf(out));
        }
        for (Candidate c : all) {
            if (c.name().toLowerCase(Locale.ROOT).contains(q)) {
                out.add(c);
            }
        }
        return new Result(List.copyOf(out));
    }

    /** Début d'identifiant affiché (8 caractères). */
    public static String shortId(UUID id) {
        return id.toString().substring(0, 8);
    }
}
