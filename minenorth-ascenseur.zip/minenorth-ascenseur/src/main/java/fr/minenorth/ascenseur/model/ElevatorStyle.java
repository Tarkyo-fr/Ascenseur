package fr.minenorth.ascenseur.model;

import java.util.Optional;

/**
 * Personnalisation d'un ascenseur (Java pur) : couleur des parois et de l'encadrement (une des 16
 * teintes de colorant, ou {@link #DEFAULT_COLOR} pour l'aspect clair d'origine) et côtés vitrés
 * (masque de bits {@link CabinWalls}, quatre côtés horizontaux ; le côté porte n'est jamais vitré,
 * voir {@link #effectiveGlass}).
 */
public record ElevatorStyle(int colorIndex, int glassMask) {
    public static final int DEFAULT_COLOR = -1;
    public static final int MAX_COLOR = 15;
    public static final int ALL_SIDES = CabinWalls.NORTH | CabinWalls.EAST | CabinWalls.SOUTH | CabinWalls.WEST;
    public static final ElevatorStyle DEFAULT = new ElevatorStyle(DEFAULT_COLOR, 0);

    public ElevatorStyle {
        Optional<String> error = validate(colorIndex, glassMask);
        if (error.isPresent()) {
            throw new IllegalArgumentException(error.get());
        }
    }

    /** Vide si valide, sinon le message d'erreur (en français). */
    public static Optional<String> validate(int colorIndex, int glassMask) {
        if (colorIndex < DEFAULT_COLOR || colorIndex > MAX_COLOR) {
            return Optional.of("Couleur de cabine invalide.");
        }
        if ((glassMask & ~ALL_SIDES) != 0) {
            return Optional.of("Côtés vitrés invalides.");
        }
        return Optional.empty();
    }

    /** Style lu d'une source non sûre (sauvegarde ancienne ou abîmée) : valeurs invalides remplacées par défaut. */
    public static ElevatorStyle sanitize(int colorIndex, int glassMask) {
        int c = colorIndex < DEFAULT_COLOR || colorIndex > MAX_COLOR ? DEFAULT_COLOR : colorIndex;
        return new ElevatorStyle(c, glassMask & ALL_SIDES);
    }

    public boolean isDefaultColor() {
        return colorIndex == DEFAULT_COLOR;
    }

    /** Côtés vitrés réellement appliqués à cette empreinte : jamais le côté de la porte. */
    public int effectiveGlass(CabinFootprint fp) {
        return glassMask & ~CabinWalls.doorSide(fp);
    }
}
