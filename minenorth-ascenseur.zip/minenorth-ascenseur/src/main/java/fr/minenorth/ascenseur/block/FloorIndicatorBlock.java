package fr.minenorth.ascenseur.block;

import fr.minenorth.ascenseur.cabin.ElevatorBlocks;
import fr.minenorth.ascenseur.model.DoorGeometry;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Afficheur d'étage : panneau sombre posé par un OP au-dessus d'une ouverture de palier. Il montre
 * l'étage actuel de la cabine et son sens de marche (un tiret si l'ascenseur est indisponible).
 * {@code FACING} : comme pour les portes, le côté de la case où le panneau est plaqué (vers la
 * cabine) ; l'écran regarde le palier. Le retirer ne touche jamais à l'ascenseur.
 */
public class FloorIndicatorBlock extends BaseEntityBlock {
    public static final DirectionProperty FACING = HorizontalDirectionalBlock.FACING;

    private static final VoxelShape[] SHAPES = new VoxelShape[4];

    static {
        for (Direction d : Direction.Plane.HORIZONTAL) {
            int[] r = DoorGeometry.panelRectPx(d.getStepX(), d.getStepZ());
            // Panneau de 14 x 10 px centré sur le côté.
            boolean alongX = r[2] - r[0] == 16;
            int x0 = alongX ? 1 : r[0];
            int x1 = alongX ? 15 : r[2];
            int z0 = alongX ? r[1] : 1;
            int z1 = alongX ? r[3] : 15;
            SHAPES[d.get2DDataValue()] = Block.box(x0, 3, z0, x1, 13, z1);
        }
    }

    public FloorIndicatorBlock() {
        super(Properties.of().mapColor(MapColor.METAL).strength(3.0f).noOcclusion()
                .forceSolidOn() // jamais remplacé par un liquide
                .pushReaction(PushReaction.BLOCK)
                .lightLevel(s -> 4));
        registerDefaultState(stateDefinition.any().setValue(FACING, Direction.NORTH));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING);
    }

    @Override
    @Nullable
    public BlockState getStateForPlacement(BlockPlaceContext ctx) {
        if (!ElevatorBlocks.mayPlace(ctx.getPlayer())) {
            return null; // OP uniquement
        }
        return defaultBlockState().setValue(FACING, ctx.getHorizontalDirection());
    }

    /** Pose par un OP : liaison à la gaine (au-dessus d'une ouverture), panneau tourné vers la cabine. */
    @Override
    public void setPlacedBy(Level level, BlockPos pos, BlockState state, @Nullable LivingEntity placer, ItemStack stack) {
        super.setPlacedBy(level, pos, state, placer, stack);
        if (level instanceof ServerLevel server && placer instanceof ServerPlayer player && player.hasPermissions(2)) {
            ElevatorBlocks.linkPlacedIndicator(server, pos, player);
        }
    }

    /** OP accroupi, main vide : liaison manuelle à l'ascenseur le plus proche ; sinon rien. */
    @Override
    public net.minecraft.world.InteractionResult use(BlockState state, Level level, BlockPos pos,
                                                     net.minecraft.world.entity.player.Player player,
                                                     net.minecraft.world.InteractionHand hand,
                                                     net.minecraft.world.phys.BlockHitResult hit) {
        if (hand != net.minecraft.world.InteractionHand.MAIN_HAND || !ElevatorBlocks.isManualLinkGesture(player)) {
            return net.minecraft.world.InteractionResult.PASS;
        }
        if (level instanceof ServerLevel server && player instanceof ServerPlayer op) {
            ElevatorBlocks.manualLink(server, pos, op);
        }
        return net.minecraft.world.InteractionResult.sidedSuccess(level.isClientSide);
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return SHAPES[state.getValue(FACING).get2DDataValue()];
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new FloorIndicatorBlockEntity(pos, state);
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }
}
