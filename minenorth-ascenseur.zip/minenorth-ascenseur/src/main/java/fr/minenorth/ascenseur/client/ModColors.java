package fr.minenorth.ascenseur.client;

import fr.minenorth.ascenseur.MineNorthAscenseur;
import fr.minenorth.ascenseur.block.FloorDoorBlock;
import fr.minenorth.ascenseur.block.ModBlocks;
import net.minecraft.world.item.DyeColor;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterColorHandlersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Teinte des panneaux de porte d'étage selon la couleur de l'ascenseur (propriété « couleur »). */
@Mod.EventBusSubscriber(modid = MineNorthAscenseur.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ModColors {
    /** Teinte d'origine : gris clair, comme les vantaux de la cabine. */
    public static final int DEFAULT_TINT = 0x9C9C94;

    private ModColors() {
    }

    /** Teinte RVB d'une couleur de colorant (index 0 à 15), ou la teinte d'origine. */
    public static int tint(int color) {
        if (color < 0 || color > 15) {
            return DEFAULT_TINT;
        }
        float[] c = DyeColor.byId(color).getTextureDiffuseColors();
        return ((int) (c[0] * 255) << 16) | ((int) (c[1] * 255) << 8) | (int) (c[2] * 255);
    }

    @SubscribeEvent
    public static void blockColors(RegisterColorHandlersEvent.Block event) {
        event.register((state, level, pos, tintIndex) -> tint(state.getValue(FloorDoorBlock.COLOR)),
                ModBlocks.FLOOR_DOOR.get());
    }

    @SubscribeEvent
    public static void itemColors(RegisterColorHandlersEvent.Item event) {
        event.register((stack, tintIndex) -> DEFAULT_TINT, ModBlocks.FLOOR_DOOR_ITEM.get());
    }
}
