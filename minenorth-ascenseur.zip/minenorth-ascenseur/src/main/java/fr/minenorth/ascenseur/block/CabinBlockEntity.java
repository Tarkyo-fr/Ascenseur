package fr.minenorth.ascenseur.block;

import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/** Entité de bloc de la cabine ; {@code elevatorId} est nul tant que la cabine n'est pas liée à un ascenseur. */
public class CabinBlockEntity extends BlockEntity {
    private static final String TAG_ELEVATOR = "ElevatorId";

    @Nullable private UUID elevatorId;

    public CabinBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlocks.CABIN_BE.get(), pos, state);
    }

    @Nullable public UUID getElevatorId() { return elevatorId; }

    public void setElevatorId(@Nullable UUID id) {
        this.elevatorId = id;
        setChanged();
        if (level != null) level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        if (elevatorId != null) tag.putUUID(TAG_ELEVATOR, elevatorId);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        elevatorId = tag.hasUUID(TAG_ELEVATOR) ? tag.getUUID(TAG_ELEVATOR) : null;
    }

    @Override
    public CompoundTag getUpdateTag() {
        CompoundTag tag = super.getUpdateTag();
        saveAdditional(tag);
        return tag;
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }
}
