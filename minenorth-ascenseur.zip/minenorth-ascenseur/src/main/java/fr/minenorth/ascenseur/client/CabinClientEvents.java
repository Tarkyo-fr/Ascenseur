package fr.minenorth.ascenseur.client;

import fr.minenorth.ascenseur.MineNorthAscenseur;
import fr.minenorth.ascenseur.cabin.CabinEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityMountEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Remplace le message vanilla « Appuyez sur Maj pour descendre » quand le joueur devient passager
 * de la cabine : pendant un trajet, descendre n'est pas possible (le joueur est repris aussitôt).
 */
@Mod.EventBusSubscriber(modid = MineNorthAscenseur.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class CabinClientEvents {
    private static boolean replaceMountMessage;

    private CabinClientEvents() {
    }

    @SubscribeEvent
    public static void onMount(EntityMountEvent event) {
        if (event.isMounting()
                && event.getLevel().isClientSide()
                && event.getEntityBeingMounted() instanceof CabinEntity
                && event.getEntityMounting() == Minecraft.getInstance().player) {
            replaceMountMessage = true;
        }
    }

    /** Le message vanilla est posé juste après le montage : on le remplace au tick suivant. */
    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.START || !replaceMountMessage) {
            return;
        }
        replaceMountMessage = false;
        Minecraft.getInstance().gui.setOverlayMessage(Component.literal("Ascenseur en mouvement"), false);
    }
}
