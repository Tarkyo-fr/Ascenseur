package fr.minenorth.ascenseur.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Deterministic, tick-driven trip state machine of one elevator cabin.
 *
 * <p>Phases: {@code IDLE -> DOORS_CLOSING (doorTicks) -> MOVING -> DOORS_OPENING (doorTicks) -> IDLE}.
 * Back in {@code IDLE} with calls queued, the cabin dwells {@code doorTicks} ticks (so riders can
 * {@link #select(int)}) before departing; a selected destination departs on the next tick.
 * Floors are index-based: removing a middle floor retargets the indices.
 *
 * <p>Destination semantics: calls are queued in FIFO order (no duplicates). A destination chosen
 * with {@link #select(int)} (only possible while {@code IDLE}) is served before any queued call
 * from that IDLE state; the queue is then resumed in order. A call for the floor the cabin is
 * idle at (doors already open) is ignored, as is a call for the floor currently being served.
 * While moving, {@link #currentFloor()} stays the floor the cabin left, and it becomes the
 * target on arrival. {@link #targetFloor()} is kept until the cabin is back to {@code IDLE}.
 *
 * <p>Pure Java; uses only integer/double arithmetic so results are exact.
 */
public final class TripController {
    public enum Phase { IDLE, DOORS_CLOSING, MOVING, DOORS_OPENING }

    /** Result of {@link #obstructed()}. */
    public enum Obstruction {
        /** Not moving: nothing to do. */
        NONE,
        /** The trip is aborted: the cabin now goes back to the floor it left. */
        REVERSED,
        /** Already going back and blocked again: the cabin holds still for this tick. */
        HELD
    }

    /** Returned by {@link #leadingLayer} when the cabin does not move. */
    public static final int NO_LAYER = Integer.MIN_VALUE;

    private final double blocksPerTick;
    private final int doorTicks;
    private int[] floorYs;
    private final List<Integer> queue = new ArrayList<>();
    private int selected = -1;
    private int current;
    private int target = -1;
    private Phase phase = Phase.IDLE;
    private int timer;
    private int dwell;
    private double y;
    /** Set by {@link #obstructed()} when already going back: the next tick does not move. */
    private boolean held;
    /** Door-sensor reopenings for the current departure. */
    private int reopens;

    public TripController(int[] floorYs, int startFloor, double blocksPerTick, int doorTicks) {
        if (floorYs == null || floorYs.length == 0) {
            throw new IllegalArgumentException("floorYs must not be empty");
        }
        if (startFloor < 0 || startFloor >= floorYs.length) {
            throw new IllegalArgumentException("invalid start floor " + startFloor);
        }
        if (!(blocksPerTick > 0)) {
            throw new IllegalArgumentException("blocksPerTick must be > 0");
        }
        if (doorTicks < 0) {
            throw new IllegalArgumentException("doorTicks must be >= 0");
        }
        this.floorYs = floorYs.clone();
        this.blocksPerTick = blocksPerTick;
        this.doorTicks = doorTicks;
        this.current = startFloor;
        this.y = this.floorYs[startFloor];
    }

    private boolean valid(int floor) {
        return floor >= 0 && floor < floorYs.length;
    }

    public double blocksPerTick() {
        return blocksPerTick;
    }

    /** Queues a call; ignored if the cabin is idle (doors open) at that floor. */
    public void call(int floor) {
        if (!valid(floor)) {
            return;
        }
        if (phase == Phase.IDLE && floor == current) {
            return; // doors already open: no reopening, no longer dwell (no "hostage" cabin)
        }
        if (floor == target || queue.contains(floor)) {
            return;
        }
        queue.add(floor);
    }

    /**
     * Registers a destination; accepted while IDLE or while the doors are opening (it is then served
     * once IDLE), for an existing floor. The current floor is a no-op (the doors are open).
     */
    public boolean select(int floor) {
        if (!acceptsSelection() || !valid(floor)) {
            return false;
        }
        if (floor == current) {
            return true;
        }
        selected = floor;
        return true;
    }

    /** True while a destination can be selected: IDLE, or doors opening at a floor. */
    public boolean acceptsSelection() {
        return phase == Phase.IDLE || phase == Phase.DOORS_OPENING;
    }

    /** Maximum reopenings by the door sensor for one departure. */
    public static final int MAX_DOOR_REOPENS = 3;

    /**
     * Door sensor: someone stands in the doorway while the doors close. The doors reopen (the
     * destination is kept and served right after), at most {@code MAX_DOOR_REOPENS} times per
     * departure so the queue can never be blocked. Returns false once that budget is spent or when
     * the doors are not closing.
     */
    public boolean doorObstructed() {
        if (phase != Phase.DOORS_CLOSING || reopens >= MAX_DOOR_REOPENS) {
            return false;
        }
        reopens++;
        if (target != -1 && target != current && selected == -1) {
            selected = target;
        }
        target = current;
        phase = Phase.DOORS_OPENING;
        timer = doorTicks;
        return true;
    }

    public void tick() {
        switch (phase) {
            case IDLE -> startNextTrip();
            case DOORS_CLOSING -> {
                if (--timer <= 0) {
                    phase = Phase.MOVING;
                    reopens = 0;
                }
            }
            case MOVING -> {
                if (held) {
                    held = false;
                } else {
                    move();
                }
            }
            case DOORS_OPENING -> {
                if (--timer <= 0) {
                    phase = Phase.IDLE;
                    dwell = doorTicks;
                    target = -1;
                }
            }
        }
    }

    private void startNextTrip() {
        if (dwell > 0) {
            dwell--; // counts down even with no call: a later call does not wait any longer
            if (selected == -1 && !queue.isEmpty()) {
                return;
            }
        }
        int next = -1;
        if (selected != -1) {
            next = selected;
            selected = -1;
            queue.remove(Integer.valueOf(next));
        } else if (!queue.isEmpty()) {
            next = queue.remove(0);
        }
        if (next == -1) {
            return;
        }
        target = next;
        if (next == current) {
            phase = Phase.DOORS_OPENING;
        } else {
            phase = Phase.DOORS_CLOSING;
        }
        timer = doorTicks;
    }

    private void move() {
        double goal = floorYs[target];
        double delta = goal - y;
        if (Math.abs(delta) <= blocksPerTick) {
            y = goal;
            current = target;
            phase = Phase.DOORS_OPENING;
            timer = doorTicks;
        } else {
            y += delta > 0 ? blocksPerTick : -blocksPerTick;
        }
    }

    /** Height the cabin will have after the next {@link #tick()} (same as {@link #y()} unless MOVING). */
    public double nextY() {
        if (phase != Phase.MOVING || held) {
            return y;
        }
        double delta = floorYs[target] - y;
        if (Math.abs(delta) <= blocksPerTick) {
            return floorYs[target];
        }
        return y + (delta > 0 ? blocksPerTick : -blocksPerTick);
    }

    /**
     * Block layer the cabin enters when it goes from {@code y} to {@code nextY}: the layer of its top
     * edge when going up (interior of {@code height} blocks), the layer of its floor when going down;
     * {@link #NO_LAYER} if it does not move. Only that layer has to be free of blocks.
     */
    public static int leadingLayer(double y, double nextY, int height) {
        if (nextY > y) {
            return (int) Math.ceil(nextY + height) - 1;
        }
        if (nextY < y) {
            return (int) Math.floor(nextY);
        }
        return NO_LAYER;
    }

    /**
     * The shaft ahead is blocked (to be reported before {@link #tick()}). While going to a
     * destination, the trip is aborted and the cabin goes back to the floor it left (the destination
     * is dropped, other queued calls are kept). If it is already going back, it holds still during the
     * next tick and retries afterwards. Never moves the cabin by itself.
     */
    public Obstruction obstructed() {
        if (phase != Phase.MOVING) {
            return Obstruction.NONE;
        }
        if (target != current) {
            target = current;
            return Obstruction.REVERSED;
        }
        held = true;
        return Obstruction.HELD;
    }

    public Phase phase() {
        return phase;
    }

    public int currentFloor() {
        return current;
    }

    /** Floor being served, or -1 when there is none. */
    /**
     * True while the floor is being served for a call or a selection: queued, selected, or the target
     * of the current trip until the doors have opened there (lit call button).
     */
    public boolean isServing(int floor) {
        return queue.contains(floor) || selected == floor || (target == floor && phase != Phase.IDLE);
    }

    /** Travel direction: {@link FloorIndicator#UP}, {@link FloorIndicator#DOWN} or NONE. */
    public int direction() {
        return phase == Phase.MOVING ? FloorIndicator.direction(phase, y, floorYs[target]) : FloorIndicator.NONE;
    }

    public int targetFloor() {
        return target;
    }

    public double y() {
        return y;
    }

    /**
     * True while a destination chosen with {@link #select(int)} has not been taken into account yet
     * (it is consumed on the next {@link #tick()}). Callers use it so that two selections arriving in
     * the same tick do not both win: the first one is kept, later ones are rejected.
     */
    public boolean hasPendingSelection() {
        return selected != -1;
    }

    /**
     * Replaces the floor heights. Queued and selected floors that no longer exist are dropped.
     * If the cabin's current or target floor vanished, the trip is aborted and the cabin snaps
     * to the nearest remaining floor (IDLE).
     */
    public void updateFloors(int[] newFloorYs) {
        if (newFloorYs == null || newFloorYs.length == 0) {
            throw new IllegalArgumentException("floorYs must not be empty");
        }
        this.floorYs = newFloorYs.clone();
        held = false;
        queue.removeIf(f -> !valid(f));
        if (selected != -1 && !valid(selected)) {
            selected = -1;
        }
        if (!valid(current) || (target != -1 && !valid(target))) {
            current = nearest(y);
            target = -1;
            phase = Phase.IDLE;
            dwell = 0;
            y = floorYs[current];
        } else if (phase != Phase.MOVING) {
            y = floorYs[current];
        }
    }

    /**
     * Replaces the floor heights, matching floors by <em>height</em> instead of index (admin edit).
     * While {@code MOVING} this is the same as {@link #updateFloors(int[])}.
     *
     * <p>Otherwise: the cabin keeps its height if a floor still exists there (only its index may
     * change); queued calls, the pending selection and the door target are moved to the index of
     * the same height, or dropped if that height is gone. If the cabin's own floor is gone, it snaps
     * to the nearest remaining floor (IDLE, door target dropped).
     *
     * @return true if the cabin height changed (its floor no longer exists)
     */
    public boolean remapFloorsByHeight(int[] newFloorYs) {
        if (newFloorYs == null || newFloorYs.length == 0) {
            throw new IllegalArgumentException("floorYs must not be empty");
        }
        if (phase == Phase.MOVING) {
            double before = y;
            updateFloors(newFloorYs);
            return y != before && phase != Phase.MOVING;
        }
        int[] map = FloorRemap.byHeight(floorYs, newFloorYs);
        List<Integer> remapped = new ArrayList<>(queue.size());
        for (int f : queue) {
            int n = map[f];
            if (n != -1 && !remapped.contains(n)) {
                remapped.add(n);
            }
        }
        queue.clear();
        queue.addAll(remapped);
        selected = selected == -1 ? -1 : map[selected];
        int newTarget = target == -1 ? -1 : map[target];
        int newCurrent = map[current];
        double before = y;
        this.floorYs = newFloorYs.clone();
        if (newCurrent == -1) {
            current = FloorRemap.nearest(floorYs, before);
            target = -1;
            phase = Phase.IDLE;
            dwell = 0;
            timer = 0;
        } else {
            current = newCurrent;
            if (target != -1 && newTarget == -1) {
                target = -1;
                phase = Phase.IDLE;
                dwell = 0;
                timer = 0;
            } else {
                target = newTarget;
            }
        }
        y = floorYs[current];
        return y != before;
    }

    /** Snaps to the nearest floor, phase IDLE, queue cleared (e.g. after a server restart). */
    public void reset(double newY) {
        held = false;
        queue.clear();
        selected = -1;
        target = -1;
        phase = Phase.IDLE;
        dwell = 0;
        timer = 0;
        current = nearest(newY);
        y = floorYs[current];
    }

    private int nearest(double value) {
        int best = 0;
        double bestDist = Double.MAX_VALUE;
        for (int i = 0; i < floorYs.length; i++) {
            double d = Math.abs(floorYs[i] - value);
            if (d < bestDist) {
                bestDist = d;
                best = i;
            }
        }
        return best;
    }
}
