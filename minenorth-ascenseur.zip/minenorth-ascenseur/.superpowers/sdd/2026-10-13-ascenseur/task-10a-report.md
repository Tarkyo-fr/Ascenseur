# Task 10a: Mobile cabin and server service (report)

Status: DONE_WITH_CONCERNS (everything that could be compiled, unit-tested and booted headless was. Smoothness, rendering and anti-fly in real play have not been verified, see the last section).

## Commits (branch feature/ascenseur)
- `86998c3` feat: empreinte de cabine et sélection en attente du contrôleur
- `91ee49c` feat: cabine mobile et service d'ascenseur
- `8fb4adb` feat: rendu de la cabine et message de trajet

## Approach chosen (and why)

I read the vanilla 1.20.1 sources (`ServerGamePacketListenerImpl`, `Entity`, `LivingEntity`, `ServerPlayer`, `PlayerList`). Three facts drove the choice:

1. **Anti-fly.** `clientIsFloating` depends on `noBlocksAround(player)`, and that check looks only at **block states** (bbox inflated by 0.0625 and extended 0.55 downward, `allMatch(isAir)`). It ignores entities. The kick is skipped when `player.isPassenger()`. A player standing still on a collidable entity also gets `verticalCollisionBelow = false`, because the server move has dy = 0. So a "collidable entity surface" over an open shaft gets the player **kicked after 4 s** even when the cabin is stopped.
2. **Fall damage.** `LivingEntity.rideTick()` calls `resetFallDistance()` on every tick, and a passenger's moves never go through `doCheckFallDamage`.
3. **Disconnect.** `PlayerList.remove` deletes the root vehicle if the player is its only player passenger. It also saves `RootVehicle` in the player's data. `PlayerLoggedOutEvent` fires **before** that.

Chosen design (no mixin, no AT, no reflection):

- **Stopped cabin:** an invisible real-block floor, `CabinFloorBlock` (`minenorthascenseur:plancher_cabine`). There is one block under each cell of the footprint at `floorY - 1`, so its top is exactly at the floor height. It is only placed into **air**, and only **our** blocks are ever removed. It has an empty outline (cannot be targeted or broken), full collision, never suffocates, unbreakable in survival, no loot, no item. Because the player stands on a block, `noBlocksAround` is false: no kick and no collision jitter.
- **Moving:** every player whose feet are in the footprint becomes a **passenger** of `CabinEntity` (`startRiding(cabin, true)`; force bypasses the 3 s boarding cooldown). `positionRider` keeps each passenger's own X/Z, clamped inside the footprint with a 0.31 margin, and puts their feet on the floor. They are never in a shaft wall, never kicked, never take fall damage, and all of them travel together. Riders stand (`shouldRiderSit()=false`).
- **Packet ordering (avoids snapping and falling through blocks):**
  - START of tick: the controller advances.
  - On departure: boarding, which sends a teleport packet.
  - On arrival: the floor is **placed**.
  - Level tick: block and entity changes go out.
  - END of tick:
    - departure: the floor is **removed**, after the passengers packet has gone out;
    - arrival: passengers get off on the spot. I send `ClientboundSetPassengersPacket` myself, **then** `connection.teleport` to the exact position (vanilla `ServerPlayer.dismountTo` does not resync the client).
- **Shift during a trip:** vanilla dismounts the player (no event is cancelled). The END pass boards them again in the same tick. This is more robust than cancelling `EntityMountEvent`, which would block `/tp`, death, logout and teleports from other mods. On the client, the "press Shift to get off" message is replaced by "Ascenseur en mouvement" (`client/CabinClientEvents`).
- **Client smoothness:** `updateInterval(1)`. The client **predicts** the movement: target Y, speed and a "moving" flag are synced, the client applies the same `approach` as the server, and it resyncs to the server position if the drift exceeds max(1 block, 3 × speed). When not moving, it uses a boat-style lerp. The rider follows the cabin on the client through `positionRider`.
- **Disconnect:** in `PlayerLoggedOutEvent` the passenger is put down at the **destination floor** before vanilla can delete the cabin. The cabin is `noSave()`, so it is never duplicated through `RootVehicle`.
- **Safety net:** `LivingFallEvent` is cancelled for any ServerPlayer inside the column of an active shaft (footprint, from the lowest floor - 1 to the highest ceiling).

Rejected alternatives:
- Entity as a collidable surface: kick when stopped (see point 1), plus client/server collision jitter.
- Resetting `aboveGroundTickCount` through reflection or an AT/mixin: forbidden by the brief and fragile.
- Granting `mayfly`, levitation and similar: changes player abilities, which is abusable.
- Cancelling `EntityMountEvent` to lock riders in: breaks teleports and logout (vanilla would then delete the cabin).
- Saving the cabin entity in the world: duplicates on restart. Instead the service recreates it.

## What was created (names and signatures for 10b)

`model/` (pure Java, tested):
- `TripController.hasPendingSelection()`: true between `select()` and the next `tick()`. Tests: 3 new ones in `TripControllerTest`.
- `CabinFootprint.of(int anchorX, int anchorZ, CabinSize size, int facingX, int facingZ)`. Methods: `minX/maxX/minZ/maxZ` (max exclusive), `spanX/spanZ`, `centerX/centerZ`, `cellX(across, back)`, `cellZ(across, back)`, `rightX/rightZ`, `containsXZ(x, z)`, `contains(x, y, z, floorY)` (tolerance -0.5 / +1.5), `clampX/clampZ(v, margin)`, `static clampInside(...)`. Constants: `INTERIOR_HEIGHT = 3`, `FEET_BELOW`, `FEET_ABOVE`. Tests: `CabinFootprintTest` (11 tests, every size, 2×4 in all four orientations).
  - **Orientation convention (10b must follow it):**
    - `facing` = the direction the cabin door opens toward (from the cabin to the landing).
    - The anchor is the **front-left** cell when seen from inside, looking at the door; from the landing it is the front-right cell.
    - Width runs to the right of `facing` (clockwise: north becomes east).
    - Depth runs backward, away from the door.
    - For a 2×4, the door is on the 2-cell side. The landing cells in front of the door are `cell(a, -1)` for `a` in `[0, width)`.

`cabin/`:
- `CabinTuning.BLOCKS_PER_TICK` (0.2 = 4 b/s) and `CabinTuning.DOOR_TICKS` (40): the only constants Task 11 needs to move.
- `ModEntities.CABIN` (`minenorthascenseur:cabine`; noSave, noSummon, tracking range 10, updateInterval 1).
- `CabinEntity`:
  - Pickable, invulnerable, no physics, `blocksBuilding`.
  - Right-click: an OP who is sneaking gets the admin panel (even from outside); a player inside gets the floor panel (server-side check).
  - It discards itself if the service no longer owns it.
- `CabinFloorBlock`, registered in `ModBlocks.CABIN_FLOOR` (`plancher_cabine`), with blockstate, particle-only model and lang entry.
- `CabinStateData` (SavedData `minenorthascenseur_cabins`): resting Y per cabin. While a trip is running it holds the destination.
- `CabinEvents` (FORGE bus): ServerStarting/Stopped, ServerTick START/END, PlayerLoggedOut, LivingFall.
- `ElevatorService` (singleton `ElevatorService.current()`, `@Nullable`; it implements `ServerHooks.SelectionService` and is installed on start):
  - `boolean openPanel(ServerPlayer, UUID)`
  - `boolean openAdmin(ServerPlayer, UUID)` (OP only; works even if the elevator is not active)
  - `boolean handleCall(ServerPlayer, UUID, int floorIndex)`: index out of range gives `false`; a reserved floor gives `false` plus an action-bar message "Cet étage est réservé." (French, matching the mod's existing UI strings); otherwise `TripController.call`
  - `boolean isDoorOpenAt(UUID, int floorIndex)`: cabin stopped at that floor and phase IDLE or DOORS_OPENING. **Use it for floor doors.**
  - `static notifyElevatorUpdated(StoredElevator)`: already called by `AdminSavePacket` after `data.put`.
  - Selection hooks: `tripFor`, `isInsideCabin` (dimension + footprint at the current Y), `onFloorSelected` (rejects if `hasPendingSelection()`, so the first selection in a tick wins).
  - Automatic activation: every tick, for each `ElevatorData` entry whose `server.getLevel(dim) != null`. An elevator that disappears from data is deactivated: riders are put down at the nearest floor, the cabin and floor are removed, and its `CabinStateData` entry is deleted.
  - Changes to floors only: `TripController.updateFloors`. A geometry change (anchor, facing, size, dim): full deactivate and reactivate (at the saved floor).
  - The world side (cabin entity, floor blocks, riders) is only touched when the 4 corners of the footprint are `isPositionEntityTicking`. Block writes also check `isLoaded` per cell. No chunk is ever loaded synchronously. The controller keeps ticking without anyone nearby.
  - Boot recovery: `reset(saved resting Y, otherwise anchor Y)`. The first time the shaft is present, all stray floor blocks on every floor are cleaned up and the floor is placed at the current floor. The cabin is never between floors.

## Left for 10b

- **Wiring the blocks:**
  - `CabinBlock.use` → `openPanel`/`openAdmin`, and elevator creation on placement (no `StoredElevator` is created anywhere yet).
  - `CallButtonBlock.use` → `handleCall`.
  - `FloorDoorBlock` → shape closed/open based on `isDoorOpenAt`.
  - The entity's right-click already works.
- **Anchor block conflict (important):** the CabinBlock is placed "on the ground at the starting floor", so it sits **inside** the cabin interior at floor 0 (the player's feet cell). As a full block it is an obstacle when the cabin is at floor 0. 10b must decide what happens to it: make it non-collidable or invisible once the elevator exists, or set the anchor elsewhere, etc.
- **Obstruction** (a block placed in the shaft): nothing is detected yet. The cabin passes through blocks (no physics), and riders could take suffocation damage if a block crosses their eyes. Spec: stop and return to the previous floor. Hook it in `applyTripState` (before advancing), for example by checking the cells ahead of the cabin during MOVING.
- Sizes 2×2, 2×4 and 4×4 are already supported by the service, the footprint, the entity (synced spans) and the renderer, but none was tested in game.
- Breaking or explosion protection for the mod's blocks, for non-OPs.

## Build / tests
- `./gradlew build`: BUILD SUCCESSFUL (only pre-existing deprecation warnings).
- `./gradlew test`: 66 tests, 0 failures (CabinFootprintTest 11, TripControllerTest 17, plus the earlier tests).
- `./gradlew runServer` (headless, existing dev world): `Done (19.292s)`, no ERROR in latest.log or debug.log. The service ticked for about 5 min, including an autosave. The server was killed afterwards (stdin `stop` is not forwarded by the run task). There are no elevators in that world, so the trip path was **not** exercised.

## Unverified / residual risks
- **Not run in a client.** Unverified: visual smoothness (client prediction), cabin rendering (scaled vanilla blocks, lighting), the replaced overlay message, absence of jumps at arrival and departure, and the anti-fly behaviour in practice. The mechanism follows the vanilla code (passenger = never floating; real-block floor = `noBlocksAround` false), but nobody has tested it with a player.
- The relative order of the block, teleport and passenger packets assumes Netty sends them in the order they are queued. If it doesn't, the client may drop by about 0.08 for one tick: no damage (riding plus LivingFallEvent), but possibly visible.
- If another mod cancels `EntityMountEvent` or `EntityJoinLevelEvent` (protection mods), boarding or spawning the cabin fails. The player then falls into the shaft without damage (safety net), down to the cabin or the bottom.
- A player who logs back in after the cabin has left their destination floor reappears over the open shaft. They fall without damage until they reach the cabin or the bottom. Same for a crash mid-trip (the player position from the last autosave).
- Floor blocks are left behind if an elevator is deleted while its shaft chunks are not loaded, or if its size is changed in that state (edge case).
- While riding, players cannot walk around inside the cabin. They stand still in place until arrival (an accepted choice).
- The pickable cabin captures every click from players inside it (no block placing or breaking inside the cabin, and no hitting other players inside). This is intended, but 10b should know about it.

---

# Fix round 1 (commit `50f8d64` fix: montures, retrait d'ascenseur et réglage des étages en sécurité)

## CRITICAL 1: mounted players and other entities
- `boardPlayers`:
  - A player riding any vehicle that is not a cabin (horse, pig, strider…) is dismounted with `stopRiding()` **before** boarding.
  - The player is put back in place, inside the footprint and on the floor (`moveTo` + clamp), so they are not dropped "beside the mount" outside the shaft. Then they are boarded onto `CabinEntity`.
  - The footprint test uses the feet of the root vehicle, so a rider sitting high on a horse still counts.
  - If another mod refuses the dismount, the player is not forced on board.
  - The mount is no longer carrying the player, so its fall can no longer hurt them. Other entities are not transported.
- `CabinEvents.onFall`: `LivingFallEvent` is now cancelled for **any LivingEntity** (server side) in the column of a shaft (`isInShaft`). Mounts, animals and villagers land at the bottom unharmed.

## CRITICAL 2: deactivation and geometry change mid-trip
- `deactivate(a, successor, safeY)` replaces the old `deactivate`:
  - It collects riders (dismounted) and, if the cabin is stopped, players on foot in the footprint.
  - It discards the cabin and removes the floor.
  - With a **successor**, it places the successor's floor in the same call (`reconcilePlatform(fresh)`), **then** moves the players.
- Geometry refresh (`refresh`):
  - `activate(stored)` runs **first**, then `safeY = fresh floor` (the saved rest Y, i.e. the destination during a trip). Cabin and players end up on the same floor.
  - A player whose position is still inside the new footprint is placed there, on the floor. The others go onto the landing in front of the door.
  - Removing and placing the floor happen in the same call, so there is a single block update and no gap of 1-2 ticks.
- `landingSpot`:
  - Checks the row at two cells in front of the door first (`cell(a, -2)`; the row just in front, `-1`, is assumed to hold the floor door), then `cell(a, -1)`.
  - Picks the cell closest to the player that is free (`noCollision`) and has a solid floor underneath.
  - Fallback: centre of the nearest `cell(a, -2)` cell. Never in the shaft.
- `relocate(...)`: `moveTo` + `resetFallDistance` + immediate teleport (the server then ignores the client's moves until the ack), **then** a second teleport at END of tick, after the block changes have gone out (`pendingTeleports`).
- **New public method for 10b: `ElevatorService.release(UUID elevatorId)`.**
  - Riders and players on foot are put on the **landing** of the nearest floor (never in the shaft); cabin and floor are removed; the saved rest Y is forgotten.
  - Call it **after** removing the elevator from `ElevatorData`, otherwise it is reactivated on the next tick.
  - The tick sweep (elevator gone from the data, dimension unloaded) uses the same landing path.

## IMPORTANT 3: floors-only admin save while stopped
- New pure class `model/FloorRemap` (`byHeight(oldYs, newYs)`, `indexOf`, `nearest`).
- `TripController.remapFloorsByHeight(int[])`, whose Javadoc describes the behaviour; `updateFloors` (index-based) is still used while MOVING:
  - The cabin keeps its height if that floor still exists; only its index changes.
  - Queued calls, the pending selection and the door target follow their height, or are dropped if that height disappeared.
  - If the cabin's own floor disappeared, it snaps to the nearest floor (IDLE) and the method returns `true`.
- Service (`refresh`, floors only): if stopped and the cabin's height had to change, players on foot are captured first, `reconcilePlatform` places the new floor (and removes the old one), **then** those players are moved to the new Y (`relocate`, same X/Z).

## Minors
- Minor 4: logout with a cabin outside `active`: falls back to the last known floor (`CabinStateData.restY`), otherwise the player is not moved (only `stopRiding`).
- Minor 7: `CabinFootprintTest` has cells for 4×4 facing WEST and 2×2 facing SOUTH, and an exclusive-edge test for `containsXZ`.
- Minors 5 and 6: not done (as instructed).

## Tests / build
- New tests:
  - `FloorRemapTest` (4).
  - `TripControllerTest`, 5 tests for `remapFloorsByHeight`: lower floor removed keeps the height; call to a removed height dropped; own floor removed goes to the nearest one; pending selection follows its height; doors closing toward a vanished floor goes back to IDLE.
  - `CabinFootprintTest`: 3 tests.
- `./gradlew build --offline` (includes `test`): BUILD SUCCESSFUL, **78 tests, 0 failures, 0 errors** (pre-existing deprecation warnings only).
- `runServer` not re-run: no registry or resource changed in this round, only server logic.

## Still unverified
- Everything in game: dismounting from a horse at departure, the mount falling without damage, the `release` and geometry-change paths with real players, the landing choice (it depends on where 10b puts the floor door: assumed in the row just in front of the cabin, `cell(a, -1)`), and the ordering of the double teleport against block updates.
- If the landing in front of the door is entirely blocked or has no floor on every candidate cell, the fallback still places the player on cell `-2` without checking it (outside the shaft, but possibly inside a block).
