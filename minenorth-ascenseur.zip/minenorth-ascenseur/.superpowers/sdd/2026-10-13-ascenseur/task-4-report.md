# Task 4 report

Created in src/main/java/fr/minenorth/ascenseur/compat/: SecoursCompat, MairieCompat, EntrepriseCompat, ServerRoles, Permissions.

- MairieCompat, EntrepriseCompat: copied from Portes, package changed only (reflection, ModList.isLoaded guard, Throwable -> false/empty).
- SecoursCompat: Portes' current SecoursCompat uses MineNorth.secours() (API, no reflection), not SecoursApi reflection; I followed Portes (same as brief "copy"), wrapped in try/catch Throwable.
- Permissions: @Mod.EventBusSubscriber (default FORGE bus, as Portes), 4 nodes under minenorthascenseur, default player != null && hasPermissions(2); hasNode true for OPs, node value otherwise, false if unknown/throws.
- ServerRoles: as specified; isPolice via MineNorth.police() in try/catch.

Build: ./gradlew build test -> BUILD SUCCESSFUL (tests green).
Runtime: not verified at runtime (runServer needs a joined player to exercise ServerRoles; not practical headless). No temporary code added.
Concerns: none beyond the SecoursCompat note above.
