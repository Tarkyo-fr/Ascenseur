# Task 6 report

RED: `./gradlew test --tests '*PanelBuilderTest' --tests '*ElevatorRulesTest'` -> compileTestJava failed (classes absent). After implementing, one real failure: cannotSelectWhileMoving (select() only stores the choice; a tick is required to leave IDLE). Test fixed with t.tick().
GREEN: same command -> BUILD SUCCESSFUL; full `./gradlew test` -> BUILD SUCCESSFUL.

Files: model/FloorView.java, PanelBuilder.java, ElevatorRules.java; tests PanelBuilderTest, ElevatorRulesTest.

Concerns: tooltip uses the 0-based index field as given (floor "Garde à vue" at index 2 shows "2 · ..."); the brief example "3 ·" implies display may be index+1 by the caller; FloorView.tooltip() prints `index` verbatim as decided by controller.
