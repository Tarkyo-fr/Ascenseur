# Task 11 + 12 report

## Done
- `ElevatorProtection`: non-OP BreakEvent cancelled for cabin/call button/floor door (action bar "§cCet ascenseur est protégé."); ExplosionEvent.Detonate spares the three blocks + CabinFloorBlock. Pistons: all four blocks already have PushReaction.BLOCK (verified), no event needed. OP path untouched: BreakEvent not cancelled -> CabinBlock.onRemove -> ElevatorBlocks.removeElevatorAt (data first, then release).
- `/ascenseur list|remove <nom>|reload` (level 2), `command/AscenseurCommands`. remove uses pure `model/ElevatorNameMatcher` (id prefix >=4 hex, then exact name, then contains; ambiguous -> lists names with short ids). Removes from ElevatorData first then `release(id, stored)`. `ElevatorService.isActive(UUID)` added for list.
- `config/AscenseurSettings` (pure parse + clamp) and `config/AscenseurConfig` (file IO, creates `config/Minenorth-ascenseur/ascenseur.toml`, loaded in the mod constructor and on reload). `CabinTuning` is now method-based (blocksPerTick(), doorTicks()) fed by the config.
- Reload decision: applies to elevators activated afterwards (TripController fields are final). To avoid client/server speed mismatch for running trips, the synced speed now comes from `a.trip.blocksPerTick()` (new getter) instead of the global. Documented in the toml header, command message and README.
- README.md (French) with all requested sections.

## Tests
- `./gradlew build --offline`: BUILD SUCCESSFUL, 101 tests, 0 failures (8 new: AscenseurSettingsTest 4, ElevatorNameMatcherTest 4).
- `./gradlew runServer --offline` headless: "Done (26.987s)", no mod error; ascenseur.toml created in run/config; process killed by timeout.

## Unverified
- Nothing exercised in a client or with a real elevator: break protection, explosions, command output formatting, reload effect.
- TNT/piston behaviour relies on PushReaction.BLOCK and the event, not tested in game.
- `remove` leaves a placed console block in the world (it has no elevator anymore, "non reliée"); stated in the command message.
