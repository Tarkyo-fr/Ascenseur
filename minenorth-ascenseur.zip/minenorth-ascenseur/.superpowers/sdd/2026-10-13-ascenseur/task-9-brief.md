### Task 9 : Réseau et écrans

**Files :**
- Create : `network/ModNetwork.java`, `network/ElevatorPanelPacket.java`, `network/SelectFloorPacket.java`, `network/AdminPanelPacket.java`, `network/AdminSavePacket.java`
- Create : `client/MineNorthStyle.java`, `client/MineNorthButton.java` (copies de Portes, paquetage changé), `client/ElevatorPanelScreen.java`, `client/ElevatorAdminScreen.java`, `client/ClientNetworkHandler.java`
- Reference : `../minenorth-portes/.../network/ModNetwork.java`, `client/DoorPanelScreen.java`

**Interfaces :**
- Consumes : `FloorView` (Task 6), `Elevator`, `EntrepriseCompat.companies/grades` (Task 4).
- Produces :
  - `ElevatorPanelPacket(UUID elevatorId, String elevatorName, List<FloorView> floors)` (serveur → client).
  - `SelectFloorPacket(UUID elevatorId, int floorIndex)` (client → serveur) ; le serveur revalide tout via `ElevatorRules.canSelect`.
  - `AdminPanelPacket(Elevator-complet, List<String> companies)` (serveur → client, OP seulement) et `AdminSavePacket(UUID id, String name, String size, List<Floor> floors)` (client → serveur) ; le serveur exécute `Elevator.validate`, vérifie `hasPermissions(2)`, et renvoie le message d'erreur à l'écran.
- Écrans : `ElevatorPanelScreen` = colonne de boutons ronds du bas vers le haut, étage actuel mis en évidence, boutons interdits éteints, infobulle `FloorView.tooltip()` au survol. `ElevatorAdminScreen` = nom, taille, nombre d'étages, par étage : nom, hauteur (bouton « ma position = hauteur de l'étage » : `player.getBlockY()`), accès (liste Public / Police / Pompier-SAMU / Mairie / Entreprise + sélecteur d'entreprise et de grade), boutons « + Étage » et « Supprimer ».

- [ ] **Step 1 :** Implémenter paquets, `ModNetwork.register()` appelé depuis `MineNorthAscenseur`, et les deux écrans.
- [ ] **Step 2 :** `./gradlew build` ; attendu : `BUILD SUCCESSFUL`.
- [ ] **Step 3 :** Vérification manuelle `runClient` : ouvrir les deux écrans depuis une commande de test, tester le survol, la sauvegarde admin avec des données invalides (message d'erreur) et valides. Retirer la commande de test.
- [ ] **Step 4 :** Commit `feat: réseau et écrans joueur et admin`.

---

