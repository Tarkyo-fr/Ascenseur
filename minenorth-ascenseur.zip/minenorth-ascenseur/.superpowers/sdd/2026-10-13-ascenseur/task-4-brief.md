### Task 4 : Liens vers les autres mods et permissions Forge

**Files :**
- Create : `compat/SecoursCompat.java`, `compat/MairieCompat.java`, `compat/EntrepriseCompat.java`, `compat/ServerRoles.java`, `compat/Permissions.java`
- Reference : `../minenorth-portes/src/main/java/fr/minenorth/drill/door/{SecoursCompat,MairieCompat,EntrepriseCompat,PoliceCompat}.java`

**Interfaces :**
- Consumes : `Roles`, `FloorAccess` (Task 3).
- Produces :
  - `ServerRoles implements Roles`, `static ServerRoles of(ServerPlayer p)`.
  - `EntrepriseCompat.companies(MinecraftServer) -> List<String>` (`"id|nom"`), `grades(MinecraftServer, int id) -> List<String>`, `name(MinecraftServer, int id) -> String`.
  - `Permissions.hasNode(ServerPlayer p, String node) -> boolean` ; les quatre nœuds sont enregistrés sous `minenorthascenseur` via `PermissionGatherEvent.Nodes`, défaut = `p.hasPermissions(2)`, comme `OwnerDoorManager.gatherPermissions`.

- [ ] **Step 1 :** Copier les trois `*Compat` en changeant seulement le paquetage ; `ServerRoles` : `isPolice` = `MineNorth.police().isPolice(p)`, `isSecours` = `SecoursCompat.isSecours(p)`, `isMairie` = `MairieCompat.isStaff(p)`, `hasNode` = `Permissions.hasNode`, `entrepriseExists` = `!EntrepriseCompat.name(server, id).isBlank()`, `entrepriseCanOpen` = `EntrepriseCompat.canOpen`.
- [ ] **Step 2 :** `./gradlew build` ; attendu : `BUILD SUCCESSFUL`.
- [ ] **Step 3 :** Vérification manuelle : `./gradlew runServer` avec seulement l'API présente ; appeler `ServerRoles.of(p)` via une commande temporaire ou un log au join ; attendu : aucune exception, tous les rôles faux. Retirer le code temporaire.
- [ ] **Step 4 :** Commit `feat: liens rôles par réflexion et permissions`.

---

