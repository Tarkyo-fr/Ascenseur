# Task 10b: putting the elevator to use (report)

Status: DONE_WITH_CONCERNS. Everything compiles, the unit tests pass and the server boots headless. Nothing has been tested in a client.

## Commits (branch feature/ascenseur)
- `ad879f2` feat: liaison géométrique des portes et boutons, arrêt sur obstruction (pure model plus tests)
- `0a1e4df` feat: pose de la cabine, portes d'étage, boutons d'appel et obstruction de la gaine (Forge glue)

## Per item

1. **Creation and deletion** (`cabin/ElevatorBlocks`, `block/CabinBlock`)
   - `getStateForPlacement` returns `null` for a non-OP, so nothing is placed and no item is consumed. The non-OP gets an action-bar message.
   - It also refuses on the server when an elevator already uses that anchor, or when y+4+3 is above the build limit.
   - `setPlacedBy` (OP only) creates the default elevator: "Ascenseur", size 1x1, facing = opposite of the player's horizontal facing (also stored as the block's `FACING`), floors "Étage 0" at y and "Étage 1" at y+4, both PUBLIC. It writes the id into the block entity. Nothing opens.
   - Deletion is in `onRemove`, which covers any removal (break, explosion, /setblock), so no elevator is left without its block. It removes the entry from `ElevatorData` first, then calls `ElevatorService.release(id, removed)`.
   - Lookups use `atAnchor(dim, pos)` rather than the block-entity id. This is more robust: the id could have been copied by Ctrl+pick block.
   - Pistons cannot move the block (`PushReaction.BLOCK`).
2. **Console** (`CabinBlock`)
   - Uses `noCollission()` and an empty collision shape.
   - The outline is a small 2×6×6 px panel against the left wall, near the door. It is rotated by `FACING` (4 VoxelShapes, and the blockstate uses y rotations).
   - Model: iron with a black screen. The inventory item stays a cube.
   - The obstruction scan also ignores it.
3. **Interactions**
   - Cabin block: right-click opens `openPanel`; an OP who is sneaking gets `openAdmin`. With no elevator, or an inactive one: action-bar message.
   - Call button: `handleCall`.
     - Unlinked button, or a link to a missing elevator or floor: "Ce bouton n'est relié à aucun ascenseur."
     - Restricted floor: "Cet étage est réservé." (inert).
     - Success: "Ascenseur appelé."
   - Floor door: if unlinked, says so; if closed, tells the player to use the call button.
4. **Linking** (`model/FloorLinking`, 9 tests)
   - Door rule: the door's X/Z is in the landing row `cell(a,-1)`.
   - Height rule: **deviation from the brief** (which asked for y == floor y). A door links when `floorY <= y < floorY+3`, so doors can be stacked to close the whole opening; the brief's exact-height rule is a subset of this. When floors are less than 3 blocks apart, the higher floor wins.
   - Button rule: it copies the nearest linked door within 2 cells horizontally, with the door at the same height or up to 2 blocks lower. **Deviation:** the brief asked for the same height; a button at eye level next to a door on the ground is the normal case. If no door matches, the door rule applies.
   - The OP placing the block gets an action-bar message saying what it was linked to, or why it was not.
   - `ElevatorService.relink(id)` and `relink(id, previous)` are called from `AdminSavePacket` after `notifyElevatorUpdated`. They scan the old and new footprints plus 3 cells around them, over the openings of the old and new floors, in loaded chunks only:
     - Doors are re-resolved by their own Y. A door that is no longer in front of the cabin is unlinked; an unlinked door that is well placed gets linked.
     - Buttons take the nearest door's link, otherwise their own height (index -1 if that floor no longer exists).
     - The door states are then swept again.
5. **Floor doors** (`FloorDoorBlock.OPEN`)
   - Closed: collision is 1.5 blocks tall (cannot be jumped over); outline is the full panel.
   - Open: no collision; outline is the two side jambs. There is a dedicated `porte_etage_ouverte` model.
   - Doors never cause suffocation and cannot be pushed.
   - `ElevatorService.reconcileDoors` runs every tick but is cheap: it acts only when the open floor changes. The open floor is the cabin's floor during IDLE or DOORS_OPENING; it is closed from DOORS_CLOSING onward.
   - A door opens only if its block entity is linked to this elevator **and** to that floor.
   - Full sweep in these cases: activation and restart, the shaft becoming present again, a floor change, and relink.
   - On deactivate, release, or a size change: every door is closed **before** anyone is set down.
   - The shaft's presence check (chunk probes) now includes the landing row.
6. **Sizes:** 10a had already generalised the bounding box, `isInsideCabin`, the floor platform and `CabinRenderer` (spans and door side = facing = row -1 side). I reviewed them and changed nothing. Linking, door states and the obstruction scan all use the `CabinFootprint` of the right size, and the tests cover a 2×4 facing east.
7. **Obstruction**
   - `TripController` gains:
     - `nextY()`
     - `static leadingLayer(y, nextY, height)` (top edge when going up, floor when going down)
     - `obstructed()`, which returns:
       - `REVERSED`: target = origin floor; the destination is dropped and the queue is kept.
       - `HELD` (already on the way back): no movement for one tick, then it retries.
       - `NONE` (not moving).
     - 6 new tests.
   - The service (`checkObstruction`, before `trip.tick()`) acts only while MOVING with the shaft present. It reads only the layer being entered, over the footprint: at most 16 `getBlockState` per moving cabin per tick.
   - It ignores air, our invisible floor, the console, and blocks with no collision.
   - REVERSED: riders get "Passage obstrué : retour à l'étage précédent." on the action bar, and the saved rest height becomes the origin floor.
   - If the way back is also blocked (HELD): riders are put down on the landing of the nearest floor (never in the shaft or a wall), and the cabin waits until the shaft is cleared.
8. **Carried items**
   - `landingSpot` was rewritten.
     - It tries the nearest floor first, then the others in order of distance.
     - Candidates: rows -1 to -3, one extra cell on each side, and dy from -1 to +1.
     - A candidate is accepted when:
       - two cells are free (no collision, no fluid, no fire);
       - the block below has collision with a full top;
       - it is not our invisible floor;
       - `noCollision` holds for the player's box.
     - Preference order: right height, then row -2, then closest to the player.
     - Fallback: the first free height up to 8 blocks above the landing, otherwise the centre of the landing.
   - Pending cleanup (`CabinStateData.pendingCleanups`, persisted):
     - Recorded when an elevator is removed or its footprint changes while its shaft is not loaded, including `release` of an elevator that was never activated (dimension not loaded).
     - Every 20 ticks, once all chunks of the old shaft and its landing row are loaded:
       - our floor blocks are removed from every old floor, except a floor in use by an active elevator. If an active elevator over those cells has not yet done its own cleanup, the work is postponed;
       - doors linked to that id are closed, except those in the current landing row if the elevator still exists.
     - It never runs while the list is empty.
   - `release(UUID)` semantics are unchanged, with an added overload `release(UUID, StoredElevator)`.

## Tests / build
- `./gradlew build --offline`: BUILD SUCCESSFUL. Only pre-existing deprecation warnings.
- Tests: **93 tests, 0 failures, 0 errors**. That includes `FloorLinkingTest` (9) and `TripControllerTest` (28, of which 6 are new).
- `./gradlew runServer --offline` (existing dev world, headless): `Done (18.282s)`, no ERROR line and no error from the mod. The process was killed afterwards. The world has no elevator, so no gameplay path was exercised.

## Unverified / residual risks
- **Nothing tested in a client.** That covers placement, models (console, open door), collision, messages, trips, obstruction and evacuation.
- When the cabin is at floor 0, the cabin entity (pickable) intercepts clicks on the console. The entity handles them (panel, or admin when an OP sneaks), so this is redundant but harmless.
- An OP sneaking while **holding an item** does not trigger the block's `use` (vanilla behaviour). Use an empty hand.
- A cabin held in both directions stays MOVING until someone clears the shaft. Calls pile up, and the evacuation is the only thing done in that state.
- The obstruction check is skipped while the shaft is not loaded (no world to read). A block placed while the shaft was unloaded is detected once the shaft is loaded again, at the next step.
- `relink` only sees loaded chunks. Doors in unloaded chunks keep their old link until the next admin save. After a size change, a door that was left open in an unloaded chunk is closed by the pending cleanup.
- `CabinBlock` now has a `FACING` property. Cabin blocks from earlier dev worlds come back as `north`, which is not a problem for an empty world.
- A stray door or button whose link points to a deleted elevator is treated as unlinked.
- Deviations from the brief (documented above): doors link over the whole opening height (y..y+2), and a button may sit up to 2 blocks above its door.

## In-game checklist for the recette (OP plus a non-OP)
1. A non-OP places a cabin: refused, with an action-bar message, and the item is kept.
2. An OP places a cabin while facing the shaft: message "Ascenseur créé". The console appears against the left wall and can be walked through. Sneak and right-click with an empty hand: the admin panel opens.
3. Placing a second cabin at the same spot (after /setblock) is refused.
4. Set 3 floors (0 / +4 / +8) in the admin panel. Place doors in the row in front of the cabin at each floor (stack 2 per opening): message "Porte reliée". Place a call button next to each door at eye level: message "Bouton relié".
5. A door at a floor without the cabin is closed: you cannot walk through or jump over it. A door at the cabin's floor is open.
6. A call button brings the cabin; the doors open on arrival and close before departure. Do a trip from 0 to 2 with 2 players: both arrive, with no damage and no kick.
7. A POLICE floor in the admin panel: its call button is inert for a player without the role ("Cet étage est réservé.").
8. Place a block in the shaft between two floors during a trip: message "Passage obstrué", return to the starting floor, nobody inside a block. Also block the way back: riders are set down on the landing.
9. Admin save that removes a floor which has a door: that door says "non reliée". Add the floor back and save: it is linked again.
10. Sizes 2x2, 2x4 and 4x4 in all four orientations: footprint, invisible floor, rendering, doors on the door side, and the landing row for linking.
11. Break the cabin block while players are inside: they are set down on the landing (not in the shaft), the doors close, and the invisible floor disappears.
12. Same as 11 with the shaft far away (chunks unloaded), then come back: no invisible floor left over and no door left open (cleanup within about 1 s).
13. `/stop` during a trip, then restart: the cabin is at a floor and the doors are consistent.

---

# Fix wave 1: the six problems seen in game

Commits:
- `fd9b5ad` feat: parois de cabine par case et cases d'ouverture de palier
- `511413c` fix: parois solides de la cabine et suppression en jeu par un OP
- `c2544de` fix: nouvel aspect de la cabine, console embarquée et repère d'ancre discret
- `cbf957d` fix: portes d'étage plaquées sur la façade, ouverture remplie en une pose
- `b37b881` docs: pose des portes d'étage et suppression en jeu

1. **Walking through the walls**
   - New block `CabinWallBlock` (`paroi_cabine`): invisible, no outline (cannot be targeted or copied), no item and no loot, `PushReaction.BLOCK`, never causes suffocation, explosions spare it.
   - Its collision is a 1/16 plate on each walled side of the cell, plus the ceiling in the top layer. The walled sides come from the pure function `model/CabinWalls.sides(fp, x, z)`: the footprint edges except the door side (5 tests).
   - `ElevatorService.setShell` places and removes these walls **in the same step** as the invisible floor. Same rules as the floor:
     - placed only into air, and only our own blocks are removed;
     - removed at departure, on release, on refresh and on boot;
     - the deferred cleanup of unloaded shafts covers them too.
   - The obstruction check ignores our own walls.
   - `RIDER_MARGIN` went from 0.31 to 0.37 (`CabinFootprint.RIDER_MARGIN`) so a player who is put back in place never overlaps a wall.
   - While moving: `CabinEntity.canBeCollidedWith()` returns `isMoving()`. Non-riders collide with the cabin box the way they would with a boat; riders do not (same vehicle).
   - In the anchor cell at floor 0, the plate takes the feet layer, so there is no wall there. The two layers above still stop any player (1.8 blocks tall).
2. **Console that stays at floor 0:** the console is now drawn by `CabinRenderer` (plate, lit screen, buttons) on the right-hand interior wall near the door, so it moves with the cabin. The `CabinBlock` is now a 1 px floor plate (smooth stone with an iron marker pointing to the door side), with no collision but still selectable.
3. **Look:** `CabinRenderer` was rewritten in a local frame (door at z = 0) and rotated to the door side, so it is the same at all four sizes.
   - Thin smooth-quartz walls, polished andesite floor, quartz ceiling with a sea-lantern ceiling light at full brightness.
   - Iron door frame and lintel.
   - **Two-leaf sliding door**, animated client-side by `CabinEntity.doorOpenness(partial)` (about 1 s).
   - Iron handrails along the back and side walls.
   - Plain concrete textures, so the walls no longer show a grid.
4. and 6. **Floor doors**
   - `FACING` now means "the side of the cell the panel is on".
   - Shape: a full-cell-width panel, 2 px thick, on that edge. When open, only a 1 px sill remains, so the door can still be targeted and broken.
   - When an OP places a door in the landing row of a cabin (at a floor's height), `ElevatorBlocks.linkPlacedDoor` fills **the whole opening**: `FloorLinking.openingCells` gives the cabin width × 3 high (tested).
     - The doors are linked and face the cabin, whatever way the player is looking, so they sit flush with the cabin's front.
     - Occupied cells are left alone, and the message says how many.
   - Breaking one door removes the whole opening (`removeOpening`, guarded against recursion). Non-OPs cannot break them (Task 11 protection).
5. **Deleting in game**
   - `CabinEntity.isAttackable()` is now true and `skipAttackInteraction` always returns true, so there is never any damage.
   - An OP in **creative and sneaking** who left-clicks the cabin runs `ElevatorBlocks.deleteElevator`: data is removed first, then `release`, then the plate is removed, and the action bar confirms.
   - A non-OP who is sneaking gets "§cCet ascenseur est protégé.".
   - A left-click without sneaking does nothing.
   - Breaking the plate as an OP also deletes the elevator; see C1 below for the path.

Unverified (no client): all of the rendering (rotation by side, door animation, lighting, how it looks at the 4 sizes), the wall collision as players feel it, the cabin's collision while moving for players outside, the left-click deletion, and filling and breaking an opening.

---

# Fix wave 2: whole-branch review

Commits:
- `c9ab100` fix: appel répété sans otage, choix pendant l'ouverture, capteur de porte et chevauchement de gaines (model plus tests)
- `a9c6f03` fix: ancre insensible aux liquides, suppression par chemins OP, limites et chevauchement des gaines
- `2c1a893` fix: personne coincé dans la gaine, capteur de porte, erreurs contenues et refus expliqués
- `913904c` docs: limites connues, nœuds de permission et liste de contrôle à jour

- **C1 (fluids, deletion):**
  - `forceSolidOn()` on the plate, the button, the floor door and the invisible walls (the invisible floor already has full collision).
  - `CabinBlock.onRemove` no longer deletes anything. Deletion goes only through:
    - an OP breaking the plate: `ElevatorProtection.onAnchorBroken`, at LOWEST priority and only if no other listener cancelled the break;
    - an OP's sneaking left-click in creative;
    - `/ascenseur remove`.
  - Any other removal (`/setblock`, another mod) leaves the elevator intact. Placing the plate again on the same anchor takes the elevator back ("Repère replacé").
- **C2 (stuck in the shaft):**
  - (a) `PlayerLoggedInEvent` queues a check 20 ticks later; it waits up to 20 s for the shaft to be present. A player in a shaft column who is not standing in the stopped cabin at its floor is put down on the landing of the nearest floor.
  - (b) Right-click on the cabin by a non-passenger:
    - inside the cabin: floor panel;
    - inside the shaft: `call(nearest floor)` with "Ascenseur appelé : il vient vous chercher.";
    - anywhere else: "Entrez dans la cabine pour choisir un étage.".
  - (c) Door sensor: during DOORS_CLOSING, a player whose box crosses the doorway strip (±0.3 around the cabin front plane, `CabinFootprint.doorway`, tested) makes the doors reopen via `TripController.doorObstructed()`.
    - The destination is kept and served right after.
    - At most `MAX_DOOR_REOPENS` = 3 times per departure.
    - After that, the player is put down on the landing.
- **I1:** `call(current)` while IDLE is a no-op (no reopening, no longer dwell). `select(current)` likewise. The dwell now counts down even with an empty queue. Tests: holding the button, dwell without calls.
- **I2:** the admin panel is sized from `width/height` (at most 440×330), with the number of visible rows computed from that. The list scrolls with the wheel, and Save/Close stay pinned at the bottom.
- **I3:** floor heights are checked on the server (`AdminSavePacket.placementError`: `min <= y` and `y + 3 <= max`) and on the client before sending.
- **I4:** `CabinFootprint.overlaps` (tested). Creating an elevator, or resizing one in admin, is refused if its footprint overlaps another shaft in the same dimension.
- **I5:** every per-elevator step of `tickStart`/`tickEnd`, plus the deferred tasks, is wrapped in try/catch. The error is logged at most once every 10 s per elevator and that elevator is skipped for the tick.
- **I7:**
  - A selection is accepted during DOORS_OPENING and served once IDLE (`acceptsSelection`, `ElevatorRules.canSelect`; tested).
  - A refused selection is explained on the action bar: "Entrez dans la cabine…", "Ascenseur en mouvement : choisissez au prochain arrêt.", "Cet étage est réservé.", "Un autre étage est déjà choisi.".
- **Minors:**
  - WARN logs for entries dropped by `ElevatorData.load` and `CabinStateData.load`.
  - Lava and fire count as obstructions, with a throttled INFO log naming the elevator and the position.
  - Placing a floor door or a call button is OP-only, with a message.
- **I8 and I9:** documented in the README (clicks captured by the cabin, carried players dismounted, permission nodes `minenorthascenseur.grade.*` separate from `minenorthportes.*`).

## Build and tests (after both waves)
- `./gradlew build --offline`: BUILD SUCCESSFUL. **115 tests, 0 failures, 0 errors.**
- Headless `runServer`: `Done (17.741s)`, no ERROR line and no missing model or registry. Killed afterwards.

## Unverified / residual risks
- Nothing has been run in a client.
- The cabin's collision while moving (`canBeCollidedWith`): a player inside the shaft above a rising cabin can end up inside its box. Vanilla does not push them out; they get free on the next stop.
- `forceSolidOn` also makes these blocks count in the MOTION_BLOCKING heightmap (rain, for example). That is a cosmetic effect.
- Placing the plate again only takes back an elevator whose anchor is exactly that position.
- The door sensor only sees players, not mobs.

## In-game checklist for the recette (waves 1 and 2)
1. Walls: stopped cabin, try to walk out through each wall at every size (1x1, 2x2, 2x4, 4x4, all four orientations). Blocked everywhere except the door side.
2. Console: the panel (screen and buttons) goes up and down with the cabin. At floor 0 there is only a small plate on the floor.
3. Look: from outside and from inside, the walls are light with no grid, there is a ceiling light, a handrail, and the two door leaves slide open on arrival and close before departure.
4. Floor doors: place a single door in front of the cabin at a floor. The whole opening (cabin width × 3) fills, flush with the cabin front, whatever way you were looking.
5. Two neighbouring placements line up. Breaking one door removes the whole opening.
6. Deletion:
   - creative OP, sneaking, left-click on the cabin: "Ascenseur … supprimé", players put down on the landing;
   - left-click without sneaking: nothing;
   - a non-OP who is sneaking: "Cet ascenseur est protégé.";
   - an OP breaking the plate: deleted.
7. Water or lava poured onto the plate, a button or an open door: the block stays and the elevator stays.
8. Log out in the stopped cabin, move the cabin away, log back in: you are put on the landing, not at the bottom of the shaft.
9. Stand in the doorway while it is closing: the doors reopen (up to 3 times), then you are moved onto the landing.
10. Hold right-click on the call button while the cabin is at that floor and another floor calls: the cabin leaves after its normal dwell.
11. Admin panel at GUI scale 4 (1920x1080): "Enregistrer" is visible, and the floor list scrolls.
12. Height out of bounds, or a resize that overlaps another shaft: refused, with a message in the admin panel.
13. Select during door opening: served. Select while moving: "Ascenseur en mouvement".
14. Lava or a fire block in the shaft during a trip: "Passage obstrué" and the cabin returns to the previous floor.

---

# Fix wave 3: "porte encore buggée" (screenshot 5.png)

Commit: `f2de990` fix: portes d'étage ouvertes sans barres en travers, seuil seulement en bas

**What I took from the image** (my interpretation, checked against the code):
- The cabin is seen from the landing, doors open.
- The grey horizontal bars crossing the opening sit in front of the cabin's frame posts. They are at about 1 and 2 blocks above the floor, plus a thin L shape at floor level at the bottom right.
- These heights and positions match the **1 px sills of the open floor doors** in the upper cells of the opening (floorY+1 and floorY+2). Since wave 1 the opening is filled 3 blocks high, and every open door kept its sill (`porte_etage_ouverte` model plus `OPEN_SILL` outline). That gave one horizontal bar per block of height, the full width of the cell, wider than the cabin's frame.
- The grey plate on the floor is the anchor marker. The white post on the right is the cabin's door frame.

**What I could not determine from the image:**
- The cabin size and facing (1x1 looks likely).
- Whether doors placed before wave 1 (the old `FACING` meaning) were in the world. The fix below corrects them anyway.
- Whether the user also saw a problem with the door **closed**. The image shows the open state.

**Code check (all four facings):**
- The blockstate rotations (y = 0, 90, 180, 270 for north, east, south, west) match the north model (panel at z 0..2) and the per-side VoxelShapes.
- The opening cells take the side facing the cabin (the opposite of the cabin's facing), which is the cabin's front plane.
- The cabin's two door leaves (`CabinRenderer`) slide along the width, in the cabin's front plane (at most 1.5/16 inside it). They use the same material as the floor doors (light grey concrete).
- This geometry is now pure code in `model/DoorGeometry`:
  - `panelSide`, `panelRectPx`, `isThreshold`, `rightLeafSlide`;
  - a table test over the 4 facings (side, rectangle, leaf slide);
  - a test that the panel's face lies exactly on the cabin front plane (`doorway(0)`) for all 4 facings.
- `FloorDoorBlock` builds its shapes from it.

**Fix:**
- New property `seuil` on the floor door. Only the bottom cell of an opening has `seuil=true`.
- An open door with `seuil=false` has no model (`porte_etage_vide`, particle only) and no outline, so the opening is clear. The bottom sill stays selectable for breaking (breaking it removes the whole opening).
- `linkPlacedDoor` sets `seuil` when the opening is filled.
- `applyDoors` puts **facing and sill** back in order on every opening and closing. Doors already in the world, including ones placed before wave 1, are corrected at the first door cycle.
- Closed: a full vertical light-grey panel flush with the cabin front, 3 blocks high across the cabin width.

**Build:** `./gradlew build --offline` passes, 118 tests, 0 failures, 0 errors. Headless `runServer`: `Done (22.228s)`, no error, killed afterwards.

**Still unverified:** the rendering in a client (models and rotations as displayed). The checklist item has a line added in the README (item 4).

---

# Feature wave 4

Commits:
- `2b2f346` fix: sol de cabine sans scintillement ni quadrillage, nouvelle taille 1x2
- `84fa52c` feat: style d'ascenseur, afficheur d'étage et état des boutons (modèle)
- `1250a0f` feat: couleur et côtés vitrés par ascenseur, étage affiché sur le panneau de la cabine
- `596317d` feat: boutons d'appel à voyant et afficheur d'étage
- `947277d` / `12903f5` docs: README (customisation, 1x2, display, call lights, checklist 16 to 20)

1. **Cabin floor (screenshot 6.webp, 2x2 cabin on the ground floor)**
   - Seen in the image: green, grass-like streaks and a 2×2 grid on the floor.
   - Found in the code:
     - The drawn floor had its top **exactly** at the floor height.
     - On the ground floor, the cell underneath is terrain (grass), not air, so the invisible floor is not placed there. The grass top face is at the same height, which caused z-fighting (the green streaks).
     - The grid came from the `polished_andesite` texture, which has a border and is repeated once per cell.
   - Fix:
     - The drawn floor is raised by 0.01 (`FLOOR_LIFT`).
     - Its texture is now uniform (`gray_concrete`).
     - The invisible blocks were already model-less (`RenderShape.INVISIBLE`, particle only) and were not the cause.
   - Inferred, not seen: that the z-fighting was with the grass block, based on the green colour and the ground floor. On the upper floors (invisible floor below) there was no visible face, so no conflict.
2. **Customisation**
   - `model/ElevatorStyle(colorIndex -1..15, glassMask 4 bits)`:
     - `validate` and `sanitize`;
     - `effectiveGlass(fp)` never includes the door side;
     - tests.
   - Storage: in `StoredElevator` (new component; the old constructor maps to the default style). NBT keys `Color`/`Glass`; an old save without them reads as `DEFAULT` (tested, along with a sanitize test).
   - Packets: `AdminPanelPacket` (+ color, glass, doorSide) and `AdminSavePacket` (+ color, glass), as bytes, masked on decode. The server validates (`ElevatorStyle.validate`) and returns the error to the screen.
   - Admin screen:
     - a "Couleur" row with 17 swatches (the original look plus the 16 dyes);
     - "Vitres" with N/E/S/O toggles, the door side disabled;
     - it sits under the name/size row, and the list starts lower. At GUI scale 4 (panel 440×262) there are 4 visible rows plus the scrollbar, with Save and Close still visible (a calculation, not seen in a client).
   - Synced to clients through `CabinEntity` (COLOR, GLASS, INDICATOR), sent only when they change.
   - Rendering:
     - walls, header and door leaves use `<dye>_concrete` (uniform texture);
     - glazed sides use `<dye>_stained_glass` (plain glass for the original look), drawn in the same plane;
     - the collision of the invisible walls is unchanged (solid).
   - Floor doors: a `couleur` property (0..16, 16 = original), with the panel faces tinted through `RegisterColorHandlersEvent` (`white_concrete` texture with a dye tint). The colour is reapplied on every open/close cycle and on the sweep after an admin save.
3. **1x2:** `CabinSize.S1X2(1, 2)` (width along the right axis = 1, depth = 2, so the door is on the short side). Everything was already generic (footprint, walls, landing row, opening, NBT and packets by string, the admin selector going through `values()`, spans in the renderer and the bounding box). `Size1x2Test` covers the 4 facings: bounds, landing row, opening and walls.
4. **Call button**
   - New housing model: case, iron bezel, central light; texture `redstone_lamp` when off and `redstone_lamp_on` when lit.
   - `LIT` property; when lit it gives light level 7.
   - Logic:
     - `TripController.isServing(floor)`: the floor is queued, selected, or the current target until the doors open, then the light goes out (tested).
     - The service compares a per-floor bitmask every tick, which is cheap.
     - It reads and writes the world only for the floors whose bit changed: buttons around the landing row, from the opening height up to 2 blocks above.
   - `handleCall` and the inert behaviour without the required role are unchanged.
5. **Floor display `afficheur_etage`**
   - Block, item, creative tab entry, lang « Afficheur d'étage », and a model with a black screen in an iron frame.
   - Placement is OP only. Protection (`ElevatorProtection.isModBlock`), `forceSolidOn`, `PushReaction.BLOCK`. Removing it never touches the elevator.
   - Linking: `FloorLinking.forIndicator`, on the landing row, 1 to 3 blocks above the top of an opening (tested). When placed, it is turned like the doors toward the cabin, with the screen facing the landing.
   - Display:
     - `model/FloorIndicator`: direction, text, and a compact value (pack/unpack), tested.
     - `TripController.direction()`.
     - Shows the floor closest to the cabin; « — » when the elevator is inactive or held in both directions.
   - Sync:
     - The value is stored in the block entity and sent through the vanilla block-entity update packet, only when it changes (`ElevatorService.reconcileSignals`).
     - Displays are found by a scan of the landing row only when the value changes.
     - When the elevator is removed, displays show « — » and the lights go off.
   - `FloorIndicatorRenderer` (BlockEntityRenderer) draws the text in amber at full brightness on the front face, using the vanilla font (arrows ↑/↓).
   - The same text is drawn on the control-panel screen inside the cabin (`CabinRenderer.drawLabel`).
   - Floor name instead of the number: not done (not trivial in this wave).

**Build:** `./gradlew build --offline` passes, **127 tests, 0 failures, 0 errors**. Headless `runServer`: `Done (22.444s)`, no error, killed afterwards.

**Unverified (no client):**
- All the rendering: tints, glass (render type and transparency), coloured concrete, the lit light, the display text and its orientation (rotation derived from the vanilla sign renderer's convention), the floor with no z-fighting.
- How the admin screen looks at GUI scale 4.
- Whether the font has the ↑/↓ glyphs (vanilla/unifont should).

**Residual risks:**
- Plain glass (`GLASS`) uses the cutout render type, so its block-texture frame shows on each cell (a window look).
- The floor-door item in the inventory is grey (default tint).
- Displays and buttons in chunks that are not loaded are put right when the shaft becomes present again (state reset).

**In-game checklist (wave 4):** README items 16 to 20 (floor with no streaks or grid, colour and glass, 1x2 in all 4 facings, button light, display plus the screen in the cabin).

---

# Follow-up: manual linking (screenshot 7.png)

Commit: `5d985be` feat: liaison manuelle d'un afficheur, bouton ou porte par un OP accroupi

- **Image:** the display shows « — » because it is not linked. It sits beside the cabin, not above a floor door, so the geometric rule did not apply.
- **Pure model:** `model/ManualLinking.pick` with 6 tests (nearest wins, 6-block vertical tolerance, tie goes to the lower floor, out of range, other dimension excluded, no floors).
  - It picks the nearest elevator in the same dimension, measured horizontally to the footprint rectangle, up to 24 blocks.
  - It then picks the floor whose height is closest to the block, up to 6 blocks away; on a tie the lower floor wins.
- **Gesture:** OP, sneaking, empty main hand, right-click on a display, a call button or a floor door (`ElevatorBlocks.isManualLinkGesture` / `manualLink`).
  - The block entity is overwritten and synced to clients.
  - Success: action-bar « §aLié à « nom » — étage n (nom) ».
  - Failure: « §cAucun ascenseur à moins de 24 blocs » or « §cAucun étage proche de cette hauteur ».
- **Behaviours left intact:**
  - Any other click on a button or door behaves as before (call, messages).
  - A non-OP, or an OP holding an item, gets the normal behaviour.
  - A non-OP clicking the display: nothing happens.
- **Display not linked:** shows « non lié » in small text.
- **Automatic linking:** unchanged.
- **Docs:** one paragraph in the README and checklist item 21.
- **Verification:**
  - Build passes, 133 tests, 0 failures.
  - Headless `runServer`: `Done (16.950s)`, killed afterwards.
  - Unverified in a client: the click and the rendering of « non lié ».
