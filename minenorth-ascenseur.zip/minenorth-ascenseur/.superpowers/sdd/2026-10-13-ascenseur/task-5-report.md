# Task 5 report : TripController

## RED
`./gradlew test --tests '*TripControllerTest'` -> `Execution failed for task ':compileTestJava'` (TripController missing), BUILD FAILED.

## GREEN
Same command after implementation -> BUILD SUCCESSFUL (11 tests). Full `./gradlew test` -> BUILD SUCCESSFUL.

## Files
- src/main/java/fr/minenorth/ascenseur/model/TripController.java
- src/test/java/fr/minenorth/ascenseur/model/TripControllerTest.java

## Semantic choices
- `select` destination is served before queued calls from IDLE (documented in Javadoc); it is picked up on the next tick, removed from the queue if duplicated.
- `select`/`call` for the current floor while IDLE reopens doors (DOORS_OPENING immediately, target = current).
- From IDLE the next trip starts on the tick after IDLE is reached (IDLE observable for one tick between queued trips).
- Door phases: tick that starts the trip enters DOORS_CLOSING with timer=doorTicks; each tick decrements; at 0 -> MOVING. Same for opening -> IDLE.
- currentFloor stays the departure floor while moving; targetFloor kept until back to IDLE (call for the target floor is ignored).
- Invalid floors in call are ignored. Constructor validates args.
- updateFloors: drops invalid queued/selected floors; if current or target floor vanished, trip aborted, snapped to nearest floor, IDLE (remaining queue kept); otherwise y re-synced when not MOVING.

## Concerns
None blocking. Extra tests added beyond the brief (phase cycle, selected-before-queue, aborted trip).

## Fix round 1
Change: dwell. After DOORS_OPENING -> IDLE, `dwell = doorTicks`; in IDLE, queued calls (with no selection) wait `dwell` ticks before departing; select() is accepted throughout and a selected floor departs on the next tick, ahead of the queue. Dwell restarts after every trip; reset()/aborting updateFloors set dwell 0. Javadoc updated (dwell, index-based floors).
Tests: new `selectAcceptedDuringDwellWithQueuedCalls`, `queuedCallWaitsDwellBeforeDeparting`, `resetWhileMoving`; `floorRemovedWhileHeadingThereAbortsTrip` pinned (floor 0, y 64, queue survives -> floor 1, y 70). Test helper `runToIdle` now waits for a trip to start then finish (needed because IDLE persists during dwell).
RED: `./gradlew test --tests '*TripControllerTest'` -> 14 tests completed, 2 failed (the two dwell tests).
GREEN: same command -> BUILD SUCCESSFUL (14 tests); full `./gradlew test` -> BUILD SUCCESSFUL.
