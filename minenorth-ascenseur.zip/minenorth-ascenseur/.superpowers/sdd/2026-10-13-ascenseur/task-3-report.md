# Task 3 report

## RED
Command: ./gradlew test --tests '*FloorAccessTest' (FloorAccess.java absent)
Result: > Execution failed for task :compileTestJava. Compilation failed; BUILD FAILED in 3s

## GREEN
Same command: BUILD SUCCESSFUL (11 tests, 0 failures). Full ./gradlew test: BUILD SUCCESSFUL, 19 tests total (1+7+11), 0 failures.

## Files
- src/main/java/fr/minenorth/ascenseur/model/Roles.java
- src/main/java/fr/minenorth/ascenseur/model/FloorAccess.java
- src/test/java/fr/minenorth/ascenseur/model/FloorAccessTest.java

## Concerns
- "entreprise:3" (no grade) is Unknown per the brief, whereas Portes falls back to grade 99; id<=0 is also Unknown (Portes linked() requires id>0).
- Grade clamped to -1..99 at parse time, so format() of an out-of-range value normalises.
- Unknown.format() returns the raw string so unrecognised values are preserved on save.
