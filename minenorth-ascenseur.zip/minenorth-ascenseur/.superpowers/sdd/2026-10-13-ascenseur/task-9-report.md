# Task 9 report : Réseau et écrans

Status: DONE_WITH_CONCERNS

## Done
- network: ModNetwork (channel minenorthascenseur:network, PROTOCOL "1", register() called from MineNorthAscenseur constructor), ElevatorPanelPacket, SelectFloorPacket, AdminPanelPacket, AdminSavePacket, ServerHooks.
- client: MineNorthStyle and MineNorthButton (copied, package/MOD_ID changed; logo drawn only if texture exists, cached check), ElevatorPanelScreen, ElevatorAdminScreen, ClientNetworkHandler.
- Helpers for Task 10: ModNetwork.sendPanel(ServerPlayer, Elevator, currentFloor) and ModNetwork.sendAdminPanel(ServerPlayer, Elevator, error).

## Hooks Task 10 must implement
`fr.minenorth.ascenseur.network.ServerHooks.SelectionService` (install with `ServerHooks.setSelectionService(...)`):
- `Optional<TripController> tripFor(UUID elevatorId)`
- `boolean isInsideCabin(ServerPlayer, StoredElevator)`
- `void onFloorSelected(ServerPlayer, StoredElevator, int floorIndex)` (called only after ElevatorRules.canSelect passed)
Default implementation denies everything (tripFor empty), so no floor can be selected until installed.

## Behaviour
- SelectFloorPacket handler: elevator lookup in ElevatorData, then hooks, then ElevatorRules.canSelect with ServerRoles. Client never trusted.
- AdminSavePacket: hasPermissions(2), unknown id ignored, Elevator.validate; on error replies AdminPanelPacket with the submitted values + error; on success replaces elevator keeping dim/anchor/facing, replies with AdminPanelPacket (error empty, client shows "Enregistré.").
- Access strings: PUBLIC, POLICE, POMPIER, MAIRIE, entreprise:<id>:<grade> (grade typed in a small numeric box, clamped -1..99). Unrecognised existing access strings are preserved ("Verrouillé").
- Admin screen: name, size cycle (1x1/2x2/2x4/4x4), 8 visible floor rows with mouse-wheel scroll, per row name/Y/"Ma position"/access cycle/company cycle (+grade)/Supprimer, "+ Étage", Enregistrer, Fermer, error line. Client-side min 2 / max 32 enforced (buttons disabled, plus validate before send).
- Panel screen: round buttons, lowest floor at bottom; wraps into extra columns if floors do not fit the height. Current floor ringed in cyan/green and not clickable, disallowed floors dimmed and not clickable; tooltip FloorView.tooltip() on hover (also on dimmed ones); click sends SelectFloorPacket then closes.

## Build
`./gradlew build test` : BUILD SUCCESSFUL (only deprecation warnings), existing tests green. No new tests (client/network code).

## Not verified (no runClient)
Rendering/layout of both screens, hover tooltips, round button look, scrolling, real packet round trip, admin save with valid/invalid data, with/without the Entreprises mod. No test command was added.

## Concerns
- Nothing opens the screens yet (Task 10 must call ModNetwork.sendPanel / sendAdminPanel).
- Admin save replaces the stored elevator; Task 10 must refresh any live TripController / cabin that holds the old Elevator (floors/count may change).
- Floor numbers shown are 0-based indices, as FloorView.tooltip() does.
- Layout (440x330 panel, 8 rows) is fixed size; very small GUI scales may overflow.
- logo.png texture does not exist yet (guarded).

## Fix round 1 : bornage du décodage (finding Important)
- New `network/PacketLimits` : `readCount` (rejects count < 0 or > max with IllegalArgumentException before any allocation), `readList(buf, max, reader)` (new ArrayList<>(n)), `readFloors`/`writeFloors`. Bounds: floors 32 (Elevator.MAX_FLOORS), companies 256, names/access/company entries 64, size 8, error 256.
- AdminSavePacket, AdminPanelPacket, ElevatorPanelPacket no longer use `FriendlyByteBuf.readList`; all readUtf/writeUtf use the bounds above.
- New test `PacketLimitsTest` (4 tests, uses FriendlyByteBuf over Unpooled buffer; it loads fine under JUnit): round trip, Integer.MAX_VALUE count rejected, negative rejected, bound+1 rejected.
- Commands: `./gradlew build test` -> BUILD SUCCESSFUL, all tests pass (PacketLimitsTest result file produced).

## Fix round 2 : assainissement à l'envoi
- PacketLimits: `truncate`, `sanitizeCompanies` (max 256 entries, each cut to 64 chars; "id|nom" keeps the id since the cut hits the end), `sanitizeFloors` (max 32, names 64, access 64).
- ModNetwork.sendAdminPanel sanitizes name/size/floors/companies/error before building the packet; sendPanel truncates elevator name, floor names and role labels. Nothing throws on oversized stored/external data any more.
- Tests added to PacketLimitsTest: long name, 300 entries, entry without '|', empty/null list, floors truncate+cap. Now 8 tests, 0 failures.
- `./gradlew build test`: BUILD SUCCESSFUL.
