# SDD ledger — plan: docs/superpowers/plans/2026-10-13-ascenseur.md

Spec: docs/superpowers/specs/2026-10-13-ascenseur-design.md (read, binding)
Workspace: minenorth-ascenseur/.superpowers/sdd/2026-10-13-ascenseur
Branch: feature/ascenseur in a NEW nested git repo at minenorth-ascenseur (base commit 9c1db38).

## Preflight scan

| Row | Finding |
|---|---|
| T1 files | creates .gitignore — already created in setup commit 9c1db38 (build/, run/, .gradle/, .idea/, *.iml, .superpowers/) |
| T1 vs T4/T9 | T1 produces MOD_ID; T9 ModNetwork channel uses it. consistent |
| T2 → T3/T5/T6/T7 | Elevator/Floor/CabinSize consumed by access, trip, panel, NBT. signatures consistent |
| T3 → T4/T6 | Roles interface consumed by ServerRoles (T4), PanelBuilder/ElevatorRules (T6). entrepriseExists/entrepriseCanOpen names match |
| T4 → T9 | EntrepriseCompat.companies/grades used by AdminPanelPacket. consistent |
| T5 → T6/T10 | TripController consumed by ElevatorRules (T6) and ElevatorService (T10). consistent |
| T6 → T9 | FloorView.tooltip used by ElevatorPanelPacket. consistent |
| T7 → T8/T10 | ElevatorData/StoredElevator used by blocks (anchor lookup) and service. consistent |
| T8 → T10 | block entities hold elevatorId/floorIndex, used by T10 interactions. consistent |
| T9 AdminPanelPacket | "Elevator-complet" under-specified |
| T10 | oversized (entity + service + renderer + 3 blocks' interactions + obstruction + recovery) |
| T1,T4,T9,T10,T11,T12 | steps need runServer/runClient; subagents cannot drive a GUI client |
| T7 | NBT test may not load MC classes in JUnit; plan already gives fallback |
| T2,T3,T5,T6 | each: tests ↔ code agree; files created ↔ files touched agree |

## Rulings

- Ruling: use a new standalone git repo in minenorth-ascenseur (branch feature/ascenseur) instead of the parent repo — the parent is the old vehicles repo on master with 150 deleted tracked files and a GitHub remote, and the ascenseur folder is untracked there — costs: history is not in the parent repo; `git init` is reversible by deleting .git.
- Ruling: .gitignore comes from the setup commit; T1 must not recreate it — costs nothing.
- Ruling: implementers run `./gradlew runServer` (headless) where the plan asks; any runClient/GUI step is NOT executed by subagents, reported as "not verified", and collected for the user's final recette (T12) — costs: GUI defects are found late.
- Ruling: AdminPanelPacket carries (UUID id, String name, String size, List<Floor> floors, List<String> companies, String error) — fills the plan's "Elevator-complet" — costs a small rename if wrong.
- Ruling: T10 is dispatched as two implementer dispatches reviewed separately: 10a = spike + CabinEntity + ElevatorService core + CabinRenderer for a 1x1 cabin; 10b = block interactions, floor doors, sizes 2x2/2x4/4x4, obstruction recovery, restart reset — costs one extra review seat.
- Ruling: all commits end with "Co-Authored-By: Claude Sonnet 5.5 <noreply@anthropic.com>" per the session attribution rule.
Task 1: complete (commits 9c1db38..50b3b7c, review clean)
Task 1: minor (deferred): build.gradle:62 stray whitespace-only line in dependencies block
Task 2: complete (commits 50b3b7c..00ab7d7, review clean)
Task 2: minor (deferred): Elevator has no equals/hashCode (ids available); blank-name/null-size/null-floor paths in validate untested; commit trailer unverified from diff
Task 3: Ruling: "entreprise:<id>" without a grade parses to Unknown (locked for non-OP), unlike Portes which defaults to grade 99 — spec format is entreprise:<id>:<gradeMin> and unknown = locked, fail-safe — costs: a hand-edited short value locks instead of opening to all employees
Task 3: complete (commits 00ab7d7..e2581d4, review clean)
Task 3: minor (deferred): FloorAccess.java:28-34 clumsy switch/default; format() normalises clamped grades
Task 4: Ruling: SecoursCompat uses MineNorth.secours() (API) as the current Portes does, not reflection on SecoursApi — spec says "comme dans Portes" and no hard dependency on the Secours mod results — costs: requires the minenorthapi jar to expose secours() (build passes)
Task 4: complete (commits e2581d4..80626c1, review clean)
Task 4: minor (deferred): redundant isOp check in Permissions/ServerRoles (mirrors Portes); runtime check of ServerRoles not run (needs a joined player) — goes to T12 recette
Task 5: Ruling: reviewer Important (select window = 1 tick when queue non-empty, plan-mandated) is a real spec violation ("il peut choisir au prochain arrêt") — fix in TripController, signature unchanged: IDLE with a non-empty queue dwells doorTicks ticks before departing unless select() was accepted — costs: +doorTicks latency on chained calls
Task 5: fix round 1/5 (1 addressed pending re-review — select window; commits 7c9d3cd..e2b9503)
Task 5: fix round 1/5 (2 addressed, 0 open; commits 7c9d3cd..e2b9503)
Task 5: complete (commits 80626c1..e2b9503, review clean)
Task 5: minor (deferred): dwell stays at doorTicks after an empty-queue stop, so a fresh call much later waits an extra doorTicks before departing (reset dwell to 0 when queue empty); floor count not validated 2..32 in controller
Task 6: Ruling: tooltip index is 0-based on purpose — the spec example (0 Accueil ... 3 Garde à vue) numbers floors from 0; the implementer miscounted the example, no change — costs nothing
Task 6: complete (commits e2b9503..16d4a21, review clean)
Task 6: CARRIED TO TASK 10 (must be in the dispatch): two select() calls in one tick both succeed and last write wins (TripController.select overwrites `selected`; canSelect is stateless) — the ElevatorService must serialise: first accepted select per tick wins, others rejected (e.g. add TripController.hasPendingSelection()/selectedFloor() accessor and have the service check it)
Task 6: minor (deferred): FloorView.java:59 PUBLIC detection by label string equality; duplicated FakeRoles/elevator() fixtures in tests; passengersWithoutRoleStillCarried tautological
Task 7: note: untracked logs/ at repo root (runServer artefact) — add to .gitignore at a later task; NBT wrappers + ElevatorData load/save not unit-testable in JUnit JVM — goes to T12 recette (create, /save-all, restart)
Task 7: complete (commits 16d4a21..b296330, review clean)
Task 7: CARRIED TO TASK 10: StoredElevator does not guarantee a loaded dimension — treat server.getLevel(stored.dim())==null as "unavailable"; creation logic must keep anchors unique
Task 7: minor (deferred): ElevatorNbt.read should require Anchor compound and non-empty Dim (currently missing Anchor reads as 0,0,0); ElevatorData.load drops invalid entries silently — add a warning log; no tests for read() throwing on missing Id/unknown Size/too few floors
Ruling: user asked for quick reviews — from Task 8 on, task reviews run in "fast mode" (reviewer told: spec compliance + Critical/Important only, no Minor list, ≤1 focused risk check, short report) on the mid tier; Task 10 (cabin) and the final whole-branch review stay thorough — costs: more Minor findings go unreported until the final review
Task 8: complete (commits b296330..15b8f64, review clean, fast mode)
Task 8: not verified (needs runClient, goes to T12 recette): rendering/textures, placing/breaking, elevatorId survives reload, creative tab contents
Task 9: CARRIED TO TASK 10: implement fr.minenorth.ascenseur.network.ServerHooks.SelectionService (tripFor(UUID), isInsideCabin(ServerPlayer, StoredElevator), onFloorSelected(ServerPlayer, StoredElevator, int)) and install via ServerHooks.setSelectionService; open screens via ModNetwork.sendPanel / ModNetwork.sendAdminPanel; admin save replaces the stored elevator -> refresh live TripController/cabin (TripController.updateFloors) 
Task 9: fix round 1/5 (1 addressed pending re-review — unbounded decode lists; commits bcff8d3..ee945eb)
Task 9: fix round 2/5 (1 addressed pending re-review — server-side sanitisation of company/floor lists; commits ee945eb..de3fcf2)
Task 9: fix round 2/5 (1 addressed, 0 open; commits ee945eb..de3fcf2)
Task 9: complete (commits 15b8f64..de3fcf2, review clean after 2 fix rounds)
Task 9: minor (deferred): PacketLimits.truncate cuts on UTF-16 length (could split a surrogate pair); admin screen fixed 440x330 may overflow at small GUI scales
Task 10a: DONE_WITH_CONCERNS (commits de3fcf2..8fb4adb: 86998c3, 91ee49c, 8fb4adb) — review pending (thorough)
Task 10a: Ruling: for 10b, the anchor CabinBlock becomes a non-colliding corner console (small VoxelShape, noCollission) so riders are not blocked; the cabin entity floor/walls come from CabinEntity+CabinFloorBlock — costs: console must be clickable outline only
Task 10a: CARRIED TO 10b: obstruction detection not implemented (cabin passes through blocks); anchor CabinBlock inside the cabin; relogin after cabin left/crash mid-trip falls down the shaft (no damage); cabin captures clicks inside (intended)
Task 10a: review (thorough, opus): Needs fixes — Critical 1 mounted riders hurt/left behind (ElevatorService:339,197-199); Critical 2 deactivation mid-trip drops riders in the air, resize during trip drops riders (ElevatorService:477-491,224-226); Important 3 floors-only admin save by index moves cabin out from under players (ElevatorService:231-234 + TripController:199-200); Minor 4 orphan-cabin logout y, 5 boardPlayers scans all players, 6 shift re-board jitter, 7 footprint test gaps
Task 10a: Ruling: mounted players are dismounted (stopRiding) when boarding; fall damage is cancelled for ANY living entity inside a shaft (not only players); non-player entities are not carried — costs: a horse left in the cabin falls to the shaft bottom unharmed
Task 10a: fix round 1/5 dispatched (resume implementer a39ebc2c72e21f53d)
Task 10a: fix round 1/5 (5 addressed pending re-review; commit 8fb4adb..50f8d64)
Task 10a: CARRIED TO 10b: ElevatorService.release(UUID) must be called by deletion AFTER removing from ElevatorData; landing placement assumes floor door row in front of cabin and does not check blocked cells; floor blocks may be left behind if elevator deleted/resized while shaft chunks unloaded
Task 10a: fix round 1/5 (5 addressed, 0 open; commit 8fb4adb..50f8d64)
Task 10a: complete (commits de3fcf2..50f8d64, review clean after 1 fix round)
Task 10a: minor (deferred): AbstractHorse.causeFallDamage bypasses LivingFallEvent so mounts left in a shaft can be hurt (needs LivingHurtEvent for fall source in shaft); boardPlayers scans every player per moving elevator per tick; shift-hold rider re-board jitter; while MOVING a floors-only save is still index-based (rider safe)
Task 10a: CARRIED TO 10b: landingSpot fallback can place player in a block when row -1/-2 cells are blocked; landing assumes floor-door row is row -1 of the cabin; release() with unloaded shaft chunks leaves floor blocks; relocate/pendingTeleports edge case on dimension change
Ruling: 10b linking — OP-placed call buttons and floor doors auto-link by geometry (floor door in row -1 in front of a cabin at a floor y; button within 2 blocks of such a door row at the floor y); creation — an OP placing CabinBlock creates a default 1x1 elevator with 2 floors (anchor y and anchor y+4, PUBLIC); non-OP placement cancelled — costs: no manual link UI in v1
Task 10b: DONE_WITH_CONCERNS (commits 50f8d64..0a1e4df: ad879f2, 0a1e4df; 93 tests green) — per-task review SKIPPED by ruling (user short on time); covered by the thorough final whole-branch review
Ruling: skip the 10b task review and the 11/12 task reviews; final whole-branch review (opus, thorough, focused on Task 10) replaces them — costs: defects in 10b/11/12 surface only at the end
Task 10b: deviations: doors link from floor height to 2 blocks above; button up to 2 blocks above its door; blocked both ways -> riders set down on landing, cabin waits; old dev-world cabin blocks come back facing north
Task 11+12: DONE_WITH_CONCERNS (commits 0a1e4df..499a005: 7816fc3, 499a005; 101 tests green) — per-task review skipped by ruling
Task 11+12: notes: /ascenseur reload applies to elevators activated afterwards (TripController fields final); /ascenseur remove leaves the placed console block in the world, unlinked; pistons not handled by an event (PushReaction.BLOCK on all four blocks)
FIRST IN-GAME TEST (user, 2026-10-13 20:16): 6 problems — (1) players walk through cabin walls; (2) in-cabin console/button does not follow the cabin; (3) cabin look is ugly; (4) floor doors do not sit flush against the cabin; (5) cannot break the elevator; (6) two floor doors side by side are placed badly. Dispatched to resumed 10b implementer a5d20870e2eef9c49 (fix wave 1). Final whole-branch review a7899a75576d2920c still running.
FINAL REVIEW (opus, a7899a75576d2920c) verdict: yes WITH FIXES — C1 fluid deletes elevator/doors (noCollission blocks replaceable by fluid, onRemove deletes elevator); C2 stuck in shaft after relogin/crash/door doorway + no rescue; I1 hold-right-click on call button keeps cabin hostage (dwell reset); I2 admin Save button off-screen at GUI scale 4 (440x330 panel); I3 no build-height bound on floor y; I4 overlapping footprints allowed; I5 no try/catch on server tick; I6 door orientation not forced; I7 selections during DOORS_OPENING silently dropped; I8 cabin swallows clicks + boardPlayers dismounts carried/cuffed/stretcher (spec: patient on a bed); I9 permission node namespace minenorthascenseur.* != minenorthportes.*; minors: dwell reset when queue empty, load warnings, lava/fire obstruction, non-OP can place doors/buttons, no en_us.
Ruling: wave 2 (sent to a5d20870e2eef9c49 after wave 1): fix C1, C2, I1, I2, I3, I4, I5, I7 + dwell reset + load warnings + lava/fire obstruction + OP-only placement of doors/buttons; I6 already in wave 1; I8 and I9 documented in README as v1 limitations/needs (no code) — costs: LuckPerms grants must target minenorthascenseur.grade.*; cuffed/stretcher carries are dismounted in cabins
FEATURE WAVE 4 (user request after retest, 2026-10-14, approved in chat): fix cabin floor z-fighting; per-elevator customisation (16 dye colours + glass sides, admin menu); new size 1x2 (1 wide x 2 deep); nicer call button with lit state; new floor indicator block (number + arrow, linked per floor) + display in cabin. Defaults: style saved with the elevator, visible to all; indicator shows floor number by default.
