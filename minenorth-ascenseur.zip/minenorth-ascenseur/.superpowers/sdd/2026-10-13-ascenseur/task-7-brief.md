### Task 7 : Persistance

**Files :**
- Create : `data/ElevatorNbt.java`, `data/ElevatorData.java`
- Test : `data/ElevatorNbtTest.java`

**Interfaces :**
- Produces :
  - `ElevatorNbt.toTag(Elevator e, ResourceKey<Level> dim, BlockPos anchor, Direction facing) -> CompoundTag` et `fromTag(CompoundTag) -> StoredElevator` (record `(Elevator elevator, ResourceKey<Level> dim, BlockPos anchor, Direction facing)`).
  - `ElevatorData extends SavedData` : `static ElevatorData get(MinecraftServer)`, `Optional<StoredElevator> byId(UUID)`, `Optional<StoredElevator> atAnchor(ResourceKey<Level>, BlockPos)`, `void put(StoredElevator)`, `void remove(UUID)`, `Collection<StoredElevator> all()`. Stocké dans l'overworld sous le nom `minenorthascenseur_elevators`, comme `OwnerDoorData`.

- [ ] **Step 1 :** Test `ElevatorNbtTest.roundTrip` : l'exemple d'hôpital survit à `toTag` puis `fromTag` (nom, taille, 5 étages, accès, ancre, orientation). Si les classes Minecraft ne se chargent pas dans les tests JUnit, déplacer ce test en vérification manuelle (création, `/save-all`, redémarrage, relecture) et le noter dans le commit.
- [ ] **Step 2 :** `./gradlew test --tests '*ElevatorNbtTest'` ; attendu : échec.
- [ ] **Step 3 :** Implémenter.
- [ ] **Step 4 :** Même commande ; attendu : vert.
- [ ] **Step 5 :** Commit `feat: sauvegarde des ascenseurs`.

---

