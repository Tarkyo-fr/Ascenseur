### Task 5 : Contrôleur de trajet

**Files :**
- Create : `model/TripController.java`
- Test : `model/TripControllerTest.java`

**Interfaces :**
- Produces : `final class TripController` :
  - `TripController(int[] floorYs, int startFloor, double blocksPerTick, int doorTicks)`
  - `enum Phase { IDLE, DOORS_CLOSING, MOVING, DOORS_OPENING }`
  - `void call(int floor)` : met en file ; ignoré si déjà en file ; si la cabine est à cet étage et inactive, rouvre les portes.
  - `boolean select(int floor)` : `false` si la phase n'est pas `IDLE` ou si l'étage est invalide ; sinon enregistre la destination.
  - `void tick()`, `Phase phase()`, `int currentFloor()`, `int targetFloor()` (`-1` si aucune), `double y()`.
  - `void updateFloors(int[] floorYs)` : écarte les appels vers un étage disparu.
  - `void reset(double y)` : recale sur l'étage le plus proche, phase `IDLE`, file vidée.

- [ ] **Step 1 :** Tests : `callsServedInOrder`, `duplicateCallsNotQueued`, `selectIgnoredWhileMoving`, `selectAllowedWhenIdle`, `callAtCurrentFloorOpensDoors`, `reachesTargetExactly` (`y()` égale `floorYs[target]` à l'arrivée), `floorsRemovedWhileQueued`, `resetSnapsToNearestFloor` (reset à `y=73` avec étages 64/70/76 → étage 1 puis phase `IDLE`).
- [ ] **Step 2 :** `./gradlew test --tests '*TripControllerTest'` ; attendu : échec.
- [ ] **Step 3 :** Implémenter la machine d'états : `IDLE` → `DOORS_CLOSING` (`doorTicks`) → `MOVING` → `DOORS_OPENING` → `IDLE` (puis prochain appel de la file).
- [ ] **Step 4 :** Même commande ; attendu : tous verts.
- [ ] **Step 5 :** Commit `feat: contrôleur de trajet`.

---

