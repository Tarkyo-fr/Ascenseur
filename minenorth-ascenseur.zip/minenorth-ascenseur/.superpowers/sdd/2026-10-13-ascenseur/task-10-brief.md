### Task 10 : Cabine mobile et service serveur

**Files :**
- Create : `cabin/CabinEntity.java`, `cabin/ModEntities.java`, `cabin/ElevatorService.java`, `client/CabinRenderer.java`
- Modify : `block/CabinBlock.java`, `block/CallButtonBlock.java`, `block/FloorDoorBlock.java` (interactions)

**Interfaces :**
- Consumes : `TripController`, `ElevatorRules`, `ServerRoles`, `ElevatorData`, paquets de la Task 9.
- Produces : `ElevatorService.onServerTick(MinecraftServer)` (un `TripController` par ascenseur chargé), `handleSelect(ServerPlayer, UUID, int)`, `handleCall(ServerPlayer, UUID, int)`, `openPanel(ServerPlayer, UUID)`.
- Interactions : clic droit sur la cabine → `openPanel` (joueur) ; OP + accroupi → panneau admin ; clic sur le bouton d'appel → `handleCall` ; la porte d'étage est un obstacle fermé tant que la cabine n'est pas à son étage et passe en ouvert avec elle.
- Exigences (spec) : empreinte exacte selon `CabinSize` (2×4 selon l'orientation), mouvement fluide visuel, **aucun dégât de chute, aucune expulsion anti-fly, jamais dans un mur**, tous les joueurs dans l'empreinte voyagent ensemble, un passager qui se déconnecte ou meurt ne bloque pas le service, au démarrage du serveur chaque cabine est recalée via `TripController.reset(y)`.
- Conseil : commencer par un spike de fluidité (une cabine 1×1 qui monte avec un joueur dessus) avant d'écrire le reste ; l'implémentation entité + passagers repositionnés à chaque tick est ma suggestion, pas une contrainte.

- [ ] **Step 1 :** Spike : `CabinEntity` 1×1 et trajet entre deux hauteurs fixes ; vérifier à la main que le joueur monte sans saccade, sans dégât et sans kick après 10 s en l'air.
- [ ] **Step 2 :** Brancher `ElevatorService` sur `ElevatorData` et `TripController`, interactions des trois blocs, tailles 2×2, 2×4, 4×4, portes d'étage, détection d'obstruction (arrêt + retour à l'étage précédent).
- [ ] **Step 3 :** `./gradlew build` ; attendu : `BUILD SUCCESSFUL`, tous les tests précédents toujours verts (`./gradlew test`).
- [ ] **Step 4 :** Vérification manuelle (liste de contrôle) : 1) trajet 0→3 avec 2 joueurs, tous arrivent ; 2) bouton d'appel d'un étage POLICE sans rôle : inerte ; 3) joueur sans rôle monte avec un policier qui choisit « Garde à vue » : il arrive aussi ; 4) bloc posé dans la gaine : arrêt sans dégât ; 5) un passager se déconnecte en plein trajet : service intact ; 6) `/stop` en plein trajet puis relance : cabine à un étage.
- [ ] **Step 5 :** Commit `feat: cabine mobile et service d'ascenseur`.

---

