### Task 3 : Règles d'accès par étage

**Files :**
- Create : `model/Roles.java`, `model/FloorAccess.java`
- Test : `model/FloorAccessTest.java`

**Interfaces :**
- Consumes : rien.
- Produces :
  - `interface Roles { boolean isOp(); boolean isPolice(); boolean isSecours(); boolean isMairie(); boolean hasNode(String node); boolean entrepriseExists(int id); boolean entrepriseCanOpen(int id, int minGrade); }`
  - `sealed interface FloorAccess` avec `static FloorAccess parse(String raw)` (valeur inconnue → `Unknown`), `String format()`, `boolean canUse(Roles r)`, `String label()` (« Public », « Police », « Pompier/SAMU », « Mairie », « Entreprise », « Verrouillé »).

- [ ] **Step 1 :** Tests avec un faux `Roles` : `publicOpenToAll`, `opAlwaysPasses`, `policeRequiresPoliceOrNode`, `pompierRequiresSecoursOrNode`, `mairieRequiresStaffOrNode`, `entrepriseUsesGrade` (`entreprise:3:1` ouvert seulement si `entrepriseCanOpen(3,1)`), `entrepriseMissingLocksFloor` (`entrepriseExists` faux : verrouillé même pour un employé), `missingRoleModLocksFloor` (tous les rôles faux : POLICE/POMPIER/MAIRIE fermés), `unknownAccessLocksFloorForNonOp` (`"banane"`, `"entreprise:x"`), `roundTripFormat` (`entreprise:3:-1`).
- [ ] **Step 2 :** `./gradlew test --tests '*FloorAccessTest'` ; attendu : échec.
- [ ] **Step 3 :** Implémenter. L'ordre d'évaluation dans `canUse` : OP d'abord, puis le cas ; nœud Forge ou rôle API pour POLICE/POMPIER/MAIRIE (comme `canOpen` de Portes, lignes 264–266).
- [ ] **Step 4 :** Même commande ; attendu : tous verts.
- [ ] **Step 5 :** Commit `feat: règles d'accès des étages`.

---

