### Task 1 : Squelette du mod

**Files :**
- Create : `build.gradle`, `settings.gradle`, `.gitignore` (`build/`, `run/`, `.gradle/`, `.superpowers/`), `gradle/wrapper/*` et `gradlew*` (copie de `../minenorth-portes`)
- Create : `src/main/resources/META-INF/mods.toml`, `src/main/resources/pack.mcmeta`
- Create : `src/main/java/fr/minenorth/ascenseur/MineNorthAscenseur.java`
- Test : `src/test/java/fr/minenorth/ascenseur/ModIdTest.java`

**Interfaces :**
- Produces : `MineNorthAscenseur.MOD_ID = "minenorthascenseur"`.

- [ ] **Step 1 :** Test `ModIdTest.modIdIsStable` : `assertEquals("minenorthascenseur", MineNorthAscenseur.MOD_ID)`.
- [ ] **Step 2 :** `./gradlew test` ; attendu : échec de compilation (classe absente).
- [ ] **Step 3 :** Copier `build.gradle` de Portes en remplaçant `minenorthportes`/`minenorth-portes`/`MineNorth Portes` par les valeurs des Global Constraints, ajouter `testImplementation 'org.junit.jupiter:junit-jupiter:5.10.2'` et `test { useJUnitPlatform() }`. Écrire `mods.toml` avec les dépendances forge, minecraft, `minenorthapi` (copier celles de Portes). Classe `@Mod(MOD_ID)` vide.
- [ ] **Step 4 :** `./gradlew test build` ; attendu : `BUILD SUCCESSFUL` (le jar `minenorth-ascenseur-1.0.0.jar` est produit ; `../minenorth-api` doit avoir été construit avant).
- [ ] **Step 5 :** `./gradlew runServer`, vérifier dans le log le chargement du mod `minenorthascenseur` sans erreur, puis stopper.
- [ ] **Step 6 :** Commit `chore: squelette du mod ascenseur`.

---

