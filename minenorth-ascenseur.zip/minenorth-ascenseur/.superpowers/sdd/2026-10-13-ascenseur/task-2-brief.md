### Task 2 : Modèle d'ascenseur et validation

**Files :**
- Create : `model/CabinSize.java`, `model/Floor.java`, `model/Elevator.java`
- Test : `model/ElevatorTest.java`

**Interfaces :**
- Produces :
  - `enum CabinSize { S1X1, S2X2, S2X4, S4X4 }` avec `int width()`, `int depth()`, `static Optional<CabinSize> parse(String)` (`"2x4"`).
  - `record Floor(String name, int y, String access)`.
  - `final class Elevator` : `UUID id()`, `String name()`, `CabinSize size()`, `List<Floor> floors()`, `static Optional<String> validate(String name, CabinSize size, List<Floor> floors)` (retourne un message d'erreur ou vide).
  - constantes `MIN_FLOORS = 2`, `MAX_FLOORS = 32`.

- [ ] **Step 1 :** Tests : `rejectsFewerThanTwoFloors`, `rejectsMoreThan32Floors`, `rejectsNonIncreasingHeights`, `rejectsBlankFloorName`, `acceptsHospitalExample` (Accueil 64 `PUBLIC`, Urgences 70 `PUBLIC`, Bloc opératoire 76 `POMPIER`, Garde à vue 82 `POLICE`, Direction 88 `entreprise:1:1`, taille `2x4`), `parsesSizes` (`"1x1"`, `"2x2"`, `"2x4"`, `"4x4"` valides, `"3x3"` vide).
- [ ] **Step 2 :** `./gradlew test --tests '*ElevatorTest'` ; attendu : échec.
- [ ] **Step 3 :** Implémenter les trois types. `validate` renvoie le premier message d'erreur en français.
- [ ] **Step 4 :** Même commande ; attendu : tous verts.
- [ ] **Step 5 :** Commit `feat: modèle ascenseur et validation`.

---

