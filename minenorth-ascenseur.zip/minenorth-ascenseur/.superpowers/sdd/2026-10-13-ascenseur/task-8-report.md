# Task 8 - Blocs et enregistrements

## Done
- block/: ModBlocks (DeferredRegister blocs/objets/entites de bloc, CABIN/CALL_BUTTON/FLOOR_DOOR, CABIN_BE/CALL_BUTTON_BE/FLOOR_DOOR_BE, register(IEventBus), onglet MineNorth via BuildCreativeModeTabContentsEvent sur minenorthapi:minenorth), CabinBlock, CallButtonBlock, FloorDoorBlock (FACING vers le joueur, formes simples, strength 3, use -> PASS), trois BlockEntity avec elevatorId (+ floorIndex=-1 pour bouton/porte), NBT save/load + getUpdateTag/getUpdatePacket.
- Resources assets/minenorthascenseur: blockstates, models block/item (textures vanilla iron_block / stone), lang/fr_fr.json.
- MineNorthAscenseur: ModBlocks.register(modEventBus). .gitignore: logs/.

## Verification
- ./gradlew build: BUILD SUCCESSFUL; ./gradlew test (rerun-tasks): BUILD SUCCESSFUL.
- ./gradlew runServer headless: server reached "Done (18.9s)", no registry/mod-loading errors; process ended (only the Gradle daemon remains).
- NOT verified: rendering/textures/models in client, placement, breaking, persistence of elevatorId across reload, creative tab contents in-game (needs runClient).

## Concerns
- Tab filler uses e.accept(RegistryObject) directly rather than a DisplayItemsGenerator as Portes does; equivalent effect.
- Block entity types are built with .build(null) as in ModVending.
