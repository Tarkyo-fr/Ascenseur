# Task 7 - Persistance : rapport

## Fichiers
- src/main/java/fr/minenorth/ascenseur/data/StoredElevator.java (record)
- src/main/java/fr/minenorth/ascenseur/data/ElevatorNbt.java
- src/main/java/fr/minenorth/ascenseur/data/ElevatorData.java (SavedData, nom `minenorthascenseur_elevators`, overworld, comme OwnerDoorData)
- src/test/java/fr/minenorth/ascenseur/data/ElevatorNbtTest.java

## RED
`./gradlew test --tests '*ElevatorNbtTest'` avant implementation : compilation en echec ("cannot find symbol ElevatorNbt", 6 errors).

## Decouverte : classes Minecraft dans JUnit
- `Level.OVERWORLD`, `ResourceKey`, `Registries` : ExceptionInInitializerError "Not bootstrapped" (BuiltInRegistries.<clinit>).
- `Bootstrap.bootStrap()` dans @BeforeAll : echoue (Forge : NoSuchMethodException net.minecraftforge.network.NetworkEvent.<init>). Abandonne.
- Pas de faux : le coeur est separe. `ElevatorNbt.write(Elevator, ResourceLocation, BlockPos, Direction)` et `read(CompoundTag) -> Parts` (package-private) n'utilisent pas ResourceKey ; `toTag`/`fromTag` ne sont que de fines enveloppes (`dim.location()` / `ResourceKey.create(Registries.DIMENSION, loc)`).
- CompoundTag, ListTag, NbtUtils, BlockPos, Direction, ResourceLocation se chargent sans bootstrap.

## GREEN
`./gradlew test --tests '*ElevatorNbtTest'` : BUILD SUCCESSFUL (roundTrip + invalidFacingFallsBackToNorth).
`./gradlew build test` : BUILD SUCCESSFUL, 44 tests, 0 echec (tous les fichiers de resultats).

## Verifie / non verifie
- Verifie : aller-retour NBT de l'exemple hopital (nom, taille 2x4, 5 etages avec acces, id, ancre, dim en ResourceLocation, orientation) ; repli NORTH pour orientation absente/invalide (ex. "up").
- NON verifie (a faire en recette) : `ElevatorData` (load/save reel, `computeIfAbsent`) et les enveloppes toTag/fromTag avec ResourceKey : creer un ascenseur, `/save-all`, redemarrer, verifier qu'il est relu. Le chargement saute les entrees invalides (try/catch RuntimeException) au lieu de planter.

## Concerns
- Dimension : un `ResourceKey` ne peut pas etre teste en JUnit ici ; la recette manuelle couvre ce point.
- Le dossier non suivi `logs/` existe a la racine (non ajoute au commit).
