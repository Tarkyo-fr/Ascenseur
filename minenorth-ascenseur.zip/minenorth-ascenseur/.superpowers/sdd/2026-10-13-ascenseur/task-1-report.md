# Task 1 report
- Copied gradle wrapper/gradlew* and adapted build.gradle/settings.gradle/mods.toml/pack.mcmeta from minenorth-portes (eurobank dependency dropped; only forge, minecraft, minenorthapi). Added junit-jupiter 5.10.2 + useJUnitPlatform. Class MineNorthAscenseur (@Mod, MOD_ID), ModIdTest.
- RED: `./gradlew test` -> compileTestJava error "cannot find symbol MineNorthAscenseur", BUILD FAILED.
- GREEN: `./gradlew test build` -> BUILD SUCCESSFUL, build/libs/minenorth-ascenseur-1.0.0.jar.
- runServer (eula.txt in run/, stdin `stop` after 150s): log shows "Found valid mod file main with {minenorthascenseur}" and "Creating FMLModContainer instance for fr.minenorth.ascenseur.MineNorthAscenseur"; server reached spawn prep and world save on stop. Noise only: netty Unsafe warnings, server.properties first-run error (generated file).
- Concern: none. Tests are only run via gradle.
