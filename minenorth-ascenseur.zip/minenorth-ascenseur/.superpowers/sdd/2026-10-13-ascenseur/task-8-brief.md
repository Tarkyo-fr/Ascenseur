### Task 8 : Blocs et enregistrements

**Files :**
- Create : `block/ModBlocks.java`, `block/CabinBlock.java`, `block/CabinBlockEntity.java`, `block/CallButtonBlock.java`, `block/CallButtonBlockEntity.java`, `block/FloorDoorBlock.java`, `block/FloorDoorBlockEntity.java`
- Create : `src/main/resources/assets/minenorthascenseur/{blockstates,models/block,models/item,lang/fr_fr.json}` pour `cabine`, `bouton_appel`, `porte_etage`
- Modify : `MineNorthAscenseur.java` (enregistrement sur le bus du mod)

**Interfaces :**
- Produces : `ModBlocks.CABIN`, `ModBlocks.CALL_BUTTON`, `ModBlocks.FLOOR_DOOR` (`RegistryObject<Block>`), leurs types d'entité de bloc, et dans chaque entité un champ `UUID elevatorId` (+ `int floorIndex` pour bouton et porte d'étage) avec NBT. Les trois objets vont dans l'onglet créatif MineNorth (voir `SharedTab` de Portes).
- Conventions : `DeferredRegister` comme `ModVending` du mod Entreprises ; textures provisoires vanilla acceptées.

- [ ] **Step 1 :** Implémenter les enregistrements et les trois blocs (les clics ne font encore rien, `use` retourne `InteractionResult.PASS`).
- [ ] **Step 2 :** `./gradlew build` ; attendu : `BUILD SUCCESSFUL`.
- [ ] **Step 3 :** Vérification manuelle `./gradlew runClient` : `/give` les trois blocs, les poser, les casser, quitter et revenir ; attendu : textures visibles, pas de crash, l'`elevatorId` survit au rechargement.
- [ ] **Step 4 :** Commit `feat: blocs cabine, bouton d'appel, porte d'étage`.

---

