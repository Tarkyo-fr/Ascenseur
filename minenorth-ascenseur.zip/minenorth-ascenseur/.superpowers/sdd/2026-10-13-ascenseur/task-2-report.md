# Task 2 report
Status: DONE
- RED: `./gradlew test --tests '*ElevatorTest'` -> `:compileTestJava FAILED` (CabinSize/Floor/Elevator absent), BUILD FAILED.
- GREEN: same command -> BUILD SUCCESSFUL, 7 tests pass (brief's 6 + constructorThrowsWhenInvalid). Full `./gradlew test` BUILD SUCCESSFUL.
- Files: model/CabinSize.java, Floor.java, Elevator.java (main); model/ElevatorTest.java (test).
- Design: Elevator public ctor (UUID, name, size, floors) throws IllegalArgumentException on invalid/null id; floors List.copyOf. validate also rejects blank elevator name and null size (extra, French messages). parse is trim/case-insensitive.
- Concerns: none.
