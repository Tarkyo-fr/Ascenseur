### Task 6 : Panneau joueur et règle de sélection

**Files :**
- Create : `model/PanelBuilder.java`, `model/ElevatorRules.java`
- Test : `model/PanelBuilderTest.java`, `model/ElevatorRulesTest.java`

**Interfaces :**
- Consumes : `Elevator`, `FloorAccess`, `Roles`, `TripController`.
- Produces :
  - `record FloorView(int index, String name, int y, String roleLabel, boolean allowed, boolean current)` et `String tooltip()` au format `3 · Garde à vue · Police`.
  - `PanelBuilder.forPlayer(Elevator e, Roles r, int currentFloor) -> List<FloorView>`.
  - `ElevatorRules.canSelect(Elevator e, int floor, Roles r, boolean insideCabin, TripController t) -> boolean` : vrai seulement si le joueur est dans la cabine, la phase est `IDLE`, l'étage existe, n'est pas l'étage actuel et `FloorAccess.canUse`.
  - `ElevatorRules.canCall(Elevator e, int floor, Roles r) -> boolean`.

- [ ] **Step 1 :** Tests : `tooltipShowsRoleLabel`, `lockedFloorIsNotAllowed`, `currentFloorIsMarked`, `cannotSelectWhileMoving`, `cannotSelectFromOutsideCabin`, `cannotSelectRestrictedFloorWithoutRole`, `callOnRestrictedFloorIsInertWithoutRole`, `passengersWithoutRoleStillCarried` (la règle ne regarde que le joueur qui choisit, pas la liste des passagers : `canSelect` n'a pas de paramètre passagers).
- [ ] **Step 2 :** `./gradlew test --tests '*PanelBuilderTest' --tests '*ElevatorRulesTest'` ; attendu : échec.
- [ ] **Step 3 :** Implémenter.
- [ ] **Step 4 :** Même commande ; attendu : tous verts.
- [ ] **Step 5 :** Commit `feat: panneau joueur et règles de sélection`.

---

